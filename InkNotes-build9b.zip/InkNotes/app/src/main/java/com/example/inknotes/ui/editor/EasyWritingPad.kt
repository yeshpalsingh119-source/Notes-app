package com.example.inknotes.ui.editor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardReturn
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.PointerInputChange
import androidx.compose.ui.input.pointer.PointerType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.example.inknotes.domain.model.LineStyle
import com.example.inknotes.domain.model.PenType
import com.example.inknotes.domain.model.Stroke
import com.example.inknotes.domain.model.StrokePoint
import com.example.inknotes.ink.StrokeRenderer
import java.util.UUID
import kotlin.math.hypot

/**
 * The page area the easy writing pad currently writes into (top-left + width in page px).
 * The pad shows exactly this area magnified; what is written in the pad lands in it at normal size.
 */
data class PadFrame(val x: Float, val y: Float, val w: Float)

private const val PAD_MARGIN = 40f

/** Moves the frame on to the right (a space); wraps to the next line at the end of the page. */
fun PadFrame.advance(pageW: Float, frameH: Float, frac: Float = 0.5f): PadFrame {
    val nx = x + w * frac
    return if (nx + w > pageW - PAD_MARGIN / 2f) PadFrame(PAD_MARGIN, y + frameH * 0.9f, w) else copy(x = nx)
}

fun PadFrame.back(pageW: Float, frameH: Float, frac: Float = 0.5f): PadFrame {
    val nx = x - w * frac
    return if (nx >= PAD_MARGIN / 2f) copy(x = nx)
    else if (y > PAD_MARGIN) PadFrame(maxOf(PAD_MARGIN, pageW - PAD_MARGIN / 2f - w), (y - frameH * 0.9f).coerceAtLeast(PAD_MARGIN), w)
    else copy(x = PAD_MARGIN)
}

fun PadFrame.nextLine(frameH: Float): PadFrame = PadFrame(PAD_MARGIN, y + frameH * 0.9f, w)

private fun strokeBounds(s: Stroke): FloatArray {
    var x0 = Float.MAX_VALUE; var y0 = Float.MAX_VALUE; var x1 = -Float.MAX_VALUE; var y1 = -Float.MAX_VALUE
    for (p in s.points) {
        if (p.x < x0) x0 = p.x; if (p.x > x1) x1 = p.x
        if (p.y < y0) y0 = p.y; if (p.y > y1) y1 = p.y
    }
    val m = s.width
    return floatArrayOf(x0 - m, y0 - m, x1 + m, y1 + m)
}

/**
 * Easy writing pad (Samsung): a strip above the toolbar that shows the framed page area at a larger size.
 * Write big in the strip, the strokes land inside the frame on the page. Near the right end the frame moves on by itself.
 */
@Composable
fun EasyWritingPad(
    frame: PadFrame,
    strokes: List<Stroke>,
    paperColor: Int,
    penType: PenType,
    penColor: Int,
    penWidth: Float,
    pageWidth: Float,
    onAspect: (Float) -> Unit,                 // pad height / pad width: the frame on the page has the same shape
    onFrame: (PadFrame) -> Unit,
    onStroke: (Stroke) -> Unit,
    onClose: () -> Unit
) {
    val renderer = remember { StrokeRenderer(false) }
    val bounds = remember { HashMap<String, FloatArray>() }
    val frameState = rememberUpdatedState(frame)
    val onFrameState = rememberUpdatedState(onFrame)
    val onStrokeState = rememberUpdatedState(onStroke)
    var area by remember { mutableStateOf(IntSize.Zero) }
    var live by remember { mutableStateOf<List<StrokePoint>>(emptyList()) }
    val frameH = if (area.width > 0) frame.w * area.height / area.width else frame.w * 0.3f

    Column(Modifier.fillMaxWidth().background(Color(0xFFFAFAFB))) {
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
        Row(Modifier.fillMaxWidth().height(40.dp).padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Easy writing pad", Modifier.weight(1f), style = MaterialTheme.typography.labelLarge)
            IconButton({ onFrame(frame.back(pageWidth, frameH)) }, Modifier.size(36.dp)) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
            IconButton({ onFrame(frame.advance(pageWidth, frameH)) }, Modifier.size(36.dp)) { Icon(Icons.AutoMirrored.Filled.ArrowForward, "Space") }
            IconButton({ onFrame(frame.nextLine(frameH)) }, Modifier.size(36.dp)) { Icon(Icons.Default.KeyboardReturn, "New line") }
            IconButton(onClose, Modifier.size(36.dp)) { Icon(Icons.Default.Close, "Close") }
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
        Box(
            Modifier.fillMaxWidth().height(190.dp).clipToBounds()
                .onSizeChanged { sz ->
                    area = sz
                    if (sz.width > 0) onAspect(sz.height.toFloat() / sz.width)
                }
                .pointerInput(Unit) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        val fr = frameState.value
                        val sz = area
                        if (sz.width <= 0) return@awaitEachGesture
                        val k = sz.width / fr.w                              // pad px per page px
                        val t0 = down.uptimeMillis
                        val pts = ArrayList<StrokePoint>()
                        fun add(c: PointerInputChange) {
                            val px = fr.x + c.position.x / k
                            val py = fr.y + c.position.y / k
                            val pr = if (c.type == PointerType.Stylus) c.pressure.coerceIn(0.05f, 1f) else 0.5f
                            val last = pts.lastOrNull()
                            if (last == null || hypot(px - last.x, py - last.y) * k > 1f) {
                                pts.add(StrokePoint(px, py, pr, 0f, 0f, c.uptimeMillis - t0))
                            }
                        }
                        add(down)
                        down.consume()
                        live = pts.toList()
                        while (true) {
                            val ev = awaitPointerEvent()
                            val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                            add(ch)
                            ch.consume()
                            if (!ch.pressed) break
                            live = pts.toList()
                        }
                        live = emptyList()
                        if (pts.size >= 2) {
                            onStrokeState.value(Stroke(UUID.randomUUID().toString(), penType, penColor, penWidth, pts))
                            val endPadX = (pts.last().x - fr.x) * k
                            if (endPadX > sz.width * 0.72f) {                // near the right end: the frame moves on by itself
                                val fh = fr.w * sz.height / sz.width
                                onFrameState.value(fr.advance(pageWidth, fh))
                            }
                        }
                    }
                }
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val k = size.width / frame.w
                val fh = size.height / k
                drawIntoCanvas { c ->
                    val nc = c.nativeCanvas
                    nc.save()
                    nc.drawColor(paperColor)
                    nc.scale(k, k)
                    nc.translate(-frame.x, -frame.y)
                    for (s in strokes) {
                        val b = bounds.getOrPut(s.id) { strokeBounds(s) }
                        if (b[2] < frame.x || b[0] > frame.x + frame.w || b[3] < frame.y || b[1] > frame.y + fh) continue
                        renderer.draw(nc, s)
                    }
                    if (live.size >= 2) renderer.drawLive(nc, penType, penColor, penWidth, LineStyle.SOLID, live)
                    nc.restore()
                }
                // faint writing line in the middle of the pad
                drawLine(Color(0x22000000), Offset(0f, size.height * 0.68f), Offset(size.width, size.height * 0.68f), strokeWidth = 1.dp.toPx())
            }
        }
    }
}
