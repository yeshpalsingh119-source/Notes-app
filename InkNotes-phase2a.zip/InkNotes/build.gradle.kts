// NOTE: versions are placeholders - bump to latest stable in Android Studio (AGP/Kotlin/KSP/Hilt must match).
plugins {
    id("com.android.application") version "8.9.2" apply false
    id("org.jetbrains.kotlin.android") version "2.1.20" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.1.20" apply false
    id("org.jetbrains.kotlin.plugin.serialization") version "2.1.20" apply false
    id("com.google.devtools.ksp") version "2.1.20-2.0.1" apply false
    id("com.google.dagger.hilt.android") version "2.56" apply false
}
