package com.example.inknotes.domain

import com.example.inknotes.domain.model.EditAction

/** Bounded undo/redo history. Spec asks for >= 100 steps; default 200. */
class UndoRedoStack(private val limit: Int = 200) {
    private val undoStack = ArrayDeque<EditAction>()
    private val redoStack = ArrayDeque<EditAction>()

    val canUndo get() = undoStack.isNotEmpty()
    val canRedo get() = redoStack.isNotEmpty()

    fun push(a: EditAction) {
        undoStack.addLast(a)
        if (undoStack.size > limit) undoStack.removeFirst()
        redoStack.clear()
    }

    fun undo(): EditAction? = undoStack.removeLastOrNull()?.also { redoStack.addLast(it) }
    fun redo(): EditAction? = redoStack.removeLastOrNull()?.also { undoStack.addLast(it) }
}
