package com.example.inknotes.ui.editor

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.roundToInt

/**
 * An imported PDF shown as a vertical stack of pages (page space: width PAGE_W, small gap between pages).
 * Pages are rendered lazily at the resolution needed for the current zoom, only for pages near the viewport,
 * so big PDFs do not eat memory. Ink is drawn on top by the ink view (same coordinates).
 */
class PdfPages(file: File) {
    private val pfd: ParcelFileDescriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    private val renderer = PdfRenderer(pfd)
    private val lock = Any()
    @Volatile private var closed = false

    val pageCount: Int = renderer.pageCount

    var tops: FloatArray = FloatArray(0)
        private set
    var heights: FloatArray = FloatArray(0)
        private set

    /** Page-space height of the whole document; 0 until the layout has been measured. */
    var contentHeight by mutableFloatStateOf(0f)
        private set

    /** Bumped whenever a page bitmap arrives, so the canvas redraws. */
    var version by mutableIntStateOf(0)
        private set

    private val cache = HashMap<Int, Pair<Bitmap, Int>>()      // page -> (bitmap, pixel width)

    suspend fun loadLayout(pageW: Float, gap: Float = 24f) {
        val sizes = withContext(Dispatchers.Default) {
            (0 until pageCount).map { i ->
                synchronized(lock) {
                    if (closed) return@synchronized 1 to 1
                    val p = renderer.openPage(i)
                    try { p.width to p.height } finally { p.close() }
                }
            }
        }
        val t = FloatArray(pageCount)
        val h = FloatArray(pageCount)
        var y = 0f
        for (i in 0 until pageCount) {
            t[i] = y
            h[i] = pageW * sizes[i].second / sizes[i].first.coerceAtLeast(1)
            y += h[i] + gap
        }
        tops = t
        heights = h
        contentHeight = y
    }

    /** Pages intersecting [topY, bottomY] in page space. */
    fun visibleRange(topY: Float, bottomY: Float): IntRange? {
        if (tops.isEmpty()) return null
        var first = -1
        var last = -1
        for (i in tops.indices) {
            if (tops[i] + heights[i] >= topY && tops[i] <= bottomY) {
                if (first == -1) first = i
                last = i
            }
        }
        return if (first == -1) null else first..last
    }

    fun bitmap(page: Int): Bitmap? = synchronized(cache) { cache[page]?.first }

    /** Renders the given pages (visible first) at [widthPx] if not already available at that quality. */
    suspend fun ensure(pages: List<Int>, widthPx: Int, keepFrom: Int, keepTo: Int) {
        withContext(Dispatchers.Default) {
            for (i in pages) {
                if (closed) return@withContext
                val have = synchronized(cache) { cache[i] }
                if (have != null && have.second >= widthPx) continue
                val bmp = render(i, widthPx) ?: continue
                synchronized(cache) {
                    cache[i] = bmp to widthPx
                    // keep only pages near the viewport (bitmaps are released by GC, never recycled while Compose may draw them)
                    cache.keys.retainAll { it in (keepFrom - 1)..(keepTo + 1) }
                }
                withContext(Dispatchers.Main) { version += 1 }
            }
        }
    }

    private fun render(i: Int, widthPx: Int): Bitmap? = synchronized(lock) {
        if (closed) return null
        val page = renderer.openPage(i)
        try {
            val h = (widthPx.toFloat() * page.height / page.width).roundToInt().coerceAtLeast(1)
            val bmp = Bitmap.createBitmap(widthPx, h, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(Color.WHITE)
            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            bmp
        } finally { page.close() }
    }

    fun close() {
        closed = true
        synchronized(lock) { runCatching { renderer.close() }; runCatching { pfd.close() } }
        synchronized(cache) { cache.clear() }
    }
}
