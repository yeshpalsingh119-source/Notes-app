package com.example.inknotes.domain.model

import kotlinx.serialization.Serializable

/** Photo on the page. x/y/w/h in page px (top-left + size), rotation in degrees, z = layer order. */
@Serializable
data class ImageItem(
    val id: String,
    val file: String,
    val x: Float,
    val y: Float,
    val w: Float,
    val h: Float,
    val rotation: Float = 0f,
    val z: Int = 0
)
