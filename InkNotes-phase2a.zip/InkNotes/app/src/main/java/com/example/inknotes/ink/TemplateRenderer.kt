package com.example.inknotes.ink

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import com.example.inknotes.domain.model.PageTemplate
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/** Width of a page in page-space px (the grey desk is shown left/right of it, like Samsung Notes). */
const val PAGE_W = 1584f

object TemplateRenderer {
    private val fill = Paint()
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 1f }

    fun drawDesk(c: Canvas, v: RectF, desk: Int) {
        fill.color = desk
        c.drawRect(v, fill)
    }

    /** Paper + template lines for the visible part of the page ([0, PAGE_W] horizontally, endless vertically). */
    fun draw(c: Canvas, t: PageTemplate, v: RectF, paper: Int, ink: Int, zoom: Float, desk: Int) {
        drawDesk(c, v, desk)
        val page = RectF(max(v.left, 0f), v.top, min(v.right, PAGE_W), v.bottom)
        if (page.width() <= 0f) return
        fill.color = paper
        c.drawRect(page, fill)
        line.color = ink
        line.alpha = 0x30
        line.strokeWidth = 1f / zoom.coerceAtLeast(0.1f)
        when (t) {
            PageTemplate.BLANK -> Unit
            PageTemplate.RULED_NARROW -> horizontal(c, page, 28f)
            PageTemplate.RULED_MEDIUM -> horizontal(c, page, 36f)
            PageTemplate.RULED_WIDE -> horizontal(c, page, 48f)
            PageTemplate.GRID -> { horizontal(c, page, 36f); vertical(c, page, 36f) }
            PageTemplate.DOTTED -> dots(c, page, 36f, 1.6f / zoom.coerceAtLeast(0.1f))
        }
    }

    private fun horizontal(c: Canvas, v: RectF, step: Float) {
        var y = floor(v.top / step) * step
        while (y <= v.bottom) { c.drawLine(v.left, y, v.right, y, line); y += step }
    }

    private fun vertical(c: Canvas, v: RectF, step: Float) {
        var x = floor(v.left / step) * step
        while (x <= v.right) { c.drawLine(x, v.top, x, v.bottom, line); x += step }
    }

    private fun dots(c: Canvas, v: RectF, step: Float, r: Float) {
        var y = floor(v.top / step) * step
        while (y <= v.bottom) {
            var x = floor(v.left / step) * step
            while (x <= v.right) { c.drawCircle(x, y, r, line); x += step }
            y += step
        }
    }
}
