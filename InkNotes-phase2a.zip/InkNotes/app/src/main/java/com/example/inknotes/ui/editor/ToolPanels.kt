package com.example.inknotes.ui.editor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import com.example.inknotes.domain.model.PenType
import com.example.inknotes.domain.model.Tool
import kotlin.math.roundToInt

enum class PanelKind { PEN, HIGHLIGHTER, ERASER }

private val palette = listOf(0xFFFFE15D, 0xFFF0526B, 0xFF6ADE8F, 0xFF7086F7, 0xFFDDDDDD, 0xFF5A5A5A, 0xFFFFC107, 0xFF34D26A)
    .map { it.toInt() }

// =============================================================== bottom toolbar (Samsung Notes style)
@Composable
fun DrawToolbar(
    pen: PenState,
    history: HistoryState,
    onToolTap: (Tool) -> Unit,
    onText: () -> Unit,
    onPhoto: () -> Unit,
    onColor: (Int) -> Unit,
    onThickness: () -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit
) {
    val onSurface = MaterialTheme.colorScheme.onSurface
    Surface(tonalElevation = 3.dp, shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)) {
        Row(
            Modifier.navigationBarsPadding().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            ToolButton(false, onText) { Icon(Icons.Default.Keyboard, "Text") }
            ToolButton(pen.tool == Tool.PEN, { onToolTap(Tool.PEN) }) {
                ToolGlyph(Glyph.PEN, onSurface, Color(pen.settings[pen.pen]?.color ?: 0xFF7086F7.toInt()))
            }
            ToolButton(pen.tool == Tool.HIGHLIGHTER, { onToolTap(Tool.HIGHLIGHTER) }) {
                ToolGlyph(Glyph.HIGHLIGHTER, onSurface, Color(pen.settings[pen.highlighter]?.color ?: 0xFFFDE047.toInt()))
            }
            ToolButton(pen.tool == Tool.ERASER, { onToolTap(Tool.ERASER) }) { ToolGlyph(Glyph.ERASER, onSurface, Color(0xFFF48F8A)) }
            ToolButton(pen.tool == Tool.SELECT, { onToolTap(Tool.SELECT) }) { ToolGlyph(Glyph.LASSO, onSurface, onSurface) }
            ToolButton(false, onPhoto) { Icon(Icons.Default.Image, "Photo") }
            BarDivider()
            pen.recentColors.forEach { c -> ColorDot(c, c == pen.active.color) { onColor(c) } }
            ToolButton(false, onThickness) {
                Box(
                    Modifier.width(26.dp).height((2f + pen.active.size / 14f).dp)
                        .clip(CircleShape).background(onSurface)
                )
            }
            BarDivider()
            ToolButton(false, onUndo, enabled = history.canUndo) { Icon(Icons.AutoMirrored.Filled.Undo, "Undo") }
            ToolButton(false, onRedo, enabled = history.canRedo) { Icon(Icons.AutoMirrored.Filled.Redo, "Redo") }
        }
    }
}

@Composable
private fun BarDivider() {
    Box(Modifier.padding(horizontal = 6.dp).width(1.dp).height(24.dp).background(MaterialTheme.colorScheme.outlineVariant))
}

@Composable
fun ToolButton(selected: Boolean, onClick: () -> Unit, enabled: Boolean = true, content: @Composable () -> Unit) {
    Box(
        Modifier.size(44.dp).clip(CircleShape)
            .background(if (selected) MaterialTheme.colorScheme.surfaceVariant else Color.Transparent)
            .alpha(if (enabled) 1f else 0.35f)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) { content() }
}

@Composable
private fun ColorDot(color: Int, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.padding(horizontal = 4.dp).size(28.dp).clip(CircleShape).background(Color(color))
            .border(if (selected) 3.dp else 1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant, CircleShape)
            .clickable(onClick = onClick)
    )
}

// =============================================================== tool glyphs
enum class Glyph { PEN, HIGHLIGHTER, ERASER, LASSO }

@Composable
fun ToolGlyph(g: Glyph, tint: Color, accent: Color, modifier: Modifier = Modifier.size(28.dp)) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val sw = 2.2f.dp.toPx()
        when (g) {
            Glyph.PEN, Glyph.HIGHLIGHTER -> rotate(40f, center) {
                val bw = w * 0.30f
                val l = center.x - bw / 2f
                drawRoundRect(tint, Offset(l, h * 0.05f), Size(bw, h * 0.62f), CornerRadius(3f.dp.toPx()), style = Stroke(sw))
                val tip = Path().apply {
                    moveTo(l, h * 0.70f); lineTo(l + bw, h * 0.70f)
                    lineTo(if (g == Glyph.PEN) center.x else l + bw * 0.8f, h * 0.96f)
                    lineTo(if (g == Glyph.PEN) center.x else l + bw * 0.2f, h * 0.96f)
                    close()
                }
                if (g == Glyph.HIGHLIGHTER) drawPath(tip, accent) else drawPath(tip, tint, style = Stroke(sw, join = StrokeJoin.Round))
                drawRect(accent, Offset(l, h * 0.40f), Size(bw, h * 0.12f))
            }
            Glyph.ERASER -> rotate(-40f, center) {
                val bw = w * 0.42f
                val l = center.x - bw / 2f
                drawRoundRect(tint, Offset(l, h * 0.12f), Size(bw, h * 0.76f), CornerRadius(4f.dp.toPx()), style = Stroke(sw))
                drawRoundRect(accent, Offset(l, h * 0.50f), Size(bw, h * 0.38f), CornerRadius(4f.dp.toPx()))
            }
            Glyph.LASSO -> drawOval(
                tint, Offset(w * 0.12f, h * 0.2f), Size(w * 0.76f, h * 0.6f),
                style = Stroke(sw, pathEffect = PathEffect.dashPathEffect(floatArrayOf(7.dp.toPx(), 5.dp.toPx())))
            )
        }
    }
}

// =============================================================== floating panel (Dialog = always above the ink surface)
@Composable
fun ToolPanelDialog(
    kind: PanelKind,
    pen: PenState,
    update: ((PenState) -> PenState) -> Unit,
    onClearAll: () -> Unit,
    onPickColor: () -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        val window = (LocalView.current.parent as? DialogWindowProvider)?.window
        SideEffect { window?.setDimAmount(0f) }
        val none = remember { MutableInteractionSource() }
        Box(
            Modifier.fillMaxSize().clickable(interactionSource = none, indication = null, onClick = onDismiss),
            contentAlignment = Alignment.BottomCenter
        ) {
            Card(
                Modifier.padding(bottom = 96.dp).fillMaxWidth(0.94f).widthIn(max = 460.dp)
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { },
                shape = RoundedCornerShape(32.dp),
                elevation = CardDefaults.cardElevation(8.dp)
            ) {
                Column(Modifier.padding(horizontal = 20.dp, vertical = 12.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        IconButton(onDismiss) { Icon(Icons.Default.Close, "Close") }
                    }
                    when (kind) {
                        PanelKind.ERASER -> EraserContent(pen, update, onClearAll)
                        else -> PenContent(kind, pen, update, onPickColor)
                    }
                }
            }
        }
    }
}

@Composable
private fun PenContent(kind: PanelKind, pen: PenState, update: ((PenState) -> PenState) -> Unit, onPickColor: () -> Unit) {
    val types = if (kind == PanelKind.PEN) {
        listOf(PenType.FOUNTAIN, PenType.CALLIGRAPHY, PenType.BALLPOINT, PenType.PENCIL, PenType.WATERCOLOR, PenType.BRUSH)
    } else listOf(PenType.HIGHLIGHTER, PenType.HIGHLIGHTER_ROUND)
    val current = pen.activeType

    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        types.forEach { t ->
            val col = Color(pen.settings[t]?.color ?: 0xFF7086F7.toInt())
            Column(
                Modifier.clip(RoundedCornerShape(16.dp)).clickable { update { it.withPen(t) } },
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                PenIllustration(t, col, t == current, Modifier.width(58.dp).height(150.dp))
                Text(t.label, style = MaterialTheme.typography.labelSmall, maxLines = 1)
            }
        }
    }
    HorizontalDivider(Modifier.padding(vertical = 8.dp))

    val size = pen.active.size
    Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton({ update { it.withSize(it.active.size - 1f) } }) { Icon(Icons.Default.Remove, "Thinner") }
        Slider(
            value = size, onValueChange = { v -> update { it.withSize(v) } },
            valueRange = 1f..100f, modifier = Modifier.weight(1f),
            thumb = {
                Surface(shape = CircleShape, shadowElevation = 4.dp, modifier = Modifier.size(44.dp)) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("${size.roundToInt()}") }
                }
            }
        )
        IconButton({ update { it.withSize(it.active.size + 1f) } }) { Icon(Icons.Default.Add, "Thicker") }
    }

    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("Straighten lines", Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
        Switch(pen.straighten, { v -> update { it.copy(straighten = v) } })
    }
    Text("Hold the pen still at the end of a line for 0.5 s", style = MaterialTheme.typography.labelSmall, modifier = Modifier.alpha(0.6f))

    Row(Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        palette.forEach { c ->
            Box(
                Modifier.size(30.dp).clip(CircleShape).background(Color(c)).clickable { update { it.withColor(c) } },
                contentAlignment = Alignment.Center
            ) {
                if (pen.active.color == c) Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(18.dp))
            }
        }
        Box(
            Modifier.size(30.dp).clip(CircleShape)
                .background(Brush.sweepGradient(listOf(Color.Red, Color.Yellow, Color.Green, Color.Cyan, Color.Blue, Color.Magenta, Color.Red)))
                .clickable(onClick = onPickColor)
        )
    }
}

@Composable
private fun EraserContent(pen: PenState, update: ((PenState) -> PenState) -> Unit, onClearAll: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("Erase highlighter only", Modifier.weight(1f))
        Switch(pen.eraseHighlighterOnly, { v -> update { it.copy(eraseHighlighterOnly = v) } })
    }
    Text("Touch a stroke with the eraser to remove the whole stroke.", style = MaterialTheme.typography.labelSmall, modifier = Modifier.alpha(0.6f))
    TextButton(onClearAll, Modifier.padding(top = 8.dp)) { Text("Clear all handwriting") }
}

// =============================================================== colour picker (HSV)
@Composable
fun ColorPickerDialog(initial: Int, onDismiss: () -> Unit, onPick: (Int) -> Unit) {
    val hsv = remember { FloatArray(3).also { android.graphics.Color.colorToHSV(initial, it) } }
    var h by remember { mutableFloatStateOf(hsv[0]) }
    var s by remember { mutableFloatStateOf(hsv[1]) }
    var v by remember { mutableFloatStateOf(hsv[2]) }
    val argb = android.graphics.Color.HSVToColor(floatArrayOf(h, s, v))
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Custom colour") },
        text = {
            Column {
                Box(Modifier.fillMaxWidth().height(48.dp).clip(RoundedCornerShape(12.dp)).background(Color(argb)))
                Text("Hue"); Slider(h, { h = it }, valueRange = 0f..360f)
                Text("Saturation"); Slider(s, { s = it })
                Text("Brightness"); Slider(v, { v = it })
            }
        },
        confirmButton = { TextButton({ onPick(argb) }) { Text("Select") } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } }
    )
}

// =============================================================== pen illustrations (like the Samsung panel)
@Composable
private fun PenIllustration(type: PenType, color: Color, selected: Boolean, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val top = size.height * 0.24f
        val ph = size.height - top
        fun y(f: Float) = top + ph * f
        val cx = w / 2f
        val bw = w * 0.5f
        val bl = cx - bw / 2f
        val metal = Color(0xFFDADCE2)
        val dark = Color(0xFF3A3A40)
        val hair = 1.5f.dp.toPx()

        if (selected) {
            val wave = Path().apply {
                moveTo(w * 0.12f, top * 0.75f)
                cubicTo(w * 0.30f, top * 0.05f, w * 0.45f, top * 0.95f, w * 0.65f, top * 0.40f)
                cubicTo(w * 0.75f, top * 0.15f, w * 0.88f, top * 0.45f, w * 0.92f, top * 0.30f)
            }
            drawPath(wave, color, style = Stroke(width = 5.dp.toPx(), cap = StrokeCap.Round))
        }
        drawRoundRect(color, Offset(bl, y(0.46f)), Size(bw, ph * 0.54f), CornerRadius(bw * 0.28f))
        drawRect(Color.White.copy(alpha = 0.92f), Offset(bl, y(0.70f)), Size(bw, ph * 0.07f))

        when (type) {
            PenType.FOUNTAIN, PenType.CALLIGRAPHY -> {
                val peak = if (type == PenType.CALLIGRAPHY) cx + bw * 0.22f else cx
                val nib = Path().apply {
                    moveTo(bl + bw * 0.08f, y(0.46f)); lineTo(peak, y(0.04f)); lineTo(bl + bw * 0.92f, y(0.46f)); close()
                }
                drawPath(nib, metal)
                drawPath(nib, dark.copy(alpha = 0.5f), style = Stroke(hair))
                drawLine(dark, Offset(peak, y(0.2f)), Offset(cx, y(0.46f)), strokeWidth = hair)
            }
            PenType.BALLPOINT -> {
                val cone = Path().apply {
                    moveTo(bl + bw * 0.1f, y(0.46f)); lineTo(cx - bw * 0.1f, y(0.10f))
                    lineTo(cx + bw * 0.1f, y(0.10f)); lineTo(bl + bw * 0.9f, y(0.46f)); close()
                }
                drawPath(cone, Color(0xFFF2F3F7))
                drawPath(cone, dark.copy(alpha = 0.4f), style = Stroke(hair))
                drawCircle(color, bw * 0.08f, Offset(cx, y(0.08f)))
            }
            PenType.PENCIL -> {
                val wood = Path().apply {
                    moveTo(bl + bw * 0.04f, y(0.46f)); lineTo(cx, y(0.12f)); lineTo(bl + bw * 0.96f, y(0.46f)); close()
                }
                drawPath(wood, Color(0xFFF3D9B1))
                val lead = Path().apply {
                    moveTo(cx - bw * 0.14f, y(0.26f)); lineTo(cx, y(0.10f)); lineTo(cx + bw * 0.14f, y(0.26f)); close()
                }
                drawPath(lead, color)
            }
            PenType.WATERCOLOR, PenType.BRUSH -> {
                drawRect(metal, Offset(bl, y(0.36f)), Size(bw, y(0.46f) - y(0.36f)))
                val bristle = Path().apply {
                    moveTo(bl + bw * 0.06f, y(0.36f))
                    if (type == PenType.WATERCOLOR) quadraticBezierTo(cx, y(-0.02f), bl + bw * 0.94f, y(0.36f))
                    else { cubicTo(bl, y(0.10f), bl + bw, y(0.10f), bl + bw * 0.94f, y(0.36f)) }
                    close()
                }
                drawPath(bristle, color.copy(alpha = 0.9f))
            }
            PenType.HIGHLIGHTER, PenType.HIGHLIGHTER_ROUND -> {
                val tip = Path().apply {
                    moveTo(bl + bw * 0.04f, y(0.46f)); lineTo(bl + bw * 0.22f, y(0.12f))
                    lineTo(bl + bw * 0.78f, y(0.12f)); lineTo(bl + bw * 0.96f, y(0.46f)); close()
                }
                drawPath(tip, color)
                if (type == PenType.HIGHLIGHTER_ROUND) drawCircle(color, bw * 0.28f, Offset(cx, y(0.12f)))
            }
        }
    }
}
