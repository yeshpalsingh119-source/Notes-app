package com.example.inknotes.ui.editor

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.example.inknotes.domain.model.BlockKind
import com.example.inknotes.domain.model.ImageItem
import com.example.inknotes.domain.model.PageTemplate
import com.example.inknotes.domain.model.Stroke
import com.example.inknotes.domain.model.TextBlock
import com.example.inknotes.ink.PAGE_W
import com.example.inknotes.ink.StrokeRenderer
import com.example.inknotes.ink.TemplateRenderer
import java.io.File
import java.io.FileOutputStream
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Renders a note (paper, PDF pages, photos, text, handwriting) to a PNG or a multi-page vector PDF. */
object Exporter {

    class Input(
        val strokes: List<Stroke>,
        val blocks: List<TextBlock>,
        val images: List<ImageItem>,
        val imageFile: (String) -> File,
        val template: PageTemplate,
        val paper: Int,
        val ink: Int,
        val density: Float,
        val pdf: PdfPages?
    )

    private class TextItem(val layout: StaticLayout, val x: Float, val y: Float, val block: TextBlock)

    private fun exportsDir(ctx: Context) = File(ctx.cacheDir, "exports").also { it.mkdirs() }

    // ------------------------------------------------------------------ layout
    private fun layoutText(inp: Input): List<TextItem> {
        val d = inp.density
        val items = ArrayList<TextItem>()
        var y = 16f * d
        for (b in inp.blocks) {
            val indent = (b.indent * 24f + if (b.kind == BlockKind.PARAGRAPH) 0f else 28f) * d
            val x = 24f * d + indent
            val w = (PAGE_W - x - 24f * d).toInt().coerceAtLeast(100)
            val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = b.sizeSp * d
                color = if (b.colorArgb != 0) b.colorArgb else inp.ink
                isFakeBoldText = b.bold
                isUnderlineText = b.underline
                isStrikeThruText = b.strike || (b.kind == BlockKind.CHECKLIST && b.checked)
                textSkewX = if (b.italic) -0.25f else 0f
            }
            val align = when (b.align) {
                1 -> Layout.Alignment.ALIGN_CENTER
                2 -> Layout.Alignment.ALIGN_OPPOSITE
                else -> Layout.Alignment.ALIGN_NORMAL
            }
            val text = b.text.ifEmpty { " " }
            val layout = StaticLayout.Builder.obtain(text, 0, text.length, tp, w).setAlignment(align).build()
            items.add(TextItem(layout, x, y, b))
            y += layout.height + 4f * d
        }
        return items
    }

    private fun contentBottom(inp: Input, items: List<TextItem>): Float {
        var b = 0f
        for (s in inp.strokes) for (p in s.points) b = max(b, p.y + s.width)
        for (im in inp.images) b = max(b, im.y + im.h)
        for (t in items) if (t.block.text.isNotBlank()) b = max(b, t.y + t.layout.height)
        return b
    }

    // ------------------------------------------------------------------ drawing (page space)
    private fun drawContent(c: Canvas, inp: Input, items: List<TextItem>, visible: RectF, paperAndTemplate: Boolean, vector: Boolean) {
        if (paperAndTemplate) {
            TemplateRenderer.draw(c, inp.template, visible, inp.paper, inp.ink, 1f, inp.paper)
        }
        val paint = Paint(Paint.FILTER_BITMAP_FLAG)
        for (im in inp.images.sortedBy { it.z }) {
            if (!RectF.intersects(RectF(im.x, im.y, im.x + im.w, im.y + im.h), visible)) continue
            val bmp = BitmapFactory.decodeFile(inp.imageFile(im.file).path) ?: continue
            c.save()
            c.rotate(im.rotation, im.x + im.w / 2f, im.y + im.h / 2f)
            c.drawBitmap(bmp, null, RectF(im.x, im.y, im.x + im.w, im.y + im.h), paint)
            c.restore()
            bmp.recycle()
        }
        val d = inp.density
        val mark = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = inp.ink; style = Paint.Style.STROKE; strokeWidth = 2f * d }
        for (t in items) {
            if (t.y + t.layout.height < visible.top || t.y > visible.bottom) continue
            val b = t.block
            c.save()
            c.translate(t.x, t.y)
            if (b.highlightArgb != 0) {
                val hp = Paint().apply { color = b.highlightArgb; alpha = 120 }
                c.drawRect(0f, 0f, t.layout.width.toFloat(), t.layout.height.toFloat(), hp)
            }
            t.layout.draw(c)
            c.restore()
            val base = t.y + t.layout.getLineBaseline(0)
            when (b.kind) {
                BlockKind.BULLET -> c.drawCircle(t.x - 14f * d, base - b.sizeSp * d * 0.3f, 3.5f * d, mark.apply { style = Paint.Style.FILL })
                BlockKind.CHECKLIST -> {
                    mark.style = Paint.Style.STROKE
                    val s = 15f * d
                    val left = t.x - 26f * d
                    val top = base - s
                    c.drawRect(left, top, left + s, top + s, mark)
                    if (b.checked) { c.drawLine(left + 3f * d, top + s / 2f, left + s * 0.42f, top + s - 3f * d, mark); c.drawLine(left + s * 0.42f, top + s - 3f * d, left + s - 2f * d, top + 3f * d, mark) }
                }
                BlockKind.PARAGRAPH -> Unit
            }
        }
        val r = StrokeRenderer(!vector)               // real Multiply for highlighters on bitmaps, plain alpha in PDF
        for (s in inp.strokes) r.draw(c, s)
    }

    // ------------------------------------------------------------------ PNG
    fun png(ctx: Context, name: String, inp: Input): File {
        val items = layoutText(inp)
        val pdf = inp.pdf
        val height = if (pdf != null && pdf.contentHeight > 0f) pdf.contentHeight else max(contentBottom(inp, items) + 80f, 1100f)
        val k = min(1.5f, 7000f / height)
        val bmp = Bitmap.createBitmap((PAGE_W * k).roundToInt(), (height * k).roundToInt(), Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.scale(k, k)
        c.drawColor(inp.paper)
        val visible = RectF(0f, 0f, PAGE_W, height)
        if (pdf != null && pdf.contentHeight > 0f) {
            for (i in 0 until pdf.pageCount) {
                val pb = pdf.renderPage(i, (PAGE_W * k).roundToInt()) ?: continue
                c.drawBitmap(pb, null, RectF(0f, pdf.tops[i], PAGE_W, pdf.tops[i] + pdf.heights[i]), null)
                pb.recycle()
            }
            drawContent(c, inp, items, visible, false, false)
        } else {
            drawContent(c, inp, items, visible, true, false)
        }
        val file = File(exportsDir(ctx), "$name.png")
        FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        bmp.recycle()
        return file
    }

    // ------------------------------------------------------------------ PDF (vector strokes, A4 slices; PDF notes keep their pages)
    fun pdf(ctx: Context, name: String, inp: Input): File {
        val items = layoutText(inp)
        val doc = PdfDocument()
        val src = inp.pdf
        if (src != null && src.contentHeight > 0f) {
            for (i in 0 until src.pageCount) {
                val h = src.heights[i]
                val ptsH = (595f * h / PAGE_W).roundToInt().coerceAtLeast(100)
                val page = doc.startPage(PdfDocument.PageInfo.Builder(595, ptsH, i + 1).create())
                val c = page.canvas
                val k = 595f / PAGE_W
                c.scale(k, k)
                c.translate(0f, -src.tops[i])
                c.clipRect(0f, src.tops[i], PAGE_W, src.tops[i] + h)
                val pb = src.renderPage(i, 1500)
                if (pb != null) { c.drawBitmap(pb, null, RectF(0f, src.tops[i], PAGE_W, src.tops[i] + h), null); pb.recycle() }
                drawContent(c, inp, items, RectF(0f, src.tops[i], PAGE_W, src.tops[i] + h), false, true)
                doc.finishPage(page)
            }
        } else {
            val sliceH = PAGE_W * 842f / 595f
            val pages = max(1, ceil(contentBottom(inp, items) / sliceH).toInt())
            for (i in 0 until pages) {
                val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, i + 1).create())
                val c = page.canvas
                val k = 595f / PAGE_W
                c.scale(k, k)
                c.translate(0f, -i * sliceH)
                val visible = RectF(0f, i * sliceH, PAGE_W, (i + 1) * sliceH)
                c.clipRect(visible)
                drawContent(c, inp, items, visible, true, true)
                doc.finishPage(page)
            }
        }
        val file = File(exportsDir(ctx), "$name.pdf")
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        return file
    }
}
