package com.example.inknotes

import android.app.Application
import android.util.Log
import dagger.hilt.android.HiltAndroidApp
import java.io.File

@HiltAndroidApp
class NotesApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Any crash (also on the ink render thread) is saved to a file; the home screen shows it on next launch.
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, e ->
            runCatching {
                File(filesDir, CRASH_FILE).writeText("thread: ${thread.name}\n" + Log.getStackTraceString(e))
            }
            previous?.uncaughtException(thread, e)
        }
    }

    companion object { const val CRASH_FILE = "last_crash.txt" }
}
