package com.example.inknotes.domain.model

import kotlinx.serialization.KSerializer
import kotlinx.serialization.Serializable
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.builtins.serializer
import kotlinx.serialization.descriptors.SerialDescriptor
import kotlinx.serialization.encoding.Decoder
import kotlinx.serialization.encoding.Encoder
import kotlin.math.roundToInt

/** Page-space coordinates (independent of zoom/pan). tMs = ms since stroke start (for audio sync later). */
data class StrokePoint(
    val x: Float, val y: Float,
    val pressure: Float, val tilt: Float, val orientation: Float,
    val tMs: Long
)

/** Points are stored as ONE flat number array (6 values per point, 2 decimals) -> ~4x smaller JSON. */
object PointsSerializer : KSerializer<List<StrokePoint>> {
    private val delegate = ListSerializer(Float.serializer())
    override val descriptor: SerialDescriptor = delegate.descriptor

    private fun r2(v: Float): Float = if (v.isFinite()) (v * 100f).roundToInt() / 100f else 0f

    override fun serialize(encoder: Encoder, value: List<StrokePoint>) {
        val flat = ArrayList<Float>(value.size * 6)
        for (p in value) {
            flat.add(r2(p.x)); flat.add(r2(p.y)); flat.add(r2(p.pressure))
            flat.add(r2(p.tilt)); flat.add(r2(p.orientation)); flat.add(p.tMs.toFloat())
        }
        encoder.encodeSerializableValue(delegate, flat)
    }

    override fun deserialize(decoder: Decoder): List<StrokePoint> {
        val flat = decoder.decodeSerializableValue(delegate)
        val out = ArrayList<StrokePoint>(flat.size / 6)
        var i = 0
        while (i + 5 < flat.size) {
            out.add(StrokePoint(flat[i], flat[i + 1], flat[i + 2], flat[i + 3], flat[i + 4], flat[i + 5].toLong()))
            i += 6
        }
        return out
    }
}

@Serializable
enum class PenType(val label: String, val isHighlighter: Boolean = false) {
    FOUNTAIN("Fountain"),
    CALLIGRAPHY("Calligraphy"),
    BALLPOINT("Ballpoint"),
    PENCIL("Pencil"),
    WATERCOLOR("Watercolor"),
    BRUSH("Brush"),
    HIGHLIGHTER("Highlighter", true),          // flat chisel ends
    HIGHLIGHTER_ROUND("Round tip", true)
}

@Serializable
data class Stroke(
    val id: String,
    val pen: PenType,
    val colorArgb: Int,
    val width: Float,
    @Serializable(with = PointsSerializer::class) val points: List<StrokePoint>,
    val recordingId: String? = null,       // Phase 3: audio sync
    val recordingOffsetMs: Long? = null,
    val lineStyle: Int = 0                  // LineStyle.*
)

/** Pen line styles (like the Samsung panel): solid, tapered ends, dashed, dotted. */
object LineStyle { const val SOLID = 0; const val TAPER = 1; const val DASH = 2; const val DOT = 3 }

enum class Tool { PEN, HIGHLIGHTER, ERASER, SELECT, SHAPE }

enum class ShapeKind(val label: String) { LINE("Line"), RECT("Rectangle"), ELLIPSE("Circle"), TRIANGLE("Triangle"), ARROW("Arrow") }

enum class PageTemplate { BLANK, RULED_NARROW, RULED_MEDIUM, RULED_WIDE, GRID, DOTTED, CORNELL, MUSIC }

sealed interface EditAction {
    data class Add(val strokes: List<Stroke>) : EditAction
    data class Remove(val strokes: List<Stroke>) : EditAction
    /** Selection move / scale / recolour: [before] strokes are swapped for [after] strokes. */
    data class Replace(val before: List<Stroke>, val after: List<Stroke>) : EditAction
}

/** (strokes to remove, strokes to add) for applying [a] forward or in reverse (undo). */
fun EditAction.removeAdd(reverse: Boolean): Pair<List<Stroke>, List<Stroke>> = when (this) {
    is EditAction.Add -> if (reverse) strokes to emptyList() else emptyList<Stroke>() to strokes
    is EditAction.Remove -> if (reverse) emptyList<Stroke>() to strokes else strokes to emptyList()
    is EditAction.Replace -> if (reverse) after to before else before to after
}
