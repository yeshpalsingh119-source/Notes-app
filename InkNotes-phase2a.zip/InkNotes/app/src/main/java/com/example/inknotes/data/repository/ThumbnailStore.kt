package com.example.inknotes.data.repository

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.text.TextPaint
import com.example.inknotes.domain.model.Stroke
import com.example.inknotes.domain.model.TextBlock
import com.example.inknotes.ink.PAGE_W
import com.example.inknotes.ink.StrokeRenderer
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.roundToInt

/** Small page previews for the home screen (PDF first page / handwriting / typed text). Own scope: survives leaving the editor. */
@Singleton
class ThumbnailStore @Inject constructor(@ApplicationContext private val ctx: Context) {
    private val dir = File(ctx.filesDir, "thumbs")
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    fun file(noteId: Long) = File(dir, "$noteId.jpg")

    fun saveNote(noteId: Long, paper: Int, strokes: List<Stroke>, blocks: List<TextBlock>, pdf: File?) {
        scope.launch { runCatching { render(noteId, paper, strokes, blocks, pdf) } }
    }

    fun savePdfThumb(noteId: Long, pdf: File) {
        scope.launch { runCatching { render(noteId, Color.WHITE, emptyList(), emptyList(), pdf) } }
    }

    private fun render(noteId: Long, paper: Int, strokes: List<Stroke>, blocks: List<TextBlock>, pdf: File?) {
        val w = 400
        val h = 560
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(paper)
        val k = w / PAGE_W
        if (pdf != null) drawPdfFirstPage(pdf, c, w)
        if (strokes.isNotEmpty()) {
            c.save()
            c.scale(k, k)
            val r = StrokeRenderer(false)
            for (s in strokes) r.draw(c, s)
            c.restore()
        }
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF333333.toInt() }
        var y = 48f * k * 2f
        for (b in blocks) {
            if (b.text.isBlank()) continue
            tp.textSize = (b.sizeSp * 2.2f * k).coerceAtLeast(9f)
            c.drawText(b.text.take(48), 60f * k, y, tp)
            y += tp.textSize * 1.6f
            if (y > h) break
        }
        dir.mkdirs()
        FileOutputStream(file(noteId)).use { bmp.compress(Bitmap.CompressFormat.JPEG, 86, it) }
        bmp.recycle()
    }

    private fun drawPdfFirstPage(pdf: File, c: Canvas, width: Int) {
        ParcelFileDescriptor.open(pdf, ParcelFileDescriptor.MODE_READ_ONLY).use { fd ->
            val r = PdfRenderer(fd)
            try {
                val page = r.openPage(0)
                try {
                    val hh = (width.toFloat() * page.height / page.width).roundToInt().coerceAtLeast(1)
                    val pb = Bitmap.createBitmap(width, hh, Bitmap.Config.ARGB_8888)
                    pb.eraseColor(Color.WHITE)
                    page.render(pb, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    c.drawBitmap(pb, 0f, 0f, null)
                    pb.recycle()
                } finally { page.close() }
            } finally { r.close() }
        }
    }
}
