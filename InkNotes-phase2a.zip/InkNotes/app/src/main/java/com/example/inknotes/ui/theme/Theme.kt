package com.example.inknotes.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/** One UI look: clean white surfaces, black text, blue accent, big rounded corners (no wallpaper-tinted colours). */
private val Light = lightColorScheme(
    primary = Color(0xFF3E91FF), onPrimary = Color.White,
    primaryContainer = Color(0xFFDCEBFF), onPrimaryContainer = Color(0xFF0B3A7A),
    secondaryContainer = Color(0xFFE6E6EA), onSecondaryContainer = Color(0xFF111111),
    background = Color(0xFFFCFCFD), onBackground = Color(0xFF111111),
    surface = Color(0xFFFCFCFD), onSurface = Color(0xFF111111),
    surfaceVariant = Color(0xFFEEEEF1), onSurfaceVariant = Color(0xFF55565A),
    surfaceContainerLowest = Color.White, surfaceContainerLow = Color(0xFFF7F7F9),
    surfaceContainer = Color(0xFFF3F3F6), surfaceContainerHigh = Color(0xFFEFEFF2), surfaceContainerHighest = Color(0xFFEBEBEF),
    outline = Color(0xFF9A9AA0), outlineVariant = Color(0xFFE2E2E6)
)

private val Dark = darkColorScheme(
    primary = Color(0xFF6FB0FF), onPrimary = Color(0xFF00305F),
    primaryContainer = Color(0xFF1F4A80), onPrimaryContainer = Color(0xFFD6E8FF),
    secondaryContainer = Color(0xFF2B2B30), onSecondaryContainer = Color(0xFFF2F2F5),
    background = Color(0xFF0B0B0C), onBackground = Color(0xFFF2F2F5),
    surface = Color(0xFF161618), onSurface = Color(0xFFF2F2F5),
    surfaceVariant = Color(0xFF2A2A2E), onSurfaceVariant = Color(0xFFB9B9C0),
    surfaceContainerLowest = Color(0xFF0B0B0C), surfaceContainerLow = Color(0xFF131315),
    surfaceContainer = Color(0xFF1B1B1E), surfaceContainerHigh = Color(0xFF222226), surfaceContainerHighest = Color(0xFF2A2A2E),
    outline = Color(0xFF808088), outlineVariant = Color(0xFF38383D)
)

@Composable
fun InkNotesTheme(dark: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (dark) Dark else Light,
        shapes = Shapes(
            small = RoundedCornerShape(12.dp),
            medium = RoundedCornerShape(20.dp),
            large = RoundedCornerShape(24.dp),
            extraLarge = RoundedCornerShape(32.dp)
        ),
        content = content
    )
}
