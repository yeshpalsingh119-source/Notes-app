package com.example.inknotes.ui.home

import android.graphics.BitmapFactory
import android.text.format.DateUtils
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.inknotes.NotesApp
import com.example.inknotes.data.db.NoteEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private val folderColors = listOf(0xFFE53935, 0xFFFB8C00, 0xFFFDD835, 0xFF43A047, 0xFF1E88E5, 0xFF8E24AA).map { it.toInt() }
private val coverBands = listOf(0xFF3F4A9E, 0xFF2E7D6B, 0xFFB5527A, 0xFFC27A2C).map { it.toInt() }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(onOpenNote: (Long) -> Unit, vm: HomeViewModel = hiltViewModel()) {
    val notes by vm.notes.collectAsStateWithLifecycle()
    val folders by vm.folders.collectAsStateWithLifecycle()
    val dest by vm.destination.collectAsStateWithLifecycle()
    val mode by vm.viewMode.collectAsStateWithLifecycle()
    val query by vm.query.collectAsStateWithLifecycle()

    val wide = LocalConfiguration.current.screenWidthDp >= 600
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var showNewFolder by remember { mutableStateOf(false) }
    var searching by remember { mutableStateOf(false) }

    // crash report from the previous run (written by NotesApp's handler)
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var crash by remember {
        mutableStateOf(File(context.filesDir, NotesApp.CRASH_FILE).takeIf { it.exists() }?.readText())
    }

    val pdfPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importPdf(uri, onOpenNote)
    }

    ModalNavigationDrawer(
        drawerContent = {
            ModalDrawerSheet {
                DrawerBody(
                    selected = dest, folders = folders,
                    onSelect = { vm.select(it); scope.launch { drawerState.close() } },
                    onNewFolder = { showNewFolder = true }
                )
            }
        },
        drawerState = drawerState
    ) {
        Row(Modifier.fillMaxSize()) {
            if (wide) {
                HomeRail(dest, onMenu = { scope.launch { drawerState.open() } }, onSelect = vm::select)
            }
            HomeContent(
                title = titleFor(dest, folders), wide = wide, notes = notes, mode = mode, query = query,
                searching = searching, trash = dest == Destination.Trash,
                thumbOf = vm::thumbFile,
                onMenu = { scope.launch { drawerState.open() } },
                onPdf = { pdfPicker.launch(arrayOf("application/pdf")) },
                onSearchToggle = { searching = !searching; if (!searching) vm.setQuery("") },
                onQuery = vm::setQuery, onMode = vm::setViewMode,
                onOpen = onOpenNote, onNew = { vm.newNote(onOpenNote) },
                onPin = vm::togglePin, onTrash = vm::trash, onRestore = vm::restore,
                modifier = Modifier.weight(1f)
            )
        }
    }

    crash?.let { report ->
        AlertDialog(
            onDismissRequest = { },
            title = { Text("App crashed last time") },
            text = {
                Text(
                    report.take(3500), fontFamily = FontFamily.Monospace, fontSize = 11.sp,
                    modifier = Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState())
                )
            },
            confirmButton = { TextButton({ clipboard.setText(AnnotatedString(report)) }) { Text("Copy") } },
            dismissButton = {
                TextButton({ File(context.filesDir, NotesApp.CRASH_FILE).delete(); crash = null }) { Text("Close") }
            }
        )
    }

    if (showNewFolder) {
        NewFolderDialog(
            onDismiss = { showNewFolder = false },
            onCreate = { name -> vm.newFolder(name, folderColors[folders.size % folderColors.size]); showNewFolder = false }
        )
    }
}

private fun titleFor(d: Destination, folders: List<FolderRow>) = when (d) {
    Destination.All -> "All notes"
    Destination.Frequent -> "Frequently used"
    Destination.Locked -> "Locked notes"
    Destination.Trash -> "Trash"
    is Destination.Folder -> folders.firstOrNull { it.id == d.id }?.name ?: "Folder"
}

// ------------------------------------------------------------------ left rail (tablet)
@Composable
private fun HomeRail(selected: Destination, onMenu: () -> Unit, onSelect: (Destination) -> Unit) {
    NavigationRail(
        containerColor = Color.Transparent,
        header = { IconButton(onMenu) { Icon(Icons.Default.Menu, "Menu") } }
    ) {
        NavigationRailItem(selected == Destination.All, { onSelect(Destination.All) }, { Icon(Icons.Default.Description, "All notes") })
        NavigationRailItem(selected == Destination.Locked, { onSelect(Destination.Locked) }, { Icon(Icons.Default.Lock, "Locked") })
        NavigationRailItem(selected == Destination.Frequent, { onSelect(Destination.Frequent) }, { Icon(Icons.Default.StarBorder, "Frequently used") })
        NavigationRailItem(selected == Destination.Trash, { onSelect(Destination.Trash) }, { Icon(Icons.Default.Delete, "Trash") })
        Spacer(Modifier.height(8.dp))
        NavigationRailItem(false, onMenu, { Icon(Icons.Default.Folder, "Folders") })
    }
}

// ------------------------------------------------------------------ content
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HomeContent(
    title: String, wide: Boolean, notes: List<NoteEntity>, mode: ViewMode, query: String,
    searching: Boolean, trash: Boolean, thumbOf: (Long) -> File,
    onMenu: () -> Unit, onPdf: () -> Unit, onSearchToggle: () -> Unit,
    onQuery: (String) -> Unit, onMode: (ViewMode) -> Unit,
    onOpen: (Long) -> Unit, onNew: () -> Unit,
    onPin: (NoteEntity) -> Unit, onTrash: (Long) -> Unit, onRestore: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    var modeMenu by remember { mutableStateOf(false) }

    Scaffold(
        modifier = modifier,
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            Column(Modifier.statusBarsPadding()) {
                Row(Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 12.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (!wide) IconButton(onMenu) { Icon(Icons.Default.Menu, "Menu") }
                    Text(
                        title, Modifier.weight(1f).padding(start = if (wide) 12.dp else 0.dp),
                        style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Medium
                    )
                    IconButton(onPdf) { Icon(Icons.Default.PictureAsPdf, "Import PDF") }
                    IconButton(onSearchToggle) { Icon(Icons.Default.Search, "Search") }
                    Box {
                        IconButton({ modeMenu = true }) { Icon(Icons.Default.MoreVert, "View") }
                        DropdownMenu(modeMenu, { modeMenu = false }) {
                            ViewMode.entries.forEach { m ->
                                DropdownMenuItem(text = { Text(m.label) }, onClick = { onMode(m); modeMenu = false })
                            }
                        }
                    }
                }
                if (searching) {
                    TextField(
                        value = query, onValueChange = onQuery, singleLine = true,
                        placeholder = { Text("Search title, text, tags") },
                        leadingIcon = { Icon(Icons.Default.Search, null) },
                        shape = RoundedCornerShape(50),
                        colors = TextFieldDefaults.colors(focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent),
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
                    )
                }
            }
        },
        floatingActionButton = {
            if (!trash) FloatingActionButton(
                onClick = onNew,
                containerColor = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(24.dp)
            ) { Icon(Icons.Default.Edit, "New note", tint = Color(0xFFE5484D)) }
        }
    ) { pad ->
        LazyVerticalGrid(
            columns = mode.minCell?.let { GridCells.Adaptive(it) } ?: GridCells.Fixed(1),
            modifier = Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (notes.isEmpty()) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Text(
                        if (searching && query.isNotBlank()) "No notes found" else "No notes yet - tap the pencil to start",
                        Modifier.fillMaxWidth().padding(48.dp).alpha(0.6f), textAlign = TextAlign.Center
                    )
                }
            }
            items(notes, key = { it.id }) { n ->
                NoteItem(n, mode, trash, thumbOf(n.id), { onOpen(n.id) }, { onPin(n) }, { onTrash(n.id) }, { onRestore(n.id) })
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun NoteItem(
    n: NoteEntity, mode: ViewMode, trash: Boolean, thumb: File,
    onOpen: () -> Unit, onPin: () -> Unit, onTrash: () -> Unit, onRestore: () -> Unit
) {
    var menu by remember { mutableStateOf(false) }
    val whenText = remember(n.updatedAt) { DateUtils.getRelativeTimeSpanString(n.updatedAt).toString() }
    val titleText = n.title.ifBlank { "Untitled note" }

    Box {
        when (mode) {
            ViewMode.SIMPLE_LIST -> Card(Modifier.fillMaxWidth().combinedClickable(onClick = onOpen, onLongClick = { menu = true })) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(titleText, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (n.isPinned) Icon(Icons.Default.PushPin, "Pinned", Modifier.size(16.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(whenText, style = MaterialTheme.typography.labelSmall)
                }
            }
            ViewMode.LIST -> Card(Modifier.fillMaxWidth().combinedClickable(onClick = onOpen, onLongClick = { menu = true })) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(width = 56.dp, height = 74.dp).clip(RoundedCornerShape(12.dp))) { NoteFace(n, thumb) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(titleText, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium)
                        Text(whenText, style = MaterialTheme.typography.labelSmall)
                    }
                    if (n.isPinned) Icon(Icons.Default.PushPin, "Pinned", Modifier.size(16.dp))
                }
            }
            else -> Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).combinedClickable(onClick = onOpen, onLongClick = { menu = true }),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(Modifier.fillMaxWidth().aspectRatio(0.76f).clip(RoundedCornerShape(20.dp))) {
                    NoteFace(n, thumb)
                    if (n.isPinned) Icon(Icons.Default.PushPin, "Pinned", Modifier.align(Alignment.TopStart).padding(8.dp).size(18.dp))
                }
                Text(
                    titleText, Modifier.padding(top = 8.dp), maxLines = 2, overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium
                )
                Text(whenText, style = MaterialTheme.typography.labelMedium, modifier = Modifier.alpha(0.6f))
            }
        }
        DropdownMenu(menu, { menu = false }) {
            if (trash) {
                DropdownMenuItem(text = { Text("Restore") }, onClick = { onRestore(); menu = false })
            } else {
                DropdownMenuItem(text = { Text(if (n.isPinned) "Unpin" else "Pin to top") }, onClick = { onPin(); menu = false })
                DropdownMenuItem(text = { Text("Move to trash") }, onClick = { onTrash(); menu = false })
            }
        }
    }
}

/** Page preview if the note has one, otherwise a book-style cover. Locked notes never show a preview. */
@Composable
private fun NoteFace(n: NoteEntity, thumb: File) {
    if (n.isLocked) {
        Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Lock, "Locked", Modifier.size(32.dp), tint = MaterialTheme.colorScheme.outline)
        }
        return
    }
    val bmp by produceState<ImageBitmap?>(null, n.id, n.updatedAt) {
        value = withContext(Dispatchers.IO) {
            if (thumb.exists()) BitmapFactory.decodeFile(thumb.path)?.asImageBitmap() else null
        }
    }
    val b = bmp
    if (b != null) {
        Image(b, null, Modifier.fillMaxSize().background(Color.White), contentScale = ContentScale.Crop, alignment = Alignment.TopCenter)
    } else {
        val band = Color(coverBands[(n.id % coverBands.size).toInt()])
        Box(Modifier.fillMaxSize().background(Color(0xFFF7EEEA))) {
            Box(Modifier.fillMaxWidth().fillMaxHeight(0.3f).background(band.copy(alpha = 0.85f)))
            Box(Modifier.width(8.dp).fillMaxHeight().background(Color(0x1F000000)))
            Box(
                Modifier.align(Alignment.TopEnd).padding(top = 14.dp).clip(RoundedCornerShape(topStart = 24.dp, bottomStart = 24.dp))
                    .background(Color.White).padding(horizontal = 20.dp, vertical = 8.dp)
            ) { Icon(Icons.Default.Description, null, tint = band) }
            Text(
                n.title.ifBlank { "Untitled note" }, Modifier.align(Alignment.BottomStart).padding(start = 20.dp, end = 12.dp, bottom = 14.dp),
                color = band, style = MaterialTheme.typography.titleMedium, maxLines = 3, overflow = TextOverflow.Ellipsis
            )
        }
    }
}

// ------------------------------------------------------------------ drawer (folders)
@Composable
private fun DrawerBody(
    selected: Destination, folders: List<FolderRow>,
    onSelect: (Destination) -> Unit, onNewFolder: () -> Unit
) {
    LazyColumn(Modifier.padding(horizontal = 12.dp)) {
        item { Text("InkNotes", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(20.dp)) }
        item { DrawerItem("All notes", Icons.Default.Description, selected == Destination.All) { onSelect(Destination.All) } }
        item { DrawerItem("Frequently used", Icons.Default.StarBorder, selected == Destination.Frequent) { onSelect(Destination.Frequent) } }
        item { DrawerItem("Shared notebooks", Icons.Default.People, false, soon = true) {} }
        item { DrawerItem("Voice recordings", Icons.Default.Mic, false, soon = true) {} }
        item { DrawerItem("Locked notes", Icons.Default.Lock, selected == Destination.Locked) { onSelect(Destination.Locked) } }
        item { DrawerItem("Trash (30 days)", Icons.Default.Delete, selected == Destination.Trash) { onSelect(Destination.Trash) } }

        item { SectionLabel("Folders") }
        items(folders, key = { "f${it.id}" }) { f ->
            NavigationDrawerItem(
                label = { Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                badge = { Text("${f.totalCount}") },
                icon = { Icon(Icons.Default.Folder, null, tint = Color(f.colorArgb)) },
                selected = selected == Destination.Folder(f.id),
                onClick = { onSelect(Destination.Folder(f.id)) },
                modifier = Modifier.padding(start = (f.depth * 16).dp)
            )
        }
        item { TextButton(onNewFolder) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("New folder") } }

        item { SectionLabel("Tags") }
        item { Text("Coming soon", Modifier.padding(horizontal = 16.dp).alpha(0.6f), style = MaterialTheme.typography.bodySmall) }
    }
}

@Composable
private fun DrawerItem(
    label: String, icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean, soon: Boolean = false, onClick: () -> Unit
) {
    NavigationDrawerItem(
        label = { Text(if (soon) "$label (soon)" else label) },
        icon = { Icon(icon, null) },
        selected = selected, onClick = onClick,
        modifier = Modifier.alpha(if (soon) 0.5f else 1f)
    )
}

@Composable
private fun SectionLabel(text: String) =
    Text(text, Modifier.padding(start = 16.dp, top = 16.dp, bottom = 4.dp), style = MaterialTheme.typography.titleSmall)

@Composable
private fun NewFolderDialog(onDismiss: () -> Unit, onCreate: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New folder") },
        text = { TextField(name, { name = it }, singleLine = true, placeholder = { Text("Folder name") }) },
        confirmButton = { TextButton({ if (name.isNotBlank()) onCreate(name) }) { Text("Create") } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } }
    )
}
