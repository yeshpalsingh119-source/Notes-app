package com.example.inknotes.ink

import com.example.inknotes.domain.model.StrokePoint
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * "Hold to shape": turns a rough stroke into a clean line / triangle / rectangle / circle / ellipse.
 * Returns null when the stroke does not look like any of them (it is then kept as written).
 */
object ShapeSnap {

    fun snap(pts: List<StrokePoint>, allowShapes: Boolean): List<StrokePoint>? {
        val n = pts.size
        if (n < 4) return null
        var len = 0f
        for (i in 1 until n) len += hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y)
        if (len < 40f) return null
        val first = pts.first()
        val last = pts.last()
        val gap = hypot(last.x - first.x, last.y - first.y)

        var minX = Float.MAX_VALUE; var minY = Float.MAX_VALUE; var maxX = -Float.MAX_VALUE; var maxY = -Float.MAX_VALUE
        for (p in pts) { minX = min(minX, p.x); minY = min(minY, p.y); maxX = max(maxX, p.x); maxY = max(maxY, p.y) }
        val w = maxX - minX
        val h = maxY - minY
        val diag = hypot(w, h)

        val closed = allowShapes && len > 120f && gap < 0.22f * len
        if (!closed) {
            var maxDev = 0f
            for (p in pts) maxDev = max(maxDev, distToLine(p.x, p.y, first.x, first.y, last.x, last.y))
            return if (gap > 40f && maxDev < 0.06f * gap) line(pts) else null
        }

        // reduce points, find corners (Ramer-Douglas-Peucker), drop nearly straight vertices
        val stride = max(1, n / 160)
        val sx = ArrayList<Float>(); val sy = ArrayList<Float>()
        var i = 0
        while (i < n) { sx.add(pts[i].x); sy.add(pts[i].y); i += stride }
        sx.add(last.x); sy.add(last.y)
        val m = sx.size
        val keep = BooleanArray(m)
        keep[0] = true; keep[m - 1] = true
        rdp(sx, sy, 0, m - 1, 0.07f * diag, keep)
        val vx = ArrayList<Float>(); val vy = ArrayList<Float>()
        for (k in 0 until m - 1) if (keep[k]) { vx.add(sx[k]); vy.add(sy[k]) }      // last == first, skip it
        removeStraight(vx, vy)

        when (vx.size) {
            3 -> return polygon(pts, vx, vy)
            4 -> {
                val axisAligned = (0 until 4).all { k ->
                    val a = atan2((vy[(k + 1) % 4] - vy[k]).toDouble(), (vx[(k + 1) % 4] - vx[k]).toDouble())
                    val d = abs(((Math.toDegrees(a) % 90.0) + 90.0) % 90.0)
                    min(d, 90.0 - d) < 12.0
                }
                return if (axisAligned) polygon(pts, listOf(minX, maxX, maxX, minX), listOf(minY, minY, maxY, maxY))
                else polygon(pts, vx, vy)
            }
        }

        // round shapes: compare with the ellipse that fills the bounding box
        val cx = (minX + maxX) / 2f; val cy = (minY + maxY) / 2f
        val a = w / 2f; val b = h / 2f
        if (a < 12f || b < 12f) return null
        var err = 0f
        for (p in pts) {
            val dx = (p.x - cx) / a; val dy = (p.y - cy) / b
            err += abs(dx * dx + dy * dy - 1f)
        }
        err /= n
        if (err > 0.22f) return null
        val circle = abs(a - b) / max(a, b) < 0.12f
        val ra = if (circle) (a + b) / 2f else a
        val rb = if (circle) (a + b) / 2f else b
        return ellipse(pts, cx, cy, ra, rb)
    }

    // ------------------------------------------------------------------ builders
    private fun template(pts: List<StrokePoint>) = Triple(
        pts.map { it.pressure }.average().toFloat(),
        pts.map { it.tilt }.average().toFloat(),
        pts.first()
    )

    private fun line(pts: List<StrokePoint>): List<StrokePoint> {
        val (p, t, f) = template(pts)
        val l = pts.last()
        val mid = StrokePoint((f.x + l.x) / 2f, (f.y + l.y) / 2f, p, t, f.orientation, (f.tMs + l.tMs) / 2)
        return listOf(f.copy(pressure = p, tilt = t), mid, l.copy(pressure = p, tilt = t))
    }

    private fun polygon(src: List<StrokePoint>, xs: List<Float>, ys: List<Float>): List<StrokePoint> {
        val (p, t, f) = template(src)
        val out = ArrayList<StrokePoint>()
        val k = xs.size
        for (e in 0 until k) {
            val x0 = xs[e]; val y0 = ys[e]
            val x1 = xs[(e + 1) % k]; val y1 = ys[(e + 1) % k]
            val steps = max(2, (hypot(x1 - x0, y1 - y0) / 8f).toInt())
            for (s in 0 until steps) {
                val u = s.toFloat() / steps
                out.add(StrokePoint(x0 + (x1 - x0) * u, y0 + (y1 - y0) * u, p, t, f.orientation, 0))
            }
        }
        out.add(out.first().copy())
        return retime(out, src)
    }

    private fun ellipse(src: List<StrokePoint>, cx: Float, cy: Float, a: Float, b: Float): List<StrokePoint> {
        val (p, t, f) = template(src)
        val th0 = atan2((f.y - cy) / b, (f.x - cx) / a)
        val out = ArrayList<StrokePoint>()
        val steps = 96
        for (s in 0..steps) {
            val th = th0 + 2.0 * PI * s / steps
            out.add(StrokePoint(cx + a * cos(th).toFloat(), cy + b * sin(th).toFloat(), p, t, f.orientation, 0))
        }
        return retime(out, src)
    }

    private fun retime(out: List<StrokePoint>, src: List<StrokePoint>): List<StrokePoint> {
        val t0 = src.first().tMs; val t1 = src.last().tMs
        val n = out.size
        return out.mapIndexed { i, q -> q.copy(tMs = t0 + (t1 - t0) * i / max(1, n - 1)) }
    }

    // ------------------------------------------------------------------ geometry helpers
    private fun distToLine(px: Float, py: Float, ax: Float, ay: Float, bx: Float, by: Float): Float {
        val dx = bx - ax; val dy = by - ay
        val l = hypot(dx, dy)
        if (l < 1e-3f) return hypot(px - ax, py - ay)
        return abs(dy * (px - ax) - dx * (py - ay)) / l
    }

    private fun distToSegment(px: Float, py: Float, ax: Float, ay: Float, bx: Float, by: Float): Float {
        val dx = bx - ax; val dy = by - ay
        val l2 = dx * dx + dy * dy
        val t = if (l2 == 0f) 0f else (((px - ax) * dx + (py - ay) * dy) / l2).coerceIn(0f, 1f)
        return hypot(px - (ax + t * dx), py - (ay + t * dy))
    }

    private fun rdp(x: List<Float>, y: List<Float>, s: Int, e: Int, eps: Float, keep: BooleanArray) {
        var maxD = 0f
        var idx = -1
        for (i in s + 1 until e) {
            val d = distToSegment(x[i], y[i], x[s], y[s], x[e], y[e])
            if (d > maxD) { maxD = d; idx = i }
        }
        if (idx != -1 && maxD > eps) {
            keep[idx] = true
            rdp(x, y, s, idx, eps, keep)
            rdp(x, y, idx, e, eps, keep)
        }
    }

    /** Removes corners whose turn is < 28 degrees (they are just points lying on an edge). */
    private fun removeStraight(x: MutableList<Float>, y: MutableList<Float>) {
        var changed = true
        while (changed && x.size > 3) {
            changed = false
            val k = x.size
            for (i in 0 until k) {
                val p = (i + k - 1) % k; val q = (i + 1) % k
                val ax = x[i] - x[p]; val ay = y[i] - y[p]
                val bx = x[q] - x[i]; val by = y[q] - y[i]
                val la = hypot(ax, ay); val lb = hypot(bx, by)
                if (la < 1e-3f || lb < 1e-3f) { x.removeAt(i); y.removeAt(i); changed = true; break }
                val cosT = ((ax * bx + ay * by) / (la * lb)).coerceIn(-1f, 1f)
                if (Math.toDegrees(acos(cosT).toDouble()) < 28.0) { x.removeAt(i); y.removeAt(i); changed = true; break }
            }
        }
    }
}
