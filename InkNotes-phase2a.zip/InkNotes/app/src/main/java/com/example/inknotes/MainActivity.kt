package com.example.inknotes

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.inknotes.ui.AppNav
import com.example.inknotes.ui.theme.InkNotesTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        preferHighestRefreshRate()
        setContent { InkNotesTheme { AppNav() } }
    }

    private fun preferHighestRefreshRate() {
        runCatching {
            @Suppress("DEPRECATION")
            val best = windowManager.defaultDisplay.supportedModes.maxByOrNull { it.refreshRate } ?: return
            val lp = window.attributes
            lp.preferredDisplayModeId = best.modeId
            window.attributes = lp
        }
    }
}
