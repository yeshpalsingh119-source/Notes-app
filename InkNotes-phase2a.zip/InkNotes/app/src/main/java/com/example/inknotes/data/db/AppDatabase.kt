package com.example.inknotes.data.db

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [NoteEntity::class, FolderEntity::class, PageEntity::class, TagEntity::class, NoteTagCrossRef::class],
    version = 1,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun noteDao(): NoteDao
    abstract fun pageDao(): PageDao
    abstract fun folderDao(): FolderDao
}
