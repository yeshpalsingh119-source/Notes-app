package com.example.inknotes.ui.editor

import android.content.Context
import android.net.Uri
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.inknotes.data.repository.NotesRepository
import com.example.inknotes.domain.UndoRedoStack
import com.example.inknotes.domain.model.*
import com.example.inknotes.ink.PenSpecs
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.serialization.Serializable
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json
import java.io.File
import javax.inject.Inject
import kotlin.math.max
import kotlin.math.min

enum class EditorMode { DRAW, TEXT, IMAGE }

/** Each pen remembers its own colour and size (1..100), like Samsung Notes. */
data class PenSetting(val color: Int, val size: Float)

/** A saved pen (type + colour + size + line style) shown as a quick button in the toolbar. */
@Serializable
data class Favorite(val pen: PenType, val color: Int, val size: Float, val lineStyle: Int)

@Serializable
private data class SavedPens(
    val colors: Map<String, Int> = emptyMap(),
    val sizes: Map<String, Float> = emptyMap(),
    val favorites: List<Favorite> = emptyList(),
    val recent: List<Int> = emptyList(),
    val pen: String = "FOUNTAIN",
    val highlighter: String = "HIGHLIGHTER",
    val straighten: Boolean = false,
    val holdToShape: Boolean = false,
    val lineStyle: Int = 0,
    val areaEraser: Boolean = true,
    val eraserSize: Float = 30f,
    val shape: String = "RECT"
)

private fun PenState.toSaved() = SavedPens(
    colors = settings.entries.associate { it.key.name to it.value.color },
    sizes = settings.entries.associate { it.key.name to it.value.size },
    favorites = favorites, recent = recentColors, pen = pen.name, highlighter = highlighter.name,
    straighten = straighten, holdToShape = holdToShape, lineStyle = lineStyle,
    areaEraser = areaEraser, eraserSize = eraserSize, shape = shape.name
)

private fun SavedPens.toState(): PenState {
    val base = PenState()
    return base.copy(
        settings = base.settings.entries.associate { (t, d) -> t to PenSetting(colors[t.name] ?: d.color, sizes[t.name] ?: d.size) },
        favorites = favorites,
        recentColors = if (recent.isEmpty()) base.recentColors else recent,
        pen = runCatching { PenType.valueOf(this.pen) }.getOrDefault(PenType.FOUNTAIN),
        highlighter = runCatching { PenType.valueOf(this.highlighter) }.getOrDefault(PenType.HIGHLIGHTER),
        straighten = straighten, holdToShape = holdToShape, lineStyle = lineStyle,
        areaEraser = areaEraser, eraserSize = eraserSize,
        shape = runCatching { ShapeKind.valueOf(this.shape) }.getOrDefault(ShapeKind.RECT)
    )
}

private fun defaultSettings(): Map<PenType, PenSetting> =
    PenType.entries.associateWith { PenSetting(PenSpecs.of(it).defaultColor, PenSpecs.of(it).defaultSize) }

data class PenState(
    val tool: Tool = Tool.PEN,
    val pen: PenType = PenType.FOUNTAIN,
    val highlighter: PenType = PenType.HIGHLIGHTER,
    val settings: Map<PenType, PenSetting> = defaultSettings(),
    val recentColors: List<Int> = listOf(0xFF7086F7.toInt(), 0xFFEF5360.toInt(), 0xFFFDE047.toInt()),
    val straighten: Boolean = false,
    val holdToShape: Boolean = false,
    val lineStyle: Int = LineStyle.SOLID,
    val eraseHighlighterOnly: Boolean = false,
    val fingerDrawing: Boolean = false,
    val readingMode: Boolean = false,
    val showDebug: Boolean = false,
    val areaEraser: Boolean = true,
    val eraserSize: Float = 30f,
    val shape: ShapeKind = ShapeKind.RECT,
    val favorites: List<Favorite> = emptyList()
) {
    val activeType: PenType get() = if (tool == Tool.HIGHLIGHTER) highlighter else pen
    val active: PenSetting
        get() = settings[activeType] ?: PenSetting(PenSpecs.of(activeType).defaultColor, PenSpecs.of(activeType).defaultSize)

    fun withPen(t: PenType): PenState =
        if (t.isHighlighter) copy(tool = Tool.HIGHLIGHTER, highlighter = t) else copy(tool = Tool.PEN, pen = t)

    fun currentFavorite() = Favorite(activeType, active.color, active.size, lineStyle)
    fun isFavorite() = favorites.contains(currentFavorite())
    fun toggleFavorite(): PenState {
        val f = currentFavorite()
        return copy(favorites = if (favorites.contains(f)) favorites - f else (favorites + f).takeLast(6))
    }
    fun applyFavorite(f: Favorite): PenState =
        withPen(f.pen).copy(settings = settings + (f.pen to PenSetting(f.color, f.size)), lineStyle = f.lineStyle)

    fun withSize(s: Float): PenState =
        copy(settings = settings + (activeType to active.copy(size = s.coerceIn(1f, 100f))))

    fun withColor(c: Int): PenState =
        copy(
            settings = settings + (activeType to active.copy(color = c)),
            recentColors = (listOf(c) + recentColors.filter { it != c }).take(3)
        )
}

data class HistoryState(val canUndo: Boolean = false, val canRedo: Boolean = false)

@HiltViewModel
class EditorViewModel @Inject constructor(
    private val repo: NotesRepository,
    @ApplicationContext ctx: Context,
    state: SavedStateHandle
) : ViewModel() {

    private val noteId: Long = checkNotNull(state.get<Long>("noteId"))
    private var pageId: Long = -1
    private val undoStack = UndoRedoStack()
    private val json = Json { ignoreUnknownKeys = true }
    private val blockSer = ListSerializer(TextBlock.serializer())

    // ---------------- ink ----------------
    private val _strokes = MutableStateFlow<List<Stroke>>(emptyList())
    val strokes: StateFlow<List<Stroke>> = _strokes.asStateFlow()

    private val prefs = ctx.getSharedPreferences("pens", Context.MODE_PRIVATE)
    private val penJson = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    private fun loadPens(): PenState = runCatching {
        penJson.decodeFromString(SavedPens.serializer(), prefs.getString("v1", null) ?: return PenState()).toState()
    }.getOrDefault(PenState())

    private val _pen = MutableStateFlow(loadPens())
    val pen: StateFlow<PenState> = _pen.asStateFlow()

    private val _history = MutableStateFlow(HistoryState())
    val history: StateFlow<HistoryState> = _history.asStateFlow()

    // ---------------- page ----------------
    private val _template = MutableStateFlow(PageTemplate.BLANK)
    val template: StateFlow<PageTemplate> = _template.asStateFlow()

    private val _title = MutableStateFlow("")
    val title: StateFlow<String> = _title.asStateFlow()

    private val _mode = MutableStateFlow(EditorMode.DRAW)
    val mode: StateFlow<EditorMode> = _mode.asStateFlow()

    // ---------------- rich text (block based) ----------------
    private val _blocks = MutableStateFlow(listOf(TextBlock()))
    val blocks: StateFlow<List<TextBlock>> = _blocks.asStateFlow()

    private val _focusedId = MutableStateFlow<String?>(null)
    val focusedId: StateFlow<String?> = _focusedId.asStateFlow()

    private val _pendingFocus = MutableStateFlow<String?>(null)
    val pendingFocus: StateFlow<String?> = _pendingFocus.asStateFlow()

    // ---------------- photos ----------------
    private val _images = MutableStateFlow<List<ImageItem>>(emptyList())
    val images: StateFlow<List<ImageItem>> = _images.asStateFlow()

    // ---------------- PDF + paper ----------------
    private val _pdfName = MutableStateFlow<String?>(null)
    val pdfName: StateFlow<String?> = _pdfName.asStateFlow()

    private val _paperColor = MutableStateFlow(0xFFFFFFFF.toInt())
    val paperColor: StateFlow<Int> = _paperColor.asStateFlow()

    private val _locked = MutableStateFlow(false)
    val locked: StateFlow<Boolean> = _locked.asStateFlow()

    val folders = repo.observeFolders().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _selectedImage = MutableStateFlow<String?>(null)
    val selectedImage: StateFlow<String?> = _selectedImage.asStateFlow()

    /** CONFLATED: a burst of edits collapses into one save, but every change is saved right away. */
    private val saveRequests = Channel<Unit>(Channel.CONFLATED)
    private val textSaves = Channel<Unit>(Channel.CONFLATED)
    private val imageSaves = Channel<Unit>(Channel.CONFLATED)

    init {
        viewModelScope.launch {
            repo.markOpened(noteId)
            _title.value = repo.title(noteId)
            val page = repo.firstPage(noteId)
            pageId = page.id
            _template.value = runCatching { PageTemplate.valueOf(page.template) }.getOrDefault(PageTemplate.BLANK)
            _strokes.value = repo.loadStrokes(pageId)
            _images.value = repo.loadImages(pageId)
            _pdfName.value = repo.pdfName(pageId)
            _paperColor.value = repo.paperColor(noteId)
            _locked.value = repo.isLocked(noteId)
            if (page.richTextJson.isNotBlank()) {
                runCatching { json.decodeFromString(blockSer, page.richTextJson) }
                    .getOrNull()?.takeIf { it.isNotEmpty() }?.let { _blocks.value = it }
            }
            launch {
                for (r in textSaves) {
                    val b = _blocks.value
                    val encoded = withContext(Dispatchers.Default) { json.encodeToString(blockSer, b) }
                    repo.saveRichText(noteId, pageId, encoded, b.joinToString("\n") { it.text })
                }
            }
            launch { for (r in imageSaves) repo.saveImages(pageId, _images.value) }
            for (r in saveRequests) repo.saveStrokes(noteId, pageId, _strokes.value)
        }
    }

    // ---------------- ink edits ----------------
    fun onEdit(a: EditAction) {
        undoStack.push(a)
        apply(a, reverse = false)
        afterChange()
    }

    fun undo() { undoStack.undo()?.let { apply(it, reverse = true); afterChange() } }
    fun redo() { undoStack.redo()?.let { apply(it, reverse = false); afterChange() } }

    private fun apply(a: EditAction, reverse: Boolean) {
        val (remove, add) = a.removeAdd(reverse)
        val removeIds = remove.map { it.id }.toHashSet()
        _strokes.update { cur ->
            val kept = if (removeIds.isEmpty()) cur else cur.filterNot { it.id in removeIds }
            if (add.isEmpty()) kept else {
                val have = kept.map { it.id }.toHashSet()
                kept + add.filter { it.id !in have }
            }
        }
    }

    private fun afterChange() {
        _history.value = HistoryState(undoStack.canUndo, undoStack.canRedo)
        saveRequests.trySend(Unit)
    }

    /** Undoable "clear all handwriting". */
    fun clearAll() {
        val s = _strokes.value
        if (s.isNotEmpty()) onEdit(EditAction.Remove(s))
    }

    fun updatePen(block: (PenState) -> PenState) {
        _pen.update(block)
        val saved = _pen.value.toSaved()
        prefs.edit().putString("v1", penJson.encodeToString(SavedPens.serializer(), saved)).apply()
    }
    fun setMode(m: EditorMode) { _mode.value = m }

    fun setTemplate(t: PageTemplate) {
        _template.value = t
        viewModelScope.launch { if (pageId > 0) repo.setTemplate(pageId, t) }
    }

    fun setPaperColor(c: Int) {
        _paperColor.value = c
        viewModelScope.launch { repo.setPaperColor(noteId, c) }
    }

    fun pdfFile(name: String): File = repo.pdfFile(name)

    fun toggleLocked() {
        val v = !_locked.value
        _locked.value = v
        viewModelScope.launch { repo.setLocked(noteId, v) }
    }

    fun moveToFolder(folderId: Long?) { viewModelScope.launch { repo.moveToFolder(noteId, folderId) } }

    /** Called when leaving the editor: refreshes the preview shown on the home screen. */
    fun saveThumbnail() {
        val paper = _paperColor.value
        repo.saveThumbnail(noteId, paper, _strokes.value, _blocks.value, _pdfName.value?.let { repo.pdfFile(it) })
    }

    fun setTitle(t: String) {
        _title.value = t
        viewModelScope.launch { repo.setTitle(noteId, t) }
    }

    // ---------------- text block edits ----------------
    fun focusBlock(id: String) { _focusedId.value = id }
    fun pendingFocusConsumed() { _pendingFocus.value = null }

    fun changeBlock(b: TextBlock) {
        _blocks.value = _blocks.value.map { if (it.id == b.id) b else it }
        textSaves.trySend(Unit)
    }

    /** Enter pressed inside block [id]: text before the newline stays, text after moves to a new block. */
    fun splitBlock(id: String, before: String, after: String) {
        val l = _blocks.value
        val i = l.indexOfFirst { it.id == id }
        if (i < 0) return
        val cur = l[i]
        val out = l.toMutableList()
        if (cur.kind != BlockKind.PARAGRAPH && before.isEmpty() && after.isEmpty()) {
            out[i] = cur.copy(kind = BlockKind.PARAGRAPH, checked = false)     // Enter on empty list line leaves the list
        } else {
            val next = cur.copy(id = newBlockId(), text = after, checked = false)
            out[i] = cur.copy(text = before)
            out.add(i + 1, next)
            _pendingFocus.value = next.id
        }
        _blocks.value = out
        textSaves.trySend(Unit)
    }

    /** Backspace on an empty block: list line -> plain paragraph, plain paragraph -> removed. */
    fun backspaceEmpty(id: String) {
        val l = _blocks.value
        val i = l.indexOfFirst { it.id == id }
        if (i < 0) return
        val cur = l[i]
        if (cur.kind != BlockKind.PARAGRAPH) {
            _blocks.value = l.toMutableList().also { it[i] = cur.copy(kind = BlockKind.PARAGRAPH, checked = false) }
        } else if (l.size > 1) {
            val rest = l.filterIndexed { idx, _ -> idx != i }
            _blocks.value = rest
            _pendingFocus.value = rest[(i - 1).coerceAtLeast(0)].id
        }
        textSaves.trySend(Unit)
    }

    /** Applies a format change to the focused block (or the last block if none is focused). */
    fun format(t: (TextBlock) -> TextBlock) {
        val l = _blocks.value
        val target = l.firstOrNull { it.id == _focusedId.value } ?: l.last()
        changeBlock(t(target))
    }

    /** Adds recognised handwriting to the text layer (one block per line). */
    fun appendText(text: String) {
        val lines = text.split('\n').map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.isEmpty()) return
        val out = _blocks.value.toMutableList()
        var start = 0
        if (out.last().text.isEmpty()) { out[out.lastIndex] = out.last().copy(text = lines[0]); start = 1 }
        for (i in start until lines.size) out.add(TextBlock(text = lines[i]))
        _blocks.value = out
        textSaves.trySend(Unit)
    }

    fun plainText(): String = _blocks.value.joinToString("\n") { it.text }

    // ---------------- photos ----------------
    fun imageFile(name: String): File = repo.imageFile(name)

    fun addImage(uri: Uri, centerX: Float, centerY: Float) {
        viewModelScope.launch {
            val (file, w, h) = repo.importImage(uri) ?: return@launch
            val k = min(1f, 600f / max(w, h).toFloat())
            val iw = w * k
            val ih = h * k
            val z = (_images.value.maxOfOrNull { it.z } ?: 0) + 1
            val item = ImageItem(newBlockId(), file, centerX - iw / 2f, centerY - ih / 2f, iw, ih, 0f, z)
            _images.value = _images.value + item
            _selectedImage.value = item.id
            imageSaves.trySend(Unit)
        }
    }

    fun selectImage(id: String?) { _selectedImage.value = id }

    fun transformImage(id: String, dx: Float, dy: Float, zoom: Float, rotation: Float) {
        _images.value = _images.value.map {
            if (it.id != id) it else {
                val nw = (it.w * zoom).coerceIn(40f, 4000f)
                val nh = it.h * (nw / it.w)
                val cx = it.x + it.w / 2f + dx
                val cy = it.y + it.h / 2f + dy
                it.copy(x = cx - nw / 2f, y = cy - nh / 2f, w = nw, h = nh, rotation = it.rotation + rotation)
            }
        }
        imageSaves.trySend(Unit)
    }

    fun deleteSelectedImage() {
        val id = _selectedImage.value ?: return
        _images.value = _images.value.filterNot { it.id == id }
        _selectedImage.value = null
        imageSaves.trySend(Unit)
    }

    /** Bring forward / send backward: swap z with the neighbouring image. */
    fun moveSelectedImage(forward: Boolean) {
        val id = _selectedImage.value ?: return
        val sorted = _images.value.sortedBy { it.z }
        val i = sorted.indexOfFirst { it.id == id }
        val j = if (forward) i + 1 else i - 1
        if (i < 0 || j < 0 || j >= sorted.size) return
        val a = sorted[i]
        val b = sorted[j]
        _images.value = _images.value.map {
            when (it.id) { a.id -> it.copy(z = b.z); b.id -> it.copy(z = a.z); else -> it }
        }
        imageSaves.trySend(Unit)
    }
}
