package com.example.inknotes.ink

import com.example.inknotes.domain.model.Stroke
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.vision.digitalink.DigitalInkRecognition
import com.google.mlkit.vision.digitalink.DigitalInkRecognitionModel
import com.google.mlkit.vision.digitalink.DigitalInkRecognitionModelIdentifier
import com.google.mlkit.vision.digitalink.DigitalInkRecognizerOptions
import com.google.mlkit.vision.digitalink.Ink

/** Handwriting -> text with ML Kit Digital Ink (on-device; the language model is downloaded once, needs internet). */
class HandwritingRecognizer {

    fun recognize(strokes: List<Stroke>, languageTag: String, onResult: (Result<String>) -> Unit) {
        val id = runCatching { DigitalInkRecognitionModelIdentifier.fromLanguageTag(languageTag) }.getOrNull()
        if (id == null) { onResult(Result.failure(IllegalArgumentException("Language not supported: $languageTag"))); return }
        val model = DigitalInkRecognitionModel.builder(id).build()
        val manager = RemoteModelManager.getInstance()
        manager.isModelDownloaded(model)
            .addOnSuccessListener { has ->
                if (has) run(model, strokes, onResult)
                else manager.download(model, DownloadConditions.Builder().build())
                    .addOnSuccessListener { run(model, strokes, onResult) }
                    .addOnFailureListener { onResult(Result.failure(it)) }
            }
            .addOnFailureListener { onResult(Result.failure(it)) }
    }

    private fun run(model: DigitalInkRecognitionModel, strokes: List<Stroke>, onResult: (Result<String>) -> Unit) {
        val recognizer = DigitalInkRecognition.getClient(DigitalInkRecognizerOptions.builder(model).build())
        val ink = Ink.builder()
        strokes.forEachIndexed { i, s ->
            val sb = Ink.Stroke.builder()
            for (p in s.points) sb.addPoint(Ink.Point.create(p.x, p.y, i * 1000L + p.tMs))
            ink.addStroke(sb.build())
        }
        recognizer.recognize(ink.build())
            .addOnSuccessListener { r ->
                onResult(Result.success(r.candidates.firstOrNull()?.text.orEmpty()))
                recognizer.close()
            }
            .addOnFailureListener { e ->
                onResult(Result.failure(e))
                recognizer.close()
            }
    }
}
