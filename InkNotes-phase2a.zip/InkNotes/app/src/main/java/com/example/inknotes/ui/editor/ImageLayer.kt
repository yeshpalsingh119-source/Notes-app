package com.example.inknotes.ui.editor

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.offset
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.key
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.example.inknotes.domain.model.ImageItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.roundToInt

/**
 * Photos sit under the ink and text layers. Placed after the ink view in the layout, they get the touches
 * first when [editable] (IMAGE mode): drag = move, two fingers = resize + rotate, tap = select.
 * When not editable they have no pointer handlers, so touches fall through to the ink view.
 */
@Composable
fun ImageLayer(
    images: List<ImageItem>,
    selectedId: String?,
    editable: Boolean,
    fileOf: (String) -> File,
    onSelect: (String?) -> Unit,
    onTransform: (id: String, dx: Float, dy: Float, zoom: Float, rotation: Float) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(modifier) {
        for (item in images.sortedBy { it.z }) {
            key(item.id) {
                PhotoItem(item, item.id == selectedId, editable, fileOf, onSelect, onTransform)
            }
        }
    }
}

@Composable
private fun PhotoItem(
    item: ImageItem,
    selected: Boolean,
    editable: Boolean,
    fileOf: (String) -> File,
    onSelect: (String?) -> Unit,
    onTransform: (String, Float, Float, Float, Float) -> Unit
) {
    val bmp by produceState<ImageBitmap?>(null, item.file) {
        value = withContext(Dispatchers.IO) { BitmapFactory.decodeFile(fileOf(item.file).path)?.asImageBitmap() }
    }
    val b = bmp
    if (b != null) {
        val d = LocalDensity.current
        val wDp = with(d) { item.w.toDp() }
        val hDp = with(d) { item.h.toDp() }
        var m = Modifier
            .offset { IntOffset(item.x.roundToInt(), item.y.roundToInt()) }
            .size(wDp, hDp)
        if (editable) {
            m = m
                .pointerInput(item.id) { detectTapGestures(onTap = { onSelect(item.id) }) }
                .pointerInput(item.id) {
                    detectTransformGestures { _, pan, zoom, rot ->
                        onSelect(item.id)
                        onTransform(item.id, pan.x, pan.y, zoom, rot)
                    }
                }
        }
        m = m.graphicsLayer { rotationZ = item.rotation }
        if (editable && selected) m = m.border(2.dp, MaterialTheme.colorScheme.primary)
        Image(bitmap = b, contentDescription = null, contentScale = ContentScale.FillBounds, modifier = m)
    }
}
