package com.example.inknotes.data.repository

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import com.example.inknotes.domain.model.ImageItem
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.max

/** Photos (copied into app storage, max 2048 px) + the per-page list of placed images. */
@Singleton
class ObjectStore @Inject constructor(@ApplicationContext private val ctx: Context) {
    private val root = File(ctx.filesDir, "objects")
    private val imgDir = File(ctx.filesDir, "images")
    private val json = Json { ignoreUnknownKeys = true }
    private val ser = ListSerializer(ImageItem.serializer())

    fun imageFile(name: String) = File(imgDir, name)

    suspend fun loadImages(pageId: Long): List<ImageItem> = withContext(Dispatchers.IO) {
        runCatching { json.decodeFromString(ser, File(root, "$pageId.json").readText()) }.getOrDefault(emptyList())
    }

    suspend fun saveImages(pageId: Long, items: List<ImageItem>) = withContext(Dispatchers.IO) {
        root.mkdirs()
        val tmp = File(root, "$pageId.tmp")
        tmp.writeText(json.encodeToString(ser, items))
        tmp.renameTo(File(root, "$pageId.json"))
    }

    /** Copies + downsamples the picked image. Returns (file name, width, height) or null on failure. */
    suspend fun importImage(uri: Uri): Triple<String, Int, Int>? = withContext(Dispatchers.IO) {
        runCatching {
            val resolver = ctx.contentResolver
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / sample > 2048) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            var bmp = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return@runCatching null
            val degrees = resolver.openInputStream(uri)?.use {
                when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            } ?: 0f
            if (degrees != 0f) {
                val m = Matrix().apply { postRotate(degrees) }
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }
            imgDir.mkdirs()
            val png = bmp.hasAlpha()
            val name = UUID.randomUUID().toString() + if (png) ".png" else ".jpg"
            FileOutputStream(File(imgDir, name)).use {
                bmp.compress(if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, 92, it)
            }
            Triple(name, bmp.width, bmp.height)
        }.getOrNull()
    }
}
