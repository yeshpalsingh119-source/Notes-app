package com.example.inknotes.ink

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.graphics.RectF
import android.os.SystemClock
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.SurfaceView
import androidx.graphics.lowlatency.CanvasFrontBufferedRenderer
import com.example.inknotes.domain.model.EditAction
import com.example.inknotes.domain.model.PenType
import com.example.inknotes.domain.model.Stroke
import com.example.inknotes.domain.model.StrokePoint
import com.example.inknotes.domain.model.Tool
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** Last pen sample, for the on-screen debug HUD (is the pen really sending pressure / tilt?). */
data class PenSample(val toolType: Int, val pressure: Float, val tilt: Float, val orientation: Float, val hover: Boolean)

/**
 * Transparent ink overlay for the S Pen.
 *
 * Latency path  : unbuffered touch dispatch -> live stroke drawn into the FRONT buffer (skips the normal
 *                 compositor) with a short motion prediction at the pen tip.
 * Everything else is OFF the hot path:
 *   committed strokes live in a bitmap cache that is updated incrementally on a background thread
 *   (one stroke per pen-up) and only fully rebuilt for undo / erase / zoom / selection changes.
 *   The multi-buffer pass just blits that bitmap, so lag does not grow with the number of strokes.
 *
 * Tools: pen / highlighter / stroke eraser / lasso select (move, scale, duplicate, recolour, delete).
 * Finger = pan + pinch zoom (or draw when fingerDrawing is on); palm touches are ignored while the pen is down.
 */
class InkSurfaceView(context: Context) : SurfaceView(context) {

    fun interface EditListener { fun onEdit(action: EditAction) }
    private class Frame(val points: List<StrokePoint>?, val lasso: FloatArray?)
    private enum class G { NONE, PEN, ERASE, LASSO, SEL_MOVE, SEL_SCALE }

    // ------------------------------------------------------------------ configuration (set from Compose)
    var editListener: EditListener? = null
    var viewportListener: ((scale: Float, tx: Float, ty: Float) -> Unit)? = null
    var sampleListener: ((PenSample) -> Unit)? = null
    var selectionListener: ((Boolean) -> Unit)? = null

    var tool: Tool = Tool.PEN
        set(value) {
            if (field == Tool.SELECT && value != Tool.SELECT) commitSelection()
            field = value
        }
    var pen = PenType.FOUNTAIN
    var penColor = Color.BLACK
    var penWidth = 6f
    var fingerDrawing = false
    var straighten = false
    var eraseHighlighterOnly = false
    var readOnly = false

    // ------------------------------------------------------------------ viewport (page space -> screen)
    @Volatile private var scale = 1f
    @Volatile private var tx = 0f
    @Volatile private var ty = 0f

    // ------------------------------------------------------------------ document
    @Volatile private var doc: List<Stroke> = emptyList()

    /** Set from Compose (load / undo / redo / clear). Local edits update [doc] directly, so the echo is skipped. */
    var strokes: List<Stroke>
        get() = doc
        set(value) {
            val cur = doc
            if (cur.size == value.size && cur.lastOrNull()?.id == value.lastOrNull()?.id) return
            doc = value
            if (selected.isNotEmpty()) { selected = emptyList(); selM = Matrix(); notifySelection() }
            requestRebuild()
        }

    // ------------------------------------------------------------------ bitmap cache of committed strokes
    private val bg = Executors.newSingleThreadExecutor { r -> Thread(r, "ink-cache") }
    private val cacheRenderer = StrokeRenderer(false)
    private val liveRenderer = StrokeRenderer(false)
    private val cacheLock = Any()
    private var cacheBmp: Bitmap? = null
    private var cacheScale = 1f
    private var cacheTx = 0f
    private var cacheTy = 0f
    private val rebuildPending = AtomicBoolean(false)
    private val bitmapPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    @Volatile private var released = false

    // ------------------------------------------------------------------ live gesture state
    private var gesture = G.NONE
    private var live: MutableList<StrokePoint>? = null
    private var liveIsStylus = false
    private var strokeStart = 0L
    @Volatile private var activePen = PenType.FOUNTAIN
    @Volatile private var activeColor = Color.BLACK
    @Volatile private var activeWidth = 6f
    private var smoothP = -1f
    private var smoothT = -1f
    private val erased = mutableListOf<Stroke>()
    private var lastCommit = 0L
    private var lastSample = 0L

    // ------------------------------------------------------------------ selection
    @Volatile private var selected: List<Stroke> = emptyList()
    @Volatile private var selM = Matrix()
    @Volatile private var selRect = RectF()
    private var selBase = Matrix()
    private var anchorX = 0f
    private var anchorY = 0f
    private var startDist = 1f
    private var lastPx = 0f
    private var lastPy = 0f
    private val lasso = ArrayList<Float>()

    private val density = resources.displayMetrics.density
    private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 2f * density; color = 0xFF3D7BFF.toInt()
        pathEffect = DashPathEffect(floatArrayOf(14f * density, 9f * density), 0f)
    }
    private val handleFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.WHITE }
    private val handleLine = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2f * density; color = 0xFF3D7BFF.toInt() }
    private val lassoPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0xFF3D7BFF.toInt() }
    private val lassoPath = Path()

    // ------------------------------------------------------------------ pan / zoom
    private var lastFx = 0f
    private var lastFy = 0f
    private var fx = 0f
    private var fy = 0f
    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            val ns = (scale * d.scaleFactor).coerceIn(0.5f, 6f)
            val k = ns / scale
            tx = d.focusX - k * (d.focusX - tx)
            ty = d.focusY - k * (d.focusY - ty)
            scale = ns
            notifyViewport(false)
            return true
        }
    })

    // ------------------------------------------------------------------ renderer callbacks
    private val callback = object : CanvasFrontBufferedRenderer.Callback<Frame> {
        override fun onDrawFrontBufferedLayer(canvas: Canvas, bufferWidth: Int, bufferHeight: Int, param: Frame) {
            canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
            canvas.save()
            canvas.translate(tx, ty)
            canvas.scale(scale, scale)
            val pts = param.points
            val l = param.lasso
            if (pts != null) {
                liveRenderer.drawLive(canvas, activePen, activeColor, activeWidth, pts)
            } else if (l != null && l.size >= 4) {
                lassoPath.rewind()
                lassoPath.moveTo(l[0], l[1])
                var i = 2
                while (i + 1 < l.size) { lassoPath.lineTo(l[i], l[i + 1]); i += 2 }
                lassoPaint.strokeWidth = 2f * density / scale
                lassoPaint.pathEffect = DashPathEffect(floatArrayOf(10f * density / scale, 7f * density / scale), 0f)
                canvas.drawPath(lassoPath, lassoPaint)
            }
            canvas.restore()
        }

        override fun onDrawMultiBufferedLayer(canvas: Canvas, bufferWidth: Int, bufferHeight: Int, params: Collection<Frame>) {
            canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
            synchronized(cacheLock) {
                val bmp = cacheBmp
                if (bmp != null && !bmp.isRecycled) {
                    val k = scale / cacheScale
                    canvas.save()
                    canvas.translate(tx - cacheTx * k, ty - cacheTy * k)
                    canvas.scale(k, k)
                    canvas.drawBitmap(bmp, 0f, 0f, bitmapPaint)
                    canvas.restore()
                }
            }
            drawSelection(canvas)
        }
    }

    init {
        setZOrderOnTop(true)                       // above the Compose paper layer...
        holder.setFormat(PixelFormat.TRANSLUCENT)  // ...but transparent
    }

    private val renderer = CanvasFrontBufferedRenderer(this, callback)

    fun release() {
        released = true
        bg.shutdownNow()
        runCatching { renderer.release(true) }
        synchronized(cacheLock) { cacheBmp?.recycle(); cacheBmp = null }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        requestRebuild()
    }

    // ------------------------------------------------------------------ cache management
    private fun safeCommit() {
        if (released) return
        try { renderer.commit() } catch (_: Exception) { }
    }

    private fun safeFront(f: Frame) {
        if (released) return
        try { renderer.renderFrontBufferedLayer(f) } catch (_: Exception) { }
    }

    private fun throttledCommit() {
        val now = SystemClock.uptimeMillis()
        if (now - lastCommit >= 8) { lastCommit = now; safeCommit() }
    }

    /** Full re-render of all committed strokes (minus the floating selection) on the background thread. */
    private fun requestRebuild() {
        if (released || width <= 0 || height <= 0) return
        if (!rebuildPending.compareAndSet(false, true)) return
        try {
            bg.execute {
                rebuildPending.set(false)
                val sel = selected
                val hide = if (sel.isEmpty()) emptySet() else sel.map { it.id }.toHashSet()
                val list = doc
                val s = scale; val x = tx; val y = ty
                val w = width; val h = height
                if (w <= 0 || h <= 0) return@execute
                val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                val c = Canvas(bmp)
                c.translate(x, y)
                c.scale(s, s)
                for (st in list) if (st.id !in hide) cacheRenderer.draw(c, st)
                synchronized(cacheLock) {
                    cacheBmp?.recycle()
                    cacheBmp = bmp; cacheScale = s; cacheTx = x; cacheTy = y
                }
                post { safeCommit() }
            }
        } catch (_: Exception) { rebuildPending.set(false) }
    }

    /** Draws ONE new stroke into the existing cache (cheap). The front buffer is cleared only afterwards. */
    private fun addToCache(st: Stroke) {
        if (released) return
        try {
            bg.execute {
                var ok = false
                synchronized(cacheLock) {
                    val bmp = cacheBmp
                    if (bmp != null && !bmp.isRecycled) {
                        val c = Canvas(bmp)
                        c.translate(cacheTx, cacheTy)
                        c.scale(cacheScale, cacheScale)
                        cacheRenderer.draw(c, st)
                        ok = true
                    }
                }
                if (ok) post { safeCommit() } else requestRebuild()
            }
        } catch (_: Exception) { }
    }

    // ------------------------------------------------------------------ touch
    override fun onHoverEvent(e: MotionEvent): Boolean {
        emitSample(e, true)
        return super.onHoverEvent(e)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val type = e.getToolType(0)
        val isStylus = type == MotionEvent.TOOL_TYPE_STYLUS || type == MotionEvent.TOOL_TYPE_ERASER
        emitSample(e, false)

        if (readOnly) return if (isStylus) true else handleGesture(e)

        if (!isStylus) {
            if (gesture != G.NONE && liveIsStylus) return true            // palm rejection
            val drawWithFinger = fingerDrawing && e.pointerCount == 1 &&
                (gesture != G.NONE || e.actionMasked == MotionEvent.ACTION_DOWN)
            if (!drawWithFinger) {
                if (gesture != G.NONE) cancelGesture()
                return handleGesture(e)
            }
        }

        val erasing = tool == Tool.ERASER ||
            type == MotionEvent.TOOL_TYPE_ERASER ||
            (e.buttonState and MotionEvent.BUTTON_STYLUS_PRIMARY) != 0

        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                requestUnbufferedDispatch(e)                              // deliver touch events immediately, not per vsync
                parent?.requestDisallowInterceptTouchEvent(true)
                liveIsStylus = isStylus
                when {
                    erasing -> { gesture = G.ERASE; eraseAt(e) }
                    tool == Tool.SELECT -> beginSelect(e)
                    else -> { gesture = G.PEN; beginStroke(e) }
                }
            }
            MotionEvent.ACTION_MOVE -> when (gesture) {
                G.PEN -> extendStroke(e)
                G.ERASE -> eraseAt(e)
                G.LASSO -> extendLasso(e)
                G.SEL_MOVE, G.SEL_SCALE -> dragSelection(e)
                G.NONE -> Unit
            }
            MotionEvent.ACTION_UP -> finishGesture(e)
            MotionEvent.ACTION_CANCEL -> cancelGesture()
        }
        return true
    }

    private fun emitSample(e: MotionEvent, hover: Boolean) {
        val l = sampleListener ?: return
        if (e.eventTime - lastSample < 33) return
        lastSample = e.eventTime
        l(PenSample(e.getToolType(0), e.pressure, e.getAxisValue(MotionEvent.AXIS_TILT), e.getAxisValue(MotionEvent.AXIS_ORIENTATION), hover))
    }

    private fun toPageX(x: Float) = (x - tx) / scale
    private fun toPageY(y: Float) = (y - ty) / scale

    // ------------------------------------------------------------------ pen
    private fun point(e: MotionEvent, h: Int): StrokePoint {
        val x: Float; val y: Float; val p: Float; val t: Float; val o: Float; val time: Long
        if (h < 0) {
            x = e.x; y = e.y; p = e.pressure
            t = e.getAxisValue(MotionEvent.AXIS_TILT); o = e.getAxisValue(MotionEvent.AXIS_ORIENTATION)
            time = e.eventTime
        } else {
            x = e.getHistoricalX(h); y = e.getHistoricalY(h); p = e.getHistoricalPressure(h)
            t = e.getHistoricalAxisValue(MotionEvent.AXIS_TILT, 0, h)
            o = e.getHistoricalAxisValue(MotionEvent.AXIS_ORIENTATION, 0, h)
            time = e.getHistoricalEventTime(h)
        }
        // light smoothing so width does not jitter; fingers have no real pressure/tilt
        val sp: Float
        val st: Float
        if (liveIsStylus) {
            smoothP = if (smoothP < 0f) p else smoothP + 0.45f * (p - smoothP)
            smoothT = if (smoothT < 0f) t else smoothT + 0.4f * (t - smoothT)
            sp = smoothP; st = smoothT
        } else { sp = 0.5f; st = 0f }
        return StrokePoint(toPageX(x), toPageY(y), sp, st, o, time - strokeStart)
    }

    private fun beginStroke(e: MotionEvent) {
        activePen = pen; activeColor = penColor; activeWidth = penWidth
        strokeStart = e.eventTime
        smoothP = -1f; smoothT = -1f
        val list = ArrayList<StrokePoint>(256)
        list.add(point(e, -1))
        live = list
        pushLive()
    }

    private fun extendStroke(e: MotionEvent) {
        val pts = live ?: return
        for (h in 0 until e.historySize) addPoint(pts, point(e, h))
        addPoint(pts, point(e, -1))
        pushLive()                                    // ONE front-buffer frame per MotionEvent
    }

    private fun addPoint(pts: MutableList<StrokePoint>, p: StrokePoint) {
        val l = pts.last()
        if (hypot(p.x - l.x, p.y - l.y) * scale < 0.8f) return      // drop sub-pixel samples
        pts.add(p)
    }

    private fun pushLive() {
        val pts = live ?: return
        val display = ArrayList<StrokePoint>(pts.size + 1)
        if (pts.size > 700) {
            var i = 0
            while (i < pts.size - 1) { display.add(pts[i]); i += 2 }
            display.add(pts.last())
        } else display.addAll(pts)
        predictedTail(pts)?.let { display.add(it) }
        safeFront(Frame(display, null))
    }

    /** Display-only guess ~14 ms ahead of the pen tip: hides most of the remaining pipeline latency. */
    private fun predictedTail(pts: List<StrokePoint>): StrokePoint? {
        val n = pts.size
        if (n < 3) return null
        val a = pts[n - 3]; val b = pts[n - 1]
        val dt = (b.tMs - a.tMs).toFloat()
        if (dt <= 0f) return null
        var px = (b.x - a.x) / dt * 14f
        var py = (b.y - a.y) / dt * 14f
        val len = hypot(px, py)
        val maxLen = 28f / scale
        if (len > maxLen) { px *= maxLen / len; py *= maxLen / len }
        return StrokePoint(b.x + px, b.y + py, b.pressure, b.tilt, b.orientation, b.tMs + 14)
    }

    private fun finishStroke(e: MotionEvent) {
        val pts = live ?: return
        live = null
        addPoint(pts, point(e, -1))
        var finalPts: List<StrokePoint> = pts.toList()
        if (straighten && finalPts.size > 2) finalPts = straightened(finalPts, e.eventTime - strokeStart)
        val stroke = Stroke(UUID.randomUUID().toString(), activePen, activeColor, activeWidth, finalPts)
        doc = doc + stroke
        addToCache(stroke)                            // front buffer is cleared once the cache has the stroke
        editListener?.onEdit(EditAction.Add(listOf(stroke)))
    }

    /** "Straighten lines": hold the pen still ~0.5 s at the end of a stroke and it snaps to a straight line. */
    private fun straightened(pts: List<StrokePoint>, upMs: Long): List<StrokePoint> {
        val last = pts.last()
        var i = pts.size - 1
        while (i > 0 && hypot(pts[i - 1].x - last.x, pts[i - 1].y - last.y) * scale < 8f) i--
        if (upMs - pts[i].tMs < 450) return pts
        val a = pts.first()
        val p = (a.pressure + last.pressure) / 2f
        val mid = StrokePoint((a.x + last.x) / 2f, (a.y + last.y) / 2f, p, a.tilt, a.orientation, (a.tMs + last.tMs) / 2)
        return listOf(a.copy(pressure = p), mid, last.copy(pressure = p))
    }

    private fun cancelGesture() {
        live = null
        lasso.clear()
        erased.clear()
        gesture = G.NONE
        if (!released) try { renderer.cancel() } catch (_: Exception) { }
    }

    private fun finishGesture(e: MotionEvent) {
        when (gesture) {
            G.PEN -> finishStroke(e)
            G.ERASE -> if (erased.isNotEmpty()) { editListener?.onEdit(EditAction.Remove(erased.toList())); erased.clear() }
            G.LASSO -> finishLasso()
            G.SEL_MOVE, G.SEL_SCALE -> safeCommit()
            G.NONE -> Unit
        }
        gesture = G.NONE
    }

    // ------------------------------------------------------------------ stroke eraser
    private fun eraseAt(e: MotionEvent) {
        val r = 14f * density / scale
        val n = e.historySize + 1
        val hits = HashSet<String>()
        for (i in 0 until n) {
            val px = toPageX(if (i < e.historySize) e.getHistoricalX(i) else e.x)
            val py = toPageY(if (i < e.historySize) e.getHistoricalY(i) else e.y)
            for (s in doc) {
                if (eraseHighlighterOnly && !s.pen.isHighlighter) continue
                if (touches(s, px, py, r)) hits.add(s.id)
            }
        }
        if (hits.isEmpty()) return
        erased += doc.filter { it.id in hits }
        doc = doc.filterNot { it.id in hits }
        requestRebuild()
    }

    private fun touches(s: Stroke, x: Float, y: Float, r: Float): Boolean {
        val p = s.points
        if (p.size == 1) return hypot(p[0].x - x, p[0].y - y) <= r
        for (i in 1 until p.size) if (segDist(p[i - 1], p[i], x, y) <= r) return true
        return false
    }

    private fun segDist(a: StrokePoint, b: StrokePoint, x: Float, y: Float): Float {
        val dx = b.x - a.x; val dy = b.y - a.y
        val len2 = dx * dx + dy * dy
        val t = if (len2 == 0f) 0f else (((x - a.x) * dx + (y - a.y) * dy) / len2).coerceIn(0f, 1f)
        return hypot(x - (a.x + t * dx), y - (a.y + t * dy))
    }

    // ------------------------------------------------------------------ select (lasso)
    private fun beginSelect(e: MotionEvent) {
        val px = toPageX(e.x); val py = toPageY(e.y)
        if (selected.isNotEmpty()) {
            val b = RectF(selRect).also { selM.mapRect(it) }
            val corners = arrayOf(
                floatArrayOf(b.left, b.top, b.right, b.bottom), floatArrayOf(b.right, b.top, b.left, b.bottom),
                floatArrayOf(b.right, b.bottom, b.left, b.top), floatArrayOf(b.left, b.bottom, b.right, b.top)
            )
            for (c in corners) {      // [corner x, corner y, opposite x, opposite y]
                if (hypot(e.x - (c[0] * scale + tx), e.y - (c[1] * scale + ty)) < 32f * density) {
                    gesture = G.SEL_SCALE
                    anchorX = c[2]; anchorY = c[3]
                    startDist = max(1f, hypot(px - anchorX, py - anchorY))
                    selBase = Matrix(selM)
                    return
                }
            }
            if (b.contains(px, py)) { gesture = G.SEL_MOVE; lastPx = px; lastPy = py; return }
            commitSelection()
        }
        gesture = G.LASSO
        lasso.clear(); lasso.add(px); lasso.add(py)
        safeFront(Frame(null, lasso.toFloatArray()))
    }

    private fun extendLasso(e: MotionEvent) {
        val px = toPageX(e.x); val py = toPageY(e.y)
        val n = lasso.size
        if (hypot(px - lasso[n - 2], py - lasso[n - 1]) * scale < 3f) return
        lasso.add(px); lasso.add(py)
        safeFront(Frame(null, lasso.toFloatArray()))
    }

    private fun finishLasso() {
        val poly = lasso.toFloatArray()
        lasso.clear()
        if (poly.size >= 6) {
            val picked = doc.filter { s -> s.points.isNotEmpty() && s.points.count { inside(poly, it.x, it.y) } * 2 >= s.points.size }
            if (picked.isNotEmpty()) select(picked)
        }
        safeCommit()                                   // clears the lasso from the front buffer
    }

    private fun inside(poly: FloatArray, x: Float, y: Float): Boolean {
        var c = false
        val n = poly.size / 2
        var j = n - 1
        for (i in 0 until n) {
            val xi = poly[2 * i]; val yi = poly[2 * i + 1]; val xj = poly[2 * j]; val yj = poly[2 * j + 1]
            if ((yi > y) != (yj > y) && x < (xj - xi) * (y - yi) / (yj - yi) + xi) c = !c
            j = i
        }
        return c
    }

    private fun select(list: List<Stroke>) {
        var l = Float.MAX_VALUE; var t = Float.MAX_VALUE; var r = -Float.MAX_VALUE; var b = -Float.MAX_VALUE
        for (s in list) {
            val pad = s.width / 2f
            for (p in s.points) { l = min(l, p.x - pad); t = min(t, p.y - pad); r = max(r, p.x + pad); b = max(b, p.y + pad) }
        }
        selRect = RectF(l, t, r, b)
        selM = Matrix()
        selected = list
        notifySelection()
        requestRebuild()                               // rebuild cache without the floating strokes
    }

    private fun dragSelection(e: MotionEvent) {
        val px = toPageX(e.x); val py = toPageY(e.y)
        if (gesture == G.SEL_MOVE) {
            val m = Matrix(selM); m.postTranslate(px - lastPx, py - lastPy); selM = m
            lastPx = px; lastPy = py
        } else {
            val f = (hypot(px - anchorX, py - anchorY) / startDist).coerceIn(0.1f, 10f)
            val m = Matrix(selBase); m.postScale(f, f, anchorX, anchorY); selM = m
        }
        throttledCommit()
    }

    private fun drawSelection(canvas: Canvas) {
        val sel = selected
        if (sel.isEmpty()) return
        val m = selM
        canvas.save()
        canvas.translate(tx, ty); canvas.scale(scale, scale); canvas.concat(m)
        for (s in sel) liveRenderer.draw(canvas, s)
        canvas.restore()
        val r = RectF(selRect); m.mapRect(r)
        val l = r.left * scale + tx; val t = r.top * scale + ty
        val rr = r.right * scale + tx; val b = r.bottom * scale + ty
        canvas.drawRect(l, t, rr, b, boxPaint)
        for ((cx, cy) in listOf(l to t, rr to t, rr to b, l to b)) {
            canvas.drawCircle(cx, cy, 9f * density, handleFill)
            canvas.drawCircle(cx, cy, 9f * density, handleLine)
        }
    }

    private fun notifySelection() { post { selectionListener?.invoke(selected.isNotEmpty()) } }

    fun selectedStrokes(): List<Stroke> = selected

    /** Applies the pending move/scale to the document (undoable) and returns the resulting strokes. */
    fun commitSelection(): List<Stroke> {
        val sel = selected
        if (sel.isEmpty()) return emptyList()
        val m = selM
        if (m.isIdentity) {
            selected = emptyList(); notifySelection(); requestRebuild(); safeCommit()
            return sel
        }
        val after = sel.map { transformed(it, m) }
        val ids = sel.map { it.id }.toHashSet()
        doc = doc.filterNot { it.id in ids } + after
        selected = emptyList(); selM = Matrix(); notifySelection()
        editListener?.onEdit(EditAction.Replace(sel, after))
        requestRebuild(); safeCommit()
        return after
    }

    fun deleteSelection() {
        val sel = selected
        if (sel.isEmpty()) return
        val ids = sel.map { it.id }.toHashSet()
        doc = doc.filterNot { it.id in ids }
        selected = emptyList(); selM = Matrix(); notifySelection()
        editListener?.onEdit(EditAction.Remove(sel))
        requestRebuild(); safeCommit()
    }

    fun duplicateSelection() {
        val base = commitSelection()
        if (base.isEmpty()) return
        val copies = base.map { s ->
            s.copy(id = UUID.randomUUID().toString(), points = s.points.map { it.copy(x = it.x + 40f, y = it.y + 40f) })
        }
        doc = doc + copies
        editListener?.onEdit(EditAction.Add(copies))
        select(copies)
    }

    fun recolorSelection(color: Int) {
        val base = commitSelection()
        if (base.isEmpty()) return
        val recolored = base.map { it.copy(id = UUID.randomUUID().toString(), colorArgb = color) }
        val ids = base.map { it.id }.toHashSet()
        doc = doc.filterNot { it.id in ids } + recolored
        editListener?.onEdit(EditAction.Replace(base, recolored))
        select(recolored)
    }

    private fun transformed(s: Stroke, m: Matrix): Stroke {
        val v = FloatArray(9)
        m.getValues(v)
        val k = sqrt(v[Matrix.MSCALE_X] * v[Matrix.MSCALE_X] + v[Matrix.MSKEW_Y] * v[Matrix.MSKEW_Y])
        val xy = FloatArray(s.points.size * 2)
        s.points.forEachIndexed { i, p -> xy[2 * i] = p.x; xy[2 * i + 1] = p.y }
        m.mapPoints(xy)
        return Stroke(
            UUID.randomUUID().toString(), s.pen, s.colorArgb, s.width * k,
            s.points.mapIndexed { i, p -> p.copy(x = xy[2 * i], y = xy[2 * i + 1]) }
        )
    }

    // ------------------------------------------------------------------ finger pan / pinch
    private fun handleGesture(e: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> { focal(e, -1); lastFx = fx; lastFy = fy }
            MotionEvent.ACTION_POINTER_UP -> { focal(e, e.actionIndex); lastFx = fx; lastFy = fy }
            MotionEvent.ACTION_MOVE -> {
                focal(e, -1)
                tx += fx - lastFx; ty += fy - lastFy
                lastFx = fx; lastFy = fy
                notifyViewport(false)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> notifyViewport(true)
        }
        return true
    }

    private fun focal(e: MotionEvent, skip: Int) {
        var x = 0f; var y = 0f; var n = 0
        for (i in 0 until e.pointerCount) { if (i == skip) continue; x += e.getX(i); y += e.getY(i); n++ }
        if (n > 0) { fx = x / n; fy = y / n }
    }

    private fun notifyViewport(final: Boolean) {
        if (final) { requestRebuild(); safeCommit() } else throttledCommit()   // while moving: just blit the cached bitmap
        viewportListener?.invoke(scale, tx, ty)
    }
}
