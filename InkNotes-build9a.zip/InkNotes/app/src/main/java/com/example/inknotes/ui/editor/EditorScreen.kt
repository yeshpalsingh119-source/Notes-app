package com.example.inknotes.ui.editor

import android.content.Intent
import android.widget.Toast
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import android.graphics.RectF
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Label
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.debounce
import kotlin.math.roundToInt
import com.example.inknotes.domain.model.BlockKind
import com.example.inknotes.domain.model.PageTemplate
import com.example.inknotes.domain.model.PenType
import com.example.inknotes.domain.model.TextBlock
import com.example.inknotes.domain.model.Tool
import com.example.inknotes.ink.HandwritingRecognizer
import com.example.inknotes.ink.InkSurfaceView
import com.example.inknotes.ink.PenSample
import com.example.inknotes.ink.PAGE_W
import com.example.inknotes.ink.PenSpecs
import com.example.inknotes.ink.TemplateRenderer

private data class Viewport(val scale: Float = 1f, val tx: Float = 0f, val ty: Float = 0f)

private sealed interface Recog {
    data object Loading : Recog
    data class Done(val text: String, val lang: String) : Recog
    data class Error(val msg: String) : Recog
}

private enum class PickerTarget { PEN, SELECTION }

@OptIn(ExperimentalMaterial3Api::class, FlowPreview::class)
@Composable
fun EditorScreen(onBack: () -> Unit, vm: EditorViewModel = hiltViewModel()) {
    val strokes by vm.strokes.collectAsStateWithLifecycle()
    val pen by vm.pen.collectAsStateWithLifecycle()
    val history by vm.history.collectAsStateWithLifecycle()
    val template by vm.template.collectAsStateWithLifecycle()
    val title by vm.title.collectAsStateWithLifecycle()
    val mode by vm.mode.collectAsStateWithLifecycle()
    val blocks by vm.blocks.collectAsStateWithLifecycle()
    val focusedId by vm.focusedId.collectAsStateWithLifecycle()
    val pendingFocus by vm.pendingFocus.collectAsStateWithLifecycle()
    val images by vm.images.collectAsStateWithLifecycle()
    val selectedImage by vm.selectedImage.collectAsStateWithLifecycle()
    val pdfName by vm.pdfName.collectAsStateWithLifecycle()
    val paperColor by vm.paperColor.collectAsStateWithLifecycle()
    val locked by vm.locked.collectAsStateWithLifecycle()
    val folders by vm.folders.collectAsStateWithLifecycle()

    val ctx = LocalContext.current
    val dark = isSystemInDarkTheme()
    val white = 0xFFFFFFFF.toInt()
    val paper = if (paperColor == white) (if (dark) 0xFF2B2B2B.toInt() else 0xFFFCFCFC.toInt()) else paperColor
    val paperIsLight = Color(paper).luminance() > 0.5f
    val lineInk = if (paperIsLight) Color.Black.toArgb() else Color.White.toArgb()
    val desk = if (dark) 0xFF111113.toInt() else 0xFFE8E8EC.toInt()
    val pageWidthDp = with(LocalDensity.current) { PAGE_W.toDp() }

    var viewport by remember { mutableStateOf(Viewport()) }
    var boxSize by remember { mutableStateOf(IntSize.Zero) }
    var templateMenu by remember { mutableStateOf(false) }
    var moreMenu by remember { mutableStateOf(false) }
    var panel by remember { mutableStateOf<PanelKind?>(null) }
    val toolAnchors = remember { HashMap<Tool, Rect>() }            // tool buttons in SCREEN pixels (read when a panel opens)
    val hostView = LocalView.current
    val uiPrefs = remember { ctx.getSharedPreferences("inknotes_ui", android.content.Context.MODE_PRIVATE) }
    var dock by remember {
        mutableStateOf(runCatching { ToolbarDock.valueOf(uiPrefs.getString("dock", "BOTTOM") ?: "BOTTOM") }.getOrDefault(ToolbarDock.BOTTOM))
    }
    var editorRect by remember { mutableStateOf<Rect?>(null) }

    // pages, tags, voice, writing pad, change style, handwriting help, customisable toolbar
    val pages by vm.pages.collectAsStateWithLifecycle()
    val currentPageId by vm.currentPageId.collectAsStateWithLifecycle()
    val thumbVersion by vm.thumbVersion.collectAsStateWithLifecycle()
    val allTags by vm.tags.collectAsStateWithLifecycle()
    val noteTagIds by vm.noteTagIds.collectAsStateWithLifecycle()
    var showPages by remember { mutableStateOf(false) }
    var showTags by remember { mutableStateOf(false) }
    var showVoice by remember { mutableStateOf(false) }
    var showPad by remember { mutableStateOf(false) }
    var showStyle by remember { mutableStateOf(false) }
    var showCustomize by remember { mutableStateOf(false) }
    var helpState by remember { mutableStateOf<HelpState?>(null) }
    var padOffset by remember { mutableFloatStateOf(0f) }
    val toolItems = resolveToolbar(pen.toolbar)
    val voice = remember { VoiceController(ctx, vm.id) }
    DisposableEffect(Unit) { onDispose { voice.release() } }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) voice.start()
    }
    val micGranted = ctx.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED
    var picker by remember { mutableStateOf<PickerTarget?>(null) }
    var plusMenu by remember { mutableStateOf(false) }
    var fullscreen by remember { mutableStateOf(false) }
    var styleDialog by remember { mutableStateOf(false) }
    var bgDialog by remember { mutableStateOf(false) }
    var folderDialog by remember { mutableStateOf(false) }
    var exportDialog by remember { mutableStateOf(false) }
    var exporting by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val pdfPaint = remember { android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG) }
    val whitePaint = remember { android.graphics.Paint().apply { color = android.graphics.Color.WHITE } }

    // imported PDF: pages are rendered lazily around the viewport
    val pdf = remember(pdfName) { pdfName?.let { n -> runCatching { PdfPages(vm.pdfFile(n)) }.getOrNull() } }
    DisposableEffect(pdf) { onDispose { pdf?.close() } }
    DisposableEffect(Unit) { onDispose { vm.saveThumbnail() } }     // refresh the home-screen preview
    var sample by remember { mutableStateOf<PenSample?>(null) }
    var hasSelection by remember { mutableStateOf(false) }
    var inkView by remember { mutableStateOf<InkSurfaceView?>(null) }
    var recog by remember { mutableStateOf<Recog?>(null) }
    val recognizer = remember { HandwritingRecognizer() }
    LaunchedEffect(currentPageId) { inkView?.scrollToTop() }      // a new page opens at its top
    val onSample: (PenSample) -> Unit = { sample = it }
    val focusedBlock = blocks.firstOrNull { it.id == focusedId } ?: blocks.last()

    LaunchedEffect(pdf) {
        if (pdf == null) return@LaunchedEffect
        pdf.loadLayout(PAGE_W)
        snapshotFlow { Triple(viewport, boxSize, pdf.contentHeight) }
            .debounce(80)
            .collectLatest { (vp, size, ch) ->
                if (ch <= 0f || size.height == 0) return@collectLatest
                val range = pdf.visibleRange(-vp.ty / vp.scale, (size.height - vp.ty) / vp.scale) ?: return@collectLatest
                val want = ((((PAGE_W * vp.scale) / 256f).roundToInt() + 1) * 256).coerceIn(512, 2400)
                val near = (range.first - 1).coerceAtLeast(0)..(range.last + 1).coerceAtMost(pdf.pageCount - 1)
                pdf.ensure(range.toList() + near.filter { it !in range }, want, range.first, range.last)
            }
    }

    fun export(kind: String) {
        exportDialog = false
        exporting = true
        val input = Exporter.Input(
            strokes, blocks, images, vm::imageFile, template, paper, lineInk,
            ctx.resources.displayMetrics.density, pdf
        )
        val safe = title.ifBlank { "note" }.replace(Regex("[^A-Za-z0-9_-]+"), "_").take(40)
        scope.launch {
            val file = withContext(Dispatchers.Default) {
                runCatching { if (kind == "pdf") Exporter.pdf(ctx, safe, input) else Exporter.png(ctx, safe, input) }.getOrNull()
            }
            exporting = false
            if (file == null) {
                Toast.makeText(ctx, "Export failed", Toast.LENGTH_LONG).show()
            } else {
                val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", file)
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = if (kind == "pdf") "application/pdf" else "image/png"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                ctx.startActivity(Intent.createChooser(send, "Share note"))
            }
        }
    }

    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            val vp = viewport
            vm.addImage(uri, (boxSize.width / 2f - vp.tx) / vp.scale, (boxSize.height / 2f - vp.ty) / vp.scale)
        }
    }
    fun pickPhoto() = photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))

    fun recognize(lang: String) {
        val s = inkView?.selectedStrokes().orEmpty()
        if (s.isEmpty()) return
        recog = Recog.Loading
        recognizer.recognize(s, lang) { r ->
            recog = r.fold({ Recog.Done(it, lang) }, { Recog.Error(it.message ?: "Recognition failed") })
        }
    }

    fun help(lang: String) {
        val s = inkView?.selectedStrokes().orEmpty()
        if (s.isEmpty()) return
        helpState = HelpState.Loading
        recognizer.recognizeAll(s, lang) { r ->
            helpState = r.fold({ HelpState.Done(it) }, { HelpState.Error(it.message ?: "Recognition failed") })
        }
    }

    val drawToolbar: @Composable () -> Unit = {
        DrawToolbar(
            pen = pen, history = history, dock = dock,
            items = toolItems, recording = voice.isRecording,
            onStyle = { showStyle = true },
            onHelp = { help("en-US") },
            onPad = { padOffset = 0f; showPad = true },
            onVoice = { showVoice = true },
            onDockTo = { x, y ->
                val r = editorRect
                if (r != null && r.width > 0f && r.height > 0f) {
                    val dl = x - r.left; val dr = r.right - x; val dt = y - r.top; val db = r.bottom - y
                    val m = minOf(minOf(dl, dr), minOf(dt, db))
                    val target = when (m) {
                        dl -> ToolbarDock.LEFT
                        dr -> ToolbarDock.RIGHT
                        dt -> ToolbarDock.TOP
                        else -> ToolbarDock.BOTTOM
                    }
                    if (target != dock) {
                        dock = target
                        uiPrefs.edit().putString("dock", target.name).apply()
                    }
                }
            },
            hasSelection = hasSelection,
            onConvert = { recognize("en-US") },
            onAlign = { inkView?.alignSelection() },
            onAnchor = { t, r ->
                val loc = IntArray(2)
                hostView.getLocationOnScreen(loc)
                toolAnchors[t] = r.translate(loc[0].toFloat(), loc[1].toFloat())
            },
            onLockCanvas = { vm.updatePen { it.copy(lockCanvas = !it.lockCanvas) } },
            onToolTap = { t ->
                if (pen.tool == t) {
                    panel = when (t) {
                        Tool.PEN -> PanelKind.PEN
                        Tool.HIGHLIGHTER -> PanelKind.HIGHLIGHTER
                        Tool.ERASER -> PanelKind.ERASER
                        Tool.SELECT -> null
                        Tool.SHAPE -> PanelKind.SHAPE
                        Tool.TAPE -> PanelKind.TAPE
                        Tool.LASER -> null
                    }
                } else vm.updatePen { it.copy(tool = t) }
            },
            onText = { vm.setMode(EditorMode.TEXT) },
            onPhoto = { vm.setMode(EditorMode.IMAGE); pickPhoto() },
            onFavorite = { f -> vm.updatePen { it.applyFavorite(f) } },
            onColor = { c -> vm.updatePen { it.withColor(c) } },
            onThickness = {
                panel = when (pen.tool) {
                    Tool.HIGHLIGHTER -> PanelKind.HIGHLIGHTER
                    Tool.ERASER -> PanelKind.ERASER
                    Tool.TAPE -> PanelKind.TAPE
                    else -> PanelKind.PEN
                }
            },
            onUndo = vm::undo, onRedo = vm::redo
        
        )
    }

    Scaffold(
        topBar = {
            if (!fullscreen) TopAppBar(
                title = {
                    TextField(
                        value = title, onValueChange = vm::setTitle, singleLine = true,
                        placeholder = { Text("Title", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.outline) },
                        textStyle = MaterialTheme.typography.titleLarge,
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent
                        )
                    )
                },
                navigationIcon = { IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                actions = {
                    if (hasSelection) {
                        IconButton({ inkView?.duplicateSelection() }) { Icon(Icons.Default.ContentCopy, "Duplicate") }
                        IconButton({ picker = PickerTarget.SELECTION }) { Icon(Icons.Default.Palette, "Colour") }
                        IconButton({ inkView?.deleteSelection() }) { Icon(Icons.Default.Delete, "Delete") }
                        IconButton({ inkView?.commitSelection() }) { Icon(Icons.Default.Check, "Done") }
                    } else {
                        TextButton({ vm.refreshPageThumbs(); showPages = true }) {
                            Text("${(pages.indexOfFirst { it.id == currentPageId } + 1).coerceAtLeast(1)}/${pages.size.coerceAtLeast(1)}")
                        }
                        IconButton({ showTags = true }) { Icon(Icons.Default.Label, "Tags") }
                        IconButton({ vm.updatePen { it.copy(readingMode = !it.readingMode) }; vm.setMode(EditorMode.DRAW) }) {
                            Icon(Icons.Default.MenuBook, "Reading mode")
                        }
                        Box {
                            IconButton({ plusMenu = true }) { Icon(Icons.Default.Add, "Add") }
                            DropdownMenu(plusMenu, { plusMenu = false }) {
                                DropdownMenuItem(
                                    text = { Text("New page") },
                                    onClick = { plusMenu = false; vm.addPage() }
                                )
                                DropdownMenuItem(
                                    text = { Text("Photo") },
                                    onClick = { plusMenu = false; vm.setMode(EditorMode.IMAGE); pickPhoto() }
                                )
                                DropdownMenuItem(
                                    text = { Text("Text") },
                                    onClick = { plusMenu = false; vm.setMode(EditorMode.TEXT) }
                                )
                            }
                        }
                        IconButton({ fullscreen = true }) { Icon(Icons.Default.Fullscreen, "Full screen") }
                        Box {
                            IconButton({ moreMenu = true }) { Icon(Icons.Default.MoreVert, "More") }
                            DropdownMenu(moreMenu, { moreMenu = false }) {
                                DropdownMenuItem(text = { Text("Customise toolbar") }, onClick = { moreMenu = false; showCustomize = true })
                                DropdownMenuItem(text = { Text("Note style") }, onClick = { moreMenu = false; styleDialog = true })
                                DropdownMenuItem(text = { Text("Background colour") }, onClick = { moreMenu = false; bgDialog = true })
                                DropdownMenuItem(text = { Text("Add note to folder") }, onClick = { moreMenu = false; folderDialog = true })
                                DropdownMenuItem(
                                    text = { Text(if (locked) "Remove lock" else "Lock note") },
                                    onClick = { moreMenu = false; vm.toggleLocked() }
                                )
                                DropdownMenuItem(text = { Text("Export (PNG / PDF)") }, onClick = { moreMenu = false; exportDialog = true })
                                DropdownMenuItem(
                                    text = { Text(if (pen.fingerDrawing) "Turn off finger drawing" else "Turn on finger drawing") },
                                    onClick = { vm.updatePen { it.copy(fingerDrawing = !it.fingerDrawing) }; moreMenu = false }
                                )
                                DropdownMenuItem(
                                    text = { Text("Pen debug info: " + if (pen.showDebug) "On" else "Off") },
                                    onClick = { vm.updatePen { it.copy(showDebug = !it.showDebug) }; moreMenu = false }
                                )
                                DropdownMenuItem(
                                    text = { Text("Share as text") },
                                    onClick = {
                                        moreMenu = false
                                        val send = Intent(Intent.ACTION_SEND).apply {
                                            type = "text/plain"
                                            putExtra(Intent.EXTRA_SUBJECT, title.ifBlank { "Note" })
                                            putExtra(Intent.EXTRA_TEXT, vm.plainText())
                                        }
                                        ctx.startActivity(Intent.createChooser(send, "Share note"))
                                    }
                                )
                                DropdownMenuItem(text = { Text("Clear all handwriting") }, onClick = { vm.clearAll(); moreMenu = false })
                            }
                        }
                    }
                }
            )
        },
        bottomBar = {
            when {
                pen.readingMode -> ReadingBar { vm.updatePen { it.copy(readingMode = false) } }
                mode == EditorMode.DRAW -> { if (dock == ToolbarDock.BOTTOM) drawToolbar() }
                mode == EditorMode.TEXT -> TextToolbar(focusedBlock, vm::format) { vm.setMode(EditorMode.DRAW) }
                else -> ImageToolbar(
                    onDone = { vm.setMode(EditorMode.DRAW); vm.selectImage(null) },
                    onAdd = { pickPhoto() },
                    onForward = { vm.moveSelectedImage(true) },
                    onBackward = { vm.moveSelectedImage(false) },
                    onDelete = vm::deleteSelectedImage
                )
            }
        }
    ) { pad ->
      val drawBar = mode == EditorMode.DRAW && !pen.readingMode
      Column(Modifier.padding(pad).fillMaxSize()) {
        if (drawBar && dock == ToolbarDock.TOP) drawToolbar()
        Row(Modifier.weight(1f).fillMaxWidth()) {
        if (drawBar && dock == ToolbarDock.LEFT) drawToolbar()
        Box(
            Modifier.weight(1f).fillMaxHeight().clipToBounds()
                .onSizeChanged { boxSize = it }
                .onGloballyPositioned { editorRect = it.boundsInWindow() }
        ) {
            // desk + paper + template, or the PDF pages (follows the ink viewport)
            Canvas(Modifier.fillMaxSize()) {
                val (s, tx, ty) = viewport
                val visible = RectF(-tx / s, -ty / s, (size.width - tx) / s, (size.height - ty) / s)
                val bitmapVersion = pdf?.version            // read so the canvas redraws when a PDF page arrives
                drawIntoCanvas { c ->
                    val nc = c.nativeCanvas
                    nc.save(); nc.translate(tx, ty); nc.scale(s, s)
                    if (pdf != null && pdf.contentHeight > 0f && bitmapVersion != null) {
                        TemplateRenderer.drawDesk(nc, visible, desk)
                        val range = pdf.visibleRange(visible.top, visible.bottom)
                        if (range != null) for (i in range) {
                            val r = RectF(0f, pdf.tops[i], PAGE_W, pdf.tops[i] + pdf.heights[i])
                            val b = pdf.bitmap(i)
                            if (b != null) nc.drawBitmap(b, null, r, pdfPaint) else nc.drawRect(r, whitePaint)
                        }
                    } else {
                        TemplateRenderer.draw(nc, template, visible, paper, lineInk, s, desk)
                    }
                    nc.restore()
                }
            }
            // handwriting: low-latency SurfaceView overlay (always drawn above the window)
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { c ->
                    InkSurfaceView(c).apply {
                        editListener = InkSurfaceView.EditListener { vm.onEdit(it) }
                        viewportListener = { s, x, y -> viewport = Viewport(s, x, y) }
                        selectionListener = { hasSelection = it }
                        inkView = this
                    }
                },
                update = { v ->
                    val type = pen.activeType
                    val setting = pen.active
                    v.strokes = strokes
                    v.tool = pen.tool
                    v.pen = type
                    v.penColor = setting.color
                    v.penWidth = PenSpecs.of(type).diameter(setting.size)
                    v.fingerDrawing = pen.fingerDrawing
                    v.straighten = pen.straighten
                    v.holdToShape = true     // always on: hold the pen still to snap a shape
                    v.areaEraser = pen.areaEraser
                    v.eraserSize = pen.eraserSize
                    v.shapeKind = pen.shape
                    v.lineStyle = if (pen.tool == Tool.TAPE) pen.tapePattern else pen.lineStyle
                    val recordingNow = voice.isRecording
                    v.recordingId = if (recordingNow) voice.currentName else null
                    v.recordingStart = voice.startedAt
                    v.contentHeight = pdf?.contentHeight ?: 0f
                    v.eraseHighlighterOnly = pen.eraseHighlighterOnly
                    v.readOnly = pen.readingMode
                    v.lockCanvas = pen.lockCanvas
                    v.sampleListener = if (pen.showDebug) onSample else null
                },
                onRelease = { it.release() }
            )
            // photos, then text: declared AFTER the ink view so they get the touches first in IMAGE / TEXT mode.
            // In DRAW mode they have no pointer handlers, so touches fall through to the ink view.
            val vpModifier = Modifier.graphicsLayer {
                translationX = viewport.tx; translationY = viewport.ty
                scaleX = viewport.scale; scaleY = viewport.scale
                transformOrigin = TransformOrigin(0f, 0f)
            }
            ImageLayer(
                images = images, selectedId = selectedImage,
                editable = mode == EditorMode.IMAGE && !pen.readingMode,
                fileOf = vm::imageFile, onSelect = vm::selectImage, onTransform = vm::transformImage,
                modifier = vpModifier
            )
            RichTextLayer(
                blocks = blocks,
                editable = mode == EditorMode.TEXT && !pen.readingMode,
                pendingFocus = pendingFocus,
                textColor = if (paperIsLight) Color.Black else Color.White,
                pageWidth = pageWidthDp,
                onFocus = vm::focusBlock,
                onPendingFocusConsumed = vm::pendingFocusConsumed,
                onChange = vm::changeBlock,
                onSplit = vm::splitBlock,
                onBackspaceEmpty = vm::backspaceEmpty,
                modifier = vpModifier
            )
            if (pen.showDebug) DebugHud(sample, Modifier.align(Alignment.TopStart))
            if (fullscreen) {
                IconButton({ fullscreen = false }, Modifier.align(Alignment.TopEnd).padding(8.dp)) {
                    Icon(Icons.Default.FullscreenExit, "Exit full screen")
                }
            }
        }
        if (drawBar && dock == ToolbarDock.RIGHT) drawToolbar()
        }
      }
    }

    if (showPages) {
        PagesDialog(
            pages = pages, currentId = currentPageId, version = thumbVersion, thumbOf = vm::pageFile,
            onOpen = { vm.switchPage(it); showPages = false },
            onAdd = { vm.addPage(); showPages = false },
            onMove = vm::movePage, onDelete = vm::deletePage,
            onDismiss = { showPages = false }
        )
    }

    if (showTags) {
        TagsDialog(
            tags = allTags, selected = noteTagIds.toSet(),
            onToggle = vm::toggleTag, onCreate = vm::createTag,
            onDismiss = { showTags = false }
        )
    }

    if (showVoice) {
        VoiceDialog(
            controller = voice, hasPermission = micGranted,
            onNeedPermission = { micLauncher.launch(android.Manifest.permission.RECORD_AUDIO) },
            onDismiss = { showVoice = false }
        )
    }

    if (showPad) {
        WritingPadDialog(
            onInsert = { raw, _, padH ->
                val vp = viewport
                val k = 0.5f / vp.scale                    // written big in the pad, lands at normal size on the page
                val type = if (pen.activeType == PenType.TAPE || pen.activeType.isHighlighter) pen.pen else pen.activeType
                val setting = pen.settings[type] ?: PenSetting(PenSpecs.of(type).defaultColor, PenSpecs.of(type).defaultSize)
                val left = maxOf(40f, -vp.tx / vp.scale + 40f)
                val top = (-vp.ty + boxSize.height * 0.3f) / vp.scale + padOffset
                val made = raw.map { pts ->
                    com.example.inknotes.domain.model.Stroke(
                        java.util.UUID.randomUUID().toString(), type, setting.color, PenSpecs.of(type).diameter(setting.size),
                        pts.mapIndexed { i, o ->
                            com.example.inknotes.domain.model.StrokePoint(left + o.x * k, top + o.y * k, 0.5f, 0f, 0f, i * 8L)
                        }
                    )
                }
                vm.addStrokes(made)
                padOffset += padH * k + 30f
            },
            onDismiss = { showPad = false }
        )
    }

    if (showStyle) {
        val first = inkView?.selectedStrokes()?.firstOrNull()
        ChangeStyleDialog(
            startPen = first?.pen ?: PenType.FOUNTAIN, startColor = first?.colorArgb ?: 0xFF000000.toInt(),
            onApply = { p, c, w -> inkView?.restyleSelection(p, c, w); showStyle = false },
            onDismiss = { showStyle = false }
        )
    }

    helpState?.let { st ->
        HandwritingHelpDialog(
            state = st,
            onPick = { vm.appendText(it); helpState = null },
            onDismiss = { helpState = null }
        )
    }

    if (showCustomize) {
        ToolbarCustomizeDialog(
            current = toolItems,
            onChange = { l -> vm.updatePen { it.copy(toolbar = l.map { t -> t.name }) } },
            onReset = { vm.updatePen { it.copy(toolbar = emptyList()) } },
            onDismiss = { showCustomize = false }
        )
    }

    if (styleDialog) {
        AlertDialog(
            onDismissRequest = { styleDialog = false },
            title = { Text("Note style") },
            text = {
                Column {
                    PageTemplate.entries.forEach { t ->
                        Row(
                            Modifier.fillMaxWidth().clickable { vm.setTemplate(t); styleDialog = false }.padding(vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(template == t, { vm.setTemplate(t); styleDialog = false })
                            Text(t.name.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() }, Modifier.padding(start = 8.dp))
                        }
                    }
                }
            },
            confirmButton = { TextButton({ styleDialog = false }) { Text("Close") } }
        )
    }

    if (bgDialog) {
        val colors = listOf(0xFFFFFFFF, 0xFFFFF8E1, 0xFFE8F5E9, 0xFFE3F2FD, 0xFFFCE4EC, 0xFFEDE7F6, 0xFFEEEEEE, 0xFF2B2B2B).map { it.toInt() }
        AlertDialog(
            onDismissRequest = { bgDialog = false },
            title = { Text("Background colour") },
            text = {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    colors.forEach { c ->
                        Box(
                            Modifier.size(44.dp).clip(CircleShape).background(Color(c))
                                .border(BorderStroke(if (paperColor == c) 3.dp else 1.dp, MaterialTheme.colorScheme.outline), CircleShape)
                                .clickable { vm.setPaperColor(c); bgDialog = false }
                        )
                    }
                }
            },
            confirmButton = { TextButton({ bgDialog = false }) { Text("Close") } }
        )
    }

    if (folderDialog) {
        AlertDialog(
            onDismissRequest = { folderDialog = false },
            title = { Text("Add note to") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text(
                        "No folder", Modifier.fillMaxWidth().clickable { vm.moveToFolder(null); folderDialog = false }.padding(vertical = 14.dp)
                    )
                    folders.forEach { f ->
                        Text(
                            f.folder.name,
                            Modifier.fillMaxWidth().clickable { vm.moveToFolder(f.folder.id); folderDialog = false }.padding(vertical = 14.dp)
                        )
                    }
                }
            },
            confirmButton = { TextButton({ folderDialog = false }) { Text("Close") } }
        )
    }

    if (exportDialog) {
        AlertDialog(
            onDismissRequest = { exportDialog = false },
            title = { Text("Export note") },
            text = { Text("Share as an image or a PDF (handwriting stays sharp in the PDF).") },
            confirmButton = { TextButton({ export("pdf") }) { Text("PDF") } },
            dismissButton = { TextButton({ export("png") }) { Text("Image (PNG)") } }
        )
    }

    if (exporting) {
        AlertDialog(
            onDismissRequest = { },
            title = { Text("Exporting...") },
            text = { LinearProgressIndicator(Modifier.fillMaxWidth()) },
            confirmButton = { }
        )
    }

    panel?.let { kind ->
        ToolPanelDialog(
            kind = kind, pen = pen,
            anchor = toolAnchors[
                when (kind) {
                    PanelKind.PEN -> Tool.PEN
                    PanelKind.HIGHLIGHTER -> Tool.HIGHLIGHTER
                    PanelKind.ERASER -> Tool.ERASER
                    PanelKind.SHAPE -> Tool.SHAPE
                    PanelKind.TAPE -> Tool.TAPE
                }
            ],
            dock = dock,
            update = vm::updatePen,
            onRemoveTape = vm::removeAllTape,
            onClearAll = { vm.clearAll(); panel = null },
            onPickColor = { picker = PickerTarget.PEN },
            onDismiss = { panel = null }
        )
    }

    picker?.let { target ->
        ColorPickerDialog(
            initial = pen.active.color,
            onDismiss = { picker = null },
            onPick = { c ->
                if (target == PickerTarget.PEN) vm.updatePen { it.withColor(c) } else inkView?.recolorSelection(c)
                picker = null
            }
        )
    }

    recog?.let { r ->
        AlertDialog(
            onDismissRequest = { recog = null },
            title = { Text("Handwriting to text") },
            text = {
                Column {
                    when (r) {
                        Recog.Loading -> {
                            LinearProgressIndicator(Modifier.fillMaxWidth())
                            Text("Recognising... the first time this downloads the language model (internet needed).", Modifier.padding(top = 8.dp))
                        }
                        is Recog.Done -> {
                            Text(r.text.ifBlank { "(nothing recognised)" }, style = MaterialTheme.typography.titleMedium)
                            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(r.lang == "en-US", { recognize("en-US") }, { Text("English") })
                                FilterChip(r.lang == "hi", { recognize("hi") }, { Text("हिन्दी") })
                            }
                        }
                        is Recog.Error -> Text("Could not recognise: ${r.msg}")
                    }
                }
            },
            confirmButton = {
                if (r is Recog.Done && r.text.isNotBlank()) {
                    Row {
                        TextButton({ vm.appendText(r.text); recog = null }) { Text("Insert text") }
                        TextButton({ vm.appendText(r.text); inkView?.deleteSelection(); recog = null }) { Text("Replace") }
                    }
                }
            },
            dismissButton = { TextButton({ recog = null }) { Text("Close") } }
        )
    }
}

// =============================================================== small bars
@Composable
private fun ReadingBar(onExit: () -> Unit) {
    Surface(tonalElevation = 3.dp, shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)) {
        Row(
            Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 20.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Reading mode - drawing and typing are locked", Modifier.weight(1f))
            TextButton(onExit) { Text("Exit") }
        }
    }
}

@Composable
private fun ImageToolbar(onDone: () -> Unit, onAdd: () -> Unit, onForward: () -> Unit, onBackward: () -> Unit, onDelete: () -> Unit) {
    Surface(tonalElevation = 3.dp, shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)) {
        Row(
            Modifier.navigationBarsPadding().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            ToolButton(false, onDone) { Icon(Icons.Default.Check, "Done") }
            ToolButton(false, onAdd) { Icon(Icons.Default.Image, "Add photo") }
            ToolButton(false, onForward) { Icon(Icons.Default.KeyboardArrowUp, "Bring forward") }
            ToolButton(false, onBackward) { Icon(Icons.Default.KeyboardArrowDown, "Send backward") }
            ToolButton(false, onDelete) { Icon(Icons.Default.Delete, "Delete photo") }
            Text("Drag to move, pinch to resize / rotate", Modifier.padding(start = 12.dp), style = MaterialTheme.typography.labelMedium)
        }
    }
}

@Composable
private fun DebugHud(s: PenSample?, modifier: Modifier) {
    val tool = when (s?.toolType) { 1 -> "finger"; 2 -> "stylus"; 3 -> "mouse"; 4 -> "eraser"; else -> "-" }
    val text = "tool: $tool" + (if (s?.hover == true) " (hover)" else "") +
        "\npressure: " + "%.3f".format(s?.pressure ?: 0f) +
        "\ntilt: " + "%.0f".format(Math.toDegrees((s?.tilt ?: 0f).toDouble())) + " deg" +
        "\norient: " + "%.0f".format(Math.toDegrees((s?.orientation ?: 0f).toDouble())) + " deg" +
        "\n" + (s?.stats ?: "")
    Surface(color = Color.Black.copy(alpha = 0.65f), shape = RoundedCornerShape(10.dp), modifier = modifier.padding(8.dp)) {
        Text(text, color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 12.sp, modifier = Modifier.padding(8.dp))
    }
}

// =============================================================== text formatting bar
private val textSwatches = listOf(0xFF000000, 0xFF1565C0, 0xFFC62828, 0xFF2E7D32, 0xFFF9A825, 0xFF6A1B9A, 0xFFFFFFFF)
    .map { it.toInt() }

@Composable
private fun TextToolbar(b: TextBlock, format: ((TextBlock) -> TextBlock) -> Unit, onDraw: () -> Unit) {
    Surface(color = MaterialTheme.colorScheme.surface, tonalElevation = 0.dp) {
        Column(Modifier.navigationBarsPadding().imePadding().padding(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically
            ) {
                ToolButton(false, onDraw) { ToolGlyph(Glyph.PEN, MaterialTheme.colorScheme.onSurface, Color(0xFF7086F7)) }
                FilterChip(b.bold, { format { it.copy(bold = !it.bold) } }, { Text("B", fontWeight = FontWeight.Bold) })
                FilterChip(b.italic, { format { it.copy(italic = !it.italic) } }, { Text("I", fontStyle = FontStyle.Italic) })
                FilterChip(b.underline, { format { it.copy(underline = !it.underline) } }, { Text("U", textDecoration = TextDecoration.Underline) })
                FilterChip(b.strike, { format { it.copy(strike = !it.strike) } }, { Text("S", textDecoration = TextDecoration.LineThrough) })
                FilterChip(
                    b.kind == BlockKind.BULLET,
                    { format { it.copy(kind = if (it.kind == BlockKind.BULLET) BlockKind.PARAGRAPH else BlockKind.BULLET, checked = false) } },
                    { Text("• List") }
                )
                FilterChip(
                    b.kind == BlockKind.CHECKLIST,
                    { format { it.copy(kind = if (it.kind == BlockKind.CHECKLIST) BlockKind.PARAGRAPH else BlockKind.CHECKLIST, checked = false) } },
                    { Text("Checklist") }
                )
                AssistChip({ format { it.copy(sizeSp = (it.sizeSp - 2).coerceAtLeast(12)) } }, { Text("A-") })
                AssistChip({ format { it.copy(sizeSp = (it.sizeSp + 2).coerceAtMost(48)) } }, { Text("A+") })
                AssistChip(
                    { format { it.copy(align = (it.align + 1) % 3) } },
                    { Text(when (b.align) { 1 -> "Center"; 2 -> "Right"; else -> "Left" }) }
                )
                AssistChip({ format { it.copy(indent = (it.indent - 1).coerceAtLeast(0)) } }, { Text("<-") })
                AssistChip({ format { it.copy(indent = (it.indent + 1).coerceAtMost(6)) } }, { Text("->") })
                FilterChip(
                    b.highlightArgb != 0,
                    { format { it.copy(highlightArgb = if (it.highlightArgb == 0) 0xFFFFEB3B.toInt() else 0) } },
                    { Text("Highlight") }
                )
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(
                    Modifier.size(32.dp).clip(CircleShape)
                        .border(BorderStroke(if (b.colorArgb == 0) 3.dp else 1.dp, MaterialTheme.colorScheme.outline), CircleShape)
                        .clickable { format { it.copy(colorArgb = 0) } }
                )
                textSwatches.forEach { c ->
                    Box(
                        Modifier.size(32.dp).clip(CircleShape).background(Color(c))
                            .border(BorderStroke(if (b.colorArgb == c) 3.dp else 1.dp, MaterialTheme.colorScheme.outline), CircleShape)
                            .clickable { format { it.copy(colorArgb = c) } }
                    )
                }
            }
        }
    }
}
