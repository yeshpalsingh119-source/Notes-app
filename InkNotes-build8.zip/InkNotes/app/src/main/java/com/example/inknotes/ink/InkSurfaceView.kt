package com.example.inknotes.ink

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.graphics.RectF
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.SurfaceView
import android.view.VelocityTracker
import android.widget.OverScroller
import androidx.graphics.lowlatency.CanvasFrontBufferedRenderer
import com.example.inknotes.domain.model.EditAction
import com.example.inknotes.domain.model.LineStyle
import com.example.inknotes.domain.model.PenType
import com.example.inknotes.domain.model.ShapeKind
import com.example.inknotes.domain.model.Stroke
import com.example.inknotes.domain.model.StrokePoint
import com.example.inknotes.domain.model.Tool
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** Last pen sample, for the on-screen debug HUD (is the pen really sending pressure / tilt?). */
data class PenSample(val toolType: Int, val pressure: Float, val tilt: Float, val orientation: Float, val hover: Boolean, val stats: String = "")

/**
 * Transparent ink overlay for the S Pen.
 *
 * Hot path (latency): unbuffered touch -> live stroke into the FRONT buffer. Front frames are COALESCED:
 *   a new frame is only submitted when the previous one finished, so the render thread can never fall behind
 *   (that backlog was the "lag grows while writing" problem).
 * Everything else is off the hot path:
 *   committed strokes live in a bitmap cache on a background thread, updated one stroke at a time; full rebuilds
 *   (undo / erase / zoom end) only draw strokes inside the viewport and abort when a newer request arrives.
 *   Finished-but-not-yet-cached strokes stay in [pending] and are drawn directly, so nothing ever disappears.
 * Palm: finger touches are ignored while the pen is near/touching; huge touch areas are ignored too.
 */
private const val LASER_LIFE_MS = 900L

class InkSurfaceView(context: Context) : SurfaceView(context) {

    fun interface EditListener { fun onEdit(action: EditAction) }
    private class LaserPt(val x: Float, val y: Float, val t: Long)
    private class Frame(
        val points: List<StrokePoint>?, val lasso: FloatArray?, val pending: List<Stroke>,
        val circle: FloatArray? = null, val laser: List<LaserPt>? = null
    )
    private enum class G { NONE, PEN, ERASE, LASSO, SEL_MOVE, SEL_SCALE, SHAPE, LASER }

    // ------------------------------------------------------------------ configuration (set from Compose)
    var editListener: EditListener? = null
    var viewportListener: ((scale: Float, tx: Float, ty: Float) -> Unit)? = null
    var sampleListener: ((PenSample) -> Unit)? = null
    var selectionListener: ((Boolean) -> Unit)? = null

    var tool: Tool = Tool.PEN
        set(value) {
            if (field == Tool.SELECT && value != Tool.SELECT) commitSelection()
            field = value
        }
    var pen = PenType.FOUNTAIN
    var penColor = Color.BLACK
    var penWidth = 6f
    var lineStyle = LineStyle.SOLID
    var fingerDrawing = false
    var straighten = false
    var holdToShape = false
    var eraseHighlighterOnly = false
    var areaEraser = true
    var eraserSize = 30f            // 1..100
    var shapeKind = ShapeKind.RECT
    var readOnly = false
    var lockCanvas = false          // finger pan / zoom disabled (the pen still writes)
    var recordingId: String? = null // set while a voice recording runs: new strokes remember where they were written in it
    var recordingStart = 0L         // SystemClock.elapsedRealtime() when that recording started
    var pageWidth = PAGE_W
    var contentHeight = 0f          // > 0: finite document (PDF); 0 = endless page

    // ------------------------------------------------------------------ viewport (page space -> screen)
    @Volatile private var scale = 1f
    @Volatile private var tx = 0f
    @Volatile private var ty = 0f
    private var viewportInitialized = false

    // ------------------------------------------------------------------ document
    @Volatile private var doc: List<Stroke> = emptyList()

    /** Set from Compose (load / undo / redo / clear). Local edits update [doc] directly, so the echo is skipped. */
    var strokes: List<Stroke>
        get() = doc
        set(value) {
            val cur = doc
            if (cur.size == value.size && cur.lastOrNull()?.id == value.lastOrNull()?.id) return
            doc = value
            val alive = value.map { it.id }.toHashSet()
            removePending(pending.map { it.id }.filter { it !in alive }.toSet())
            if (selected.isNotEmpty()) { selected = emptyList(); selM = Matrix(); notifySelection() }
            requestRebuild()
        }

    // ------------------------------------------------------------------ bitmap cache of committed strokes
    private val bg = Executors.newSingleThreadExecutor { r ->
        Thread(Runnable {
            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND)
            r.run()
        }, "ink-cache")
    }
    private val cacheRenderer = StrokeRenderer(false)
    private val liveRenderer = StrokeRenderer(false)
    private val cacheLock = Any()
    private var cacheBmp: Bitmap? = null
    @Volatile private var cacheScale = 1f
    @Volatile private var cacheTx = 0f
    @Volatile private var cacheTy = 0f
    @Volatile private var cachePadX = 0
    @Volatile private var cachePadY = 0
    private val rebuildCount = AtomicInteger(0)
    @Volatile private var lastRebuildMs = 0L
    private var frontFrames = 0
    private var frontSkips = 0
    @Volatile private var frontMsAvg = 0f
    @Volatile private var frontMsMax = 0f
    private var frontMaxResetAt = 0L
    @Volatile private var touching = false           // a finger is pan/zooming: no cache rebuilds meanwhile
    private val settleRunnable = Runnable { if (needsRebuild()) requestRebuild(false) }
    private val rebuildPending = AtomicBoolean(false)
    private val rebuildGen = AtomicInteger(0)
    private val boundsCache = HashMap<String, RectF>()           // bg thread only
    private val mainBounds = HashMap<String, RectF>()            // main thread only (eraser culling)
    private val bitmapPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    @Volatile private var released = false

    private val pendingLock = Any()
    @Volatile private var pending: List<Stroke> = emptyList()

    // ------------------------------------------------------------------ laser pointer (never saved, fades out)
    private val laserPts = ArrayList<LaserPt>()
    private var laserClear = false
    private val laserPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = 0xFFFF2D2D.toInt() }
    private val laserDot = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = 0xFFFF2D2D.toInt() }
    private val laserTick = object : Runnable {
        override fun run() {
            val now = SystemClock.uptimeMillis()
            while (laserPts.isNotEmpty() && now - laserPts[0].t > LASER_LIFE_MS) laserPts.removeAt(0)
            if (laserPts.isEmpty()) { laserClear = true; requestFront(); return }
            requestFront()
            postOnAnimation(this)
        }
    }

    private fun addLaser(e: MotionEvent) {
        for (h in 0 until e.historySize) laserPts.add(LaserPt(toPageX(e.getHistoricalX(h)), toPageY(e.getHistoricalY(h)), SystemClock.uptimeMillis()))
        laserPts.add(LaserPt(toPageX(e.x), toPageY(e.y), SystemClock.uptimeMillis()))
        if (laserPts.size > 400) repeat(laserPts.size - 400) { laserPts.removeAt(0) }
    }

    private fun beginLaser(e: MotionEvent) {
        gesture = G.LASER
        addLaser(e)
        removeCallbacks(laserTick)
        postOnAnimation(laserTick)
        requestFront()
    }

    private fun drawLaser(canvas: Canvas, pts: List<LaserPt>) {
        val now = SystemClock.uptimeMillis()
        val w = 6f * density / scale
        for (i in 1 until pts.size) {
            val a = (1f - (now - pts[i].t) / LASER_LIFE_MS.toFloat()).coerceIn(0f, 1f)
            if (a <= 0f) continue
            laserPaint.alpha = (a * 70).toInt()
            laserPaint.strokeWidth = w * 2.6f
            canvas.drawLine(pts[i - 1].x, pts[i - 1].y, pts[i].x, pts[i].y, laserPaint)      // glow
            laserPaint.alpha = (a * 255).toInt()
            laserPaint.strokeWidth = w * (0.45f + 0.55f * a)
            canvas.drawLine(pts[i - 1].x, pts[i - 1].y, pts[i].x, pts[i].y, laserPaint)
        }
        val last = pts.last()
        val head = (1f - (now - last.t) / 250f).coerceIn(0f, 1f)
        if (head > 0f) { laserDot.alpha = (head * 255).toInt(); canvas.drawCircle(last.x, last.y, w * 1.1f, laserDot) }
    }

    // ------------------------------------------------------------------ live gesture state
    private var gesture = G.NONE
    private var live: MutableList<StrokePoint>? = null
    private var liveIsStylus = false
    private var strokeStart = 0L
    @Volatile private var activePen = PenType.FOUNTAIN
    @Volatile private var activeColor = Color.BLACK
    @Volatile private var activeWidth = 6f
    @Volatile private var activeLineStyle = LineStyle.SOLID
    private var smoothP = -1f
    private var smoothT = -1f
    private val erased = mutableListOf<Stroke>()
    private var lastCommit = 0L
    private var lastSample = 0L
    private var penNearUntil = 0L
    private var eraseLastX = 0f
    private var eraseLastY = 0f
    private var eraseHas = false
    private val areaBefore = ArrayList<Stroke>()
    private val areaAfter = ArrayList<Stroke>()
    private val areaCreated = HashSet<String>()
    private var shapeX0 = 0f
    private var shapeY0 = 0f

    // hold to shape / straighten
    private var holdX = 0f
    private var holdY = 0f
    private var snapped: List<StrokePoint>? = null
    private val holdRunnable = Runnable {
        val pts = live
        if (gesture != G.PEN || pts == null) return@Runnable
        val s = ShapeSnap.snap(pts, holdToShape) ?: return@Runnable
        snapped = s
        performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        requestFront()
    }

    // front-buffer coalescing
    private val frontBusy = AtomicBoolean(false)
    @Volatile private var frontDirty = false
    @Volatile private var frontSubmitAt = 0L

    // ------------------------------------------------------------------ selection
    @Volatile private var selected: List<Stroke> = emptyList()
    @Volatile private var selM = Matrix()
    @Volatile private var selRect = RectF()
    private var selBase = Matrix()
    private var anchorX = 0f
    private var anchorY = 0f
    private var startDist = 1f
    private var lastPx = 0f
    private var lastPy = 0f
    private val lasso = ArrayList<Float>()

    private val density = resources.displayMetrics.density
    private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 2f * density; color = 0xFF3D7BFF.toInt()
        pathEffect = DashPathEffect(floatArrayOf(14f * density, 9f * density), 0f)
    }
    private val handleFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.WHITE }
    private val handleLine = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2f * density; color = 0xFF3D7BFF.toInt() }
    private val lassoPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0xFF3D7BFF.toInt() }
    private val lassoPath = Path()
    private val eraserPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0xFF777777.toInt() }

    // ------------------------------------------------------------------ pan / zoom / fling
    private var lastFx = 0f
    private var lastFy = 0f
    private var fx = 0f
    private var fy = 0f
    private var scaledInGesture = false
    private var vt: VelocityTracker? = null
    private val scroller = OverScroller(context)
    private val flingRunnable = object : Runnable {
        override fun run() {
            if (scroller.computeScrollOffset()) {
                tx = scroller.currX.toFloat(); ty = scroller.currY.toFloat()
                clampViewport()
                notifyViewport(false)
                postOnAnimation(this)
            } else notifyViewport(true)
        }
    }
    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            val ns = (scale * d.scaleFactor).coerceIn(0.4f, 6f)
            val k = ns / scale
            tx = d.focusX - k * (d.focusX - tx)
            ty = d.focusY - k * (d.focusY - ty)
            scale = ns
            scaledInGesture = true
            clampViewport()
            notifyViewport(false)
            return true
        }
    })

    // ------------------------------------------------------------------ renderer callbacks
    private val callback = object : CanvasFrontBufferedRenderer.Callback<Frame> {
        override fun onDrawFrontBufferedLayer(canvas: Canvas, bufferWidth: Int, bufferHeight: Int, param: Frame) {
            val t0 = System.nanoTime()
            try {
                canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
                canvas.save()
                canvas.translate(tx, ty)
                canvas.scale(scale, scale)
                for (s in param.pending) liveRenderer.draw(canvas, s)
                val lz = param.laser
                if (lz != null && lz.isNotEmpty()) drawLaser(canvas, lz)
                val pts = param.points
                val l = param.lasso
                if (pts != null) {
                    liveRenderer.drawLive(canvas, activePen, activeColor, activeWidth, activeLineStyle, pts)
                } else if (l != null && l.size >= 4) {
                    lassoPath.rewind()
                    lassoPath.moveTo(l[0], l[1])
                    var i = 2
                    while (i + 1 < l.size) { lassoPath.lineTo(l[i], l[i + 1]); i += 2 }
                    lassoPaint.strokeWidth = 2f * density / scale
                    lassoPaint.pathEffect = DashPathEffect(floatArrayOf(10f * density / scale, 7f * density / scale), 0f)
                    canvas.drawPath(lassoPath, lassoPaint)
                }
                val circle = param.circle
                if (circle != null) {
                    eraserPaint.strokeWidth = 1.5f * density / scale
                    canvas.drawCircle(circle[0], circle[1], circle[2], eraserPaint)
                }
                canvas.restore()
            } finally {
                val ms = (System.nanoTime() - t0) / 1_000_000f
                frontMsAvg = if (frontMsAvg == 0f) ms else frontMsAvg + 0.1f * (ms - frontMsAvg)
                val nowMs = SystemClock.uptimeMillis()
                if (nowMs - frontMaxResetAt > 3000) { frontMaxResetAt = nowMs; frontMsMax = ms } else if (ms > frontMsMax) frontMsMax = ms
                frontBusy.set(false)
                if (frontDirty) this@InkSurfaceView.post { requestFront() }
            }
        }

        override fun onDrawMultiBufferedLayer(canvas: Canvas, bufferWidth: Int, bufferHeight: Int, params: Collection<Frame>) {
            canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
            synchronized(cacheLock) {
                val bmp = cacheBmp
                if (bmp != null && !bmp.isRecycled) {
                    val k = scale / cacheScale
                    canvas.save()
                    canvas.translate(tx - (cachePadX + cacheTx) * k, ty - (cachePadY + cacheTy) * k)
                    canvas.scale(k, k)
                    canvas.drawBitmap(bmp, 0f, 0f, bitmapPaint)
                    canvas.restore()
                }
            }
            val pend = pending
            if (pend.isNotEmpty()) {
                canvas.save()
                canvas.translate(tx, ty)
                canvas.scale(scale, scale)
                for (s in pend) liveRenderer.draw(canvas, s)
                canvas.restore()
            }
            drawSelection(canvas)
        }
    }

    init {
        setZOrderOnTop(true)                       // above the Compose paper layer...
        holder.setFormat(PixelFormat.TRANSLUCENT)  // ...but transparent
    }

    private val renderer = CanvasFrontBufferedRenderer(this, callback)

    fun release() {
        released = true
        removeCallbacks(holdRunnable)
        removeCallbacks(flingRunnable)
        removeCallbacks(settleRunnable)
        removeCallbacks(laserTick)
        bg.shutdownNow()
        runCatching { renderer.release(true) }
        synchronized(cacheLock) { cacheBmp?.recycle(); cacheBmp = null }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (!viewportInitialized && w > 0) {
            viewportInitialized = true
            scale = min(1f, w * 0.96f / pageWidth)          // phones: fit the page width
        }
        clampViewport()
        viewportListener?.invoke(scale, tx, ty)
        requestRebuild()
    }

    /** Page stays horizontally inside the view (centred when narrower), never scrolls above its top. */
    private fun clampViewport() {
        if (width <= 0) return
        scale = scale.coerceIn(0.4f, 6f)
        val pw = pageWidth * scale
        tx = if (pw <= width) (width - pw) / 2f else tx.coerceIn(width - pw, 0f)
        val minY = if (contentHeight > 0f) min(0f, height - contentHeight * scale - 48f * density) else -Float.MAX_VALUE / 4f
        ty = ty.coerceIn(minY, 0f)
    }

    fun setViewport(s: Float, x: Float, y: Float) {
        scale = s; tx = x; ty = y
        clampViewport()
        notifyViewport(true)
    }

    // ------------------------------------------------------------------ cache management
    private fun safeCommit() {
        if (released) return
        try { renderer.commit() } catch (_: Exception) { }
    }

    private fun throttledCommit() {
        val now = SystemClock.uptimeMillis()
        if (now - lastCommit >= 8) { lastCommit = now; safeCommit() }
    }

    private fun addPending(s: Stroke) = synchronized(pendingLock) { pending = pending + s }
    private fun removePending(ids: Set<String>) = synchronized(pendingLock) {
        if (pending.isNotEmpty()) pending = pending.filterNot { it.id in ids }
    }

    private fun computeBounds(s: Stroke): RectF {
        var l = Float.MAX_VALUE; var t = Float.MAX_VALUE; var r = -Float.MAX_VALUE; var b = -Float.MAX_VALUE
        for (p in s.points) { l = min(l, p.x); t = min(t, p.y); r = max(r, p.x); b = max(b, p.y) }
        val pad = s.width * 1.6f + 4f
        return RectF(l - pad, t - pad, r + pad, b + pad)
    }

    private fun boundsOf(s: Stroke): RectF = boundsCache.getOrPut(s.id) { computeBounds(s) }
    private fun mBounds(s: Stroke): RectF = mainBounds.getOrPut(s.id) { computeBounds(s) }

    /** Cached bitmap covers the view plus a margin, so normal scrolling never needs a rebuild. */
    private fun needsRebuild(): Boolean =
        scale != cacheScale || abs(tx - cacheTx) > cachePadX * 0.7f || abs(ty - cacheTy) > cachePadY * 0.7f

    /**
     * Full re-render of the committed strokes that are inside the cached area (minus the floating selection),
     * off the main thread. [abort] = true when strokes changed (stops a running rebuild); viewport-only rebuilds
     * never abort a running one, otherwise a long scroll could starve the cache forever.
     */
    private fun requestRebuild(abort: Boolean = true) {
        if (released || width <= 0 || height <= 0) return
        if (abort) rebuildGen.incrementAndGet()
        if (!rebuildPending.compareAndSet(false, true)) return
        try {
            bg.execute {
                rebuildPending.set(false)
                val t0 = SystemClock.uptimeMillis()
                val gen = rebuildGen.get()
                val sel = selected
                val hide = if (sel.isEmpty()) emptySet() else sel.map { it.id }.toHashSet()
                val list = doc
                val s = scale; val x = tx; val y = ty
                val w = width; val h = height
                if (w <= 0 || h <= 0) return@execute
                if (boundsCache.size > 3000) boundsCache.clear()
                val padX = if (pageWidth * s > w) (w * 0.25f).toInt() else 0
                var padY = (h * (if (s > 2f) 0.3f else 0.45f)).toInt()
                while ((w + 2L * padX) * (h + 2L * padY) > 5_500_000L && padY > 0) padY -= max(1, h / 10)
                padY = max(0, padY)
                val vis = RectF((-x - padX) / s, (-y - padY) / s, (w - x + padX) / s, (h - y + padY) / s)
                val bmp = try {
                    Bitmap.createBitmap(w + 2 * padX, h + 2 * padY, Bitmap.Config.ARGB_8888)
                } catch (_: OutOfMemoryError) { return@execute }
                val c = Canvas(bmp)
                c.translate(padX + x, padY + y)
                c.scale(s, s)
                for (st in list) {
                    if (rebuildGen.get() != gen) { bmp.recycle(); return@execute }   // strokes changed: stop wasting time
                    if (st.id in hide) continue
                    if (!RectF.intersects(boundsOf(st), vis)) continue
                    cacheRenderer.draw(c, st)
                }
                synchronized(cacheLock) {
                    cacheBmp?.recycle()
                    cacheBmp = bmp; cacheScale = s; cacheTx = x; cacheTy = y
                    cachePadX = padX; cachePadY = padY
                }
                removePending(list.map { it.id }.toHashSet())
                lastRebuildMs = SystemClock.uptimeMillis() - t0
                rebuildCount.incrementAndGet()
                post { safeCommit(); if (needsRebuild() && !touching) requestRebuild(false) }
            }
        } catch (_: Exception) { rebuildPending.set(false) }
    }

    /** Draws ONE new stroke into the existing cache (cheap). */
    private fun addToCache(st: Stroke) {
        if (released) return
        try {
            bg.execute {
                var ok = false
                synchronized(cacheLock) {
                    val bmp = cacheBmp
                    if (bmp != null && !bmp.isRecycled) {
                        val c = Canvas(bmp)
                        c.translate(cachePadX + cacheTx, cachePadY + cacheTy)
                        c.scale(cacheScale, cacheScale)
                        cacheRenderer.draw(c, st)
                        ok = true
                    }
                }
                if (ok) { removePending(setOf(st.id)); post { safeCommit() } } else requestRebuild()
            }
        } catch (_: Exception) { }
    }

    // ------------------------------------------------------------------ front buffer (coalesced)
    private fun requestFront() {
        if (released) return
        val now = SystemClock.uptimeMillis()
        if (!frontBusy.compareAndSet(false, true)) {
            if (now - frontSubmitAt > 120) frontBusy.set(false)       // a callback got lost: recover
            if (!frontBusy.compareAndSet(false, true)) { frontDirty = true; frontSkips++; return }
        }
        frontFrames++
        frontDirty = false
        frontSubmitAt = now
        val f = makeFrame()
        if (f == null) { frontBusy.set(false); return }
        try { renderer.renderFrontBufferedLayer(f) } catch (_: Exception) { frontBusy.set(false) }
    }

    private fun makeFrame(): Frame? {
        if (laserPts.isNotEmpty() || laserClear) {
            val copy: List<LaserPt>? = if (laserPts.isEmpty()) null else ArrayList(laserPts)
            laserClear = false
            return Frame(null, null, pending, null, copy)
        }
        if (gesture == G.ERASE && eraseHas) return Frame(null, null, pending, floatArrayOf(eraseLastX, eraseLastY, eraserRadius()))
        if (gesture == G.LASSO && lasso.size >= 4) return Frame(null, lasso.toFloatArray(), pending)
        val sn = snapped
        if (sn != null) return Frame(sn, null, pending)
        val pts = live ?: return null
        val display = ArrayList<StrokePoint>(pts.size + 1)
        if (pts.size > 700) {
            var i = 0
            while (i < pts.size - 1) { display.add(pts[i]); i += 2 }
            display.add(pts.last())
        } else display.addAll(pts)
        if (gesture != G.SHAPE) predictedTail(pts)?.let { display.add(it) }
        return Frame(display, null, pending)
    }

    // ------------------------------------------------------------------ touch
    override fun onHoverEvent(e: MotionEvent): Boolean {
        val t = e.getToolType(0)
        if (t == MotionEvent.TOOL_TYPE_STYLUS || t == MotionEvent.TOOL_TYPE_ERASER) penNearUntil = SystemClock.uptimeMillis() + 800
        emitSample(e, true)
        return super.onHoverEvent(e)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val now = SystemClock.uptimeMillis()
        val type = e.getToolType(0)
        val isStylus = type == MotionEvent.TOOL_TYPE_STYLUS || type == MotionEvent.TOOL_TYPE_ERASER
        if (e.actionMasked == MotionEvent.ACTION_DOWN) stopFling()
        if (isStylus) penNearUntil = now + 800
        emitSample(e, false)

        if (readOnly) return handleGesture(e)                          // reading mode: pen AND finger scroll

        if (!isStylus) {
            if (now < penNearUntil || e.getTouchMajor(0) > 48f * density) return true     // palm rejection
            if (gesture != G.NONE && liveIsStylus) return true
            val drawWithFinger = fingerDrawing && e.pointerCount == 1 &&
                (gesture != G.NONE || e.actionMasked == MotionEvent.ACTION_DOWN)
            if (!drawWithFinger) {
                if (gesture != G.NONE) cancelGesture()
                return handleGesture(e)
            }
        }

        val erasing = tool == Tool.ERASER ||
            type == MotionEvent.TOOL_TYPE_ERASER ||
            (e.buttonState and MotionEvent.BUTTON_STYLUS_PRIMARY) != 0

        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                requestUnbufferedDispatch(e)                              // deliver touch events immediately, not per vsync
                parent?.requestDisallowInterceptTouchEvent(true)
                liveIsStylus = isStylus
                val px = toPageX(e.x)
                if (px < 0f || px > pageWidth) return true                // grey desk: ignore
                when {
                    erasing -> { gesture = G.ERASE; eraseHas = false; erase(e) }
                    tool == Tool.SELECT -> beginSelect(e)
                    tool == Tool.SHAPE -> beginShape(e)
                    tool == Tool.LASER -> beginLaser(e)
                    else -> { gesture = G.PEN; beginStroke(e) }
                }
            }
            MotionEvent.ACTION_MOVE -> when (gesture) {
                G.PEN -> extendStroke(e)
                G.ERASE -> erase(e)
                G.SHAPE -> dragShape(e)
                G.LASER -> { addLaser(e); requestFront() }
                G.LASSO -> extendLasso(e)
                G.SEL_MOVE, G.SEL_SCALE -> dragSelection(e)
                G.NONE -> Unit
            }
            MotionEvent.ACTION_UP -> finishGesture(e)
            MotionEvent.ACTION_CANCEL -> cancelGesture()
        }
        return true
    }

    private fun emitSample(e: MotionEvent, hover: Boolean) {
        val l = sampleListener ?: return
        if (e.eventTime - lastSample < 33) return
        lastSample = e.eventTime
        l(PenSample(e.getToolType(0), e.pressure, e.getAxisValue(MotionEvent.AXIS_TILT), e.getAxisValue(MotionEvent.AXIS_ORIENTATION), hover, statsText()))
    }

    private fun statsText() =
        "strokes ${doc.size}  pending ${pending.size}\nrebuild ${lastRebuildMs} ms (x${rebuildCount.get()})  pad ${cachePadX}/${cachePadY}\nfront draw ${"%.1f".format(frontMsAvg)} ms (max ${"%.1f".format(frontMsMax)})\nfront frames ${frontFrames}  skipped ${frontSkips}  merged ${if (frontFrames + frontSkips > 0) 100 * frontSkips / (frontFrames + frontSkips) else 0}%  zoom ${"%.2f".format(scale)}"

    private fun toPageX(x: Float) = (x - tx) / scale
    private fun toPageY(y: Float) = (y - ty) / scale

    // ------------------------------------------------------------------ pen
    private fun point(e: MotionEvent, h: Int): StrokePoint {
        val x: Float; val y: Float; val p: Float; val t: Float; val o: Float; val time: Long
        if (h < 0) {
            x = e.x; y = e.y; p = e.pressure
            t = e.getAxisValue(MotionEvent.AXIS_TILT); o = e.getAxisValue(MotionEvent.AXIS_ORIENTATION)
            time = e.eventTime
        } else {
            x = e.getHistoricalX(h); y = e.getHistoricalY(h); p = e.getHistoricalPressure(h)
            t = e.getHistoricalAxisValue(MotionEvent.AXIS_TILT, 0, h)
            o = e.getHistoricalAxisValue(MotionEvent.AXIS_ORIENTATION, 0, h)
            time = e.getHistoricalEventTime(h)
        }
        val sp: Float
        val st: Float
        if (liveIsStylus) {
            smoothP = if (smoothP < 0f) p else smoothP + 0.45f * (p - smoothP)
            smoothT = if (smoothT < 0f) t else smoothT + 0.4f * (t - smoothT)
            sp = smoothP; st = smoothT
        } else { sp = 0.5f; st = 0f }
        return StrokePoint(toPageX(x), toPageY(y), sp, st, o, time - strokeStart)
    }

    private fun holdEnabled() = straighten || holdToShape

    private fun beginStroke(e: MotionEvent) {
        activePen = pen; activeColor = penColor; activeWidth = penWidth; activeLineStyle = lineStyle
        strokeStart = e.eventTime
        smoothP = -1f; smoothT = -1f
        snapped = null
        val list = ArrayList<StrokePoint>(256)
        val first = point(e, -1)
        list.add(first)
        live = list
        holdX = first.x; holdY = first.y
        removeCallbacks(holdRunnable)
        if (holdEnabled()) postDelayed(holdRunnable, 450)
        requestFront()
    }

    private fun extendStroke(e: MotionEvent) {
        val pts = live ?: return
        for (h in 0 until e.historySize) addPoint(pts, point(e, h))
        addPoint(pts, point(e, -1))
        val last = pts.last()
        if (hypot(last.x - holdX, last.y - holdY) * scale > 8f) {      // pen moved: restart the hold timer
            holdX = last.x; holdY = last.y
            snapped = null
            removeCallbacks(holdRunnable)
            if (holdEnabled()) postDelayed(holdRunnable, 450)
        }
        requestFront()
    }

    private fun addPoint(pts: MutableList<StrokePoint>, p: StrokePoint) {
        val l = pts.last()
        if (hypot(p.x - l.x, p.y - l.y) * scale < 0.8f) return      // drop sub-pixel samples
        pts.add(p)
    }

    /** Display-only guess ~14 ms ahead of the pen tip: hides most of the remaining pipeline latency. */
    private fun predictedTail(pts: List<StrokePoint>): StrokePoint? {
        val n = pts.size
        if (n < 3) return null
        val a = pts[n - 3]; val b = pts[n - 1]
        val dt = (b.tMs - a.tMs).toFloat()
        if (dt <= 0f) return null
        var px = (b.x - a.x) / dt * 14f
        var py = (b.y - a.y) / dt * 14f
        val len = hypot(px, py)
        val maxLen = 28f / scale
        if (len > maxLen) { px *= maxLen / len; py *= maxLen / len }
        return StrokePoint(b.x + px, b.y + py, b.pressure, b.tilt, b.orientation, b.tMs + 14)
    }

    private fun finishStroke(e: MotionEvent) {
        val pts = live ?: return
        live = null
        removeCallbacks(holdRunnable)
        addPoint(pts, point(e, -1))
        var finalPts: List<StrokePoint> = snapped ?: pts.toList()
        if (snapped == null && straighten) ShapeSnap.snap(pts, false)?.let { finalPts = it }
        snapped = null
        commitStroke(finalPts)
    }

    private fun commitStroke(finalPts: List<StrokePoint>) {
        val rec = recordingId
        val stroke = Stroke(
            UUID.randomUUID().toString(), activePen, activeColor, activeWidth, finalPts,
            recordingId = rec,
            recordingOffsetMs = if (rec != null) SystemClock.elapsedRealtime() - recordingStart else null,
            lineStyle = activeLineStyle
        )
        doc = doc + stroke
        addPending(stroke)                            // stays visible until the cache has it
        addToCache(stroke)
        editListener?.onEdit(EditAction.Add(listOf(stroke)))
    }

    // ------------------------------------------------------------------ shape tool (drag to draw)
    private fun beginShape(e: MotionEvent) {
        activePen = pen; activeColor = penColor; activeWidth = penWidth; activeLineStyle = lineStyle
        strokeStart = e.eventTime
        shapeX0 = toPageX(e.x); shapeY0 = toPageY(e.y)
        gesture = G.SHAPE
        live = ArrayList()
    }

    private fun dragShape(e: MotionEvent) {
        val pts = ShapeSnap.shape(shapeKind, shapeX0, shapeY0, toPageX(e.x), toPageY(e.y), 0.7f)
        if (pts.isEmpty()) return
        live = pts.toMutableList()
        requestFront()
    }

    private fun finishShape() {
        val pts = live
        live = null
        if (pts != null && pts.size >= 2) commitStroke(pts)
    }

    private fun cancelGesture() {
        live = null
        snapped = null
        removeCallbacks(holdRunnable)
        if (gesture == G.LASER) { laserPts.clear(); laserClear = true; removeCallbacks(laserTick) }
        lasso.clear()
        erased.clear()
        areaBefore.clear(); areaAfter.clear(); areaCreated.clear()
        eraseHas = false
        gesture = G.NONE
        frontBusy.set(false)
        if (!released) try { renderer.cancel() } catch (_: Exception) { }
    }

    private fun finishGesture(e: MotionEvent) {
        when (gesture) {
            G.PEN -> finishStroke(e)
            G.ERASE -> finishErase()
            G.SHAPE -> finishShape()
            G.LASER -> Unit                              // the trail keeps fading by itself
            G.LASSO -> finishLasso()
            G.SEL_MOVE, G.SEL_SCALE -> safeCommit()
            G.NONE -> Unit
        }
        gesture = G.NONE
    }

    // ------------------------------------------------------------------ erasers (stroke + area)
    private fun eraserRadius(): Float = (4f + eraserSize * 0.36f) * density / scale

    private fun erase(e: MotionEvent) { if (areaEraser) eraseArea(e) else eraseAt(e) }

    /** Eraser samples (page space) of this event, prefixed by the last position of the previous event. */
    private fun eraserPath(e: MotionEvent): Pair<FloatArray, FloatArray> {
        val n = e.historySize + 1
        val m = if (eraseHas) n + 1 else n
        val ex = FloatArray(m); val ey = FloatArray(m)
        var k = 0
        if (eraseHas) { ex[0] = eraseLastX; ey[0] = eraseLastY; k = 1 }
        for (i in 0 until n) {
            ex[k + i] = toPageX(if (i < e.historySize) e.getHistoricalX(i) else e.x)
            ey[k + i] = toPageY(if (i < e.historySize) e.getHistoricalY(i) else e.y)
        }
        eraseLastX = ex[m - 1]; eraseLastY = ey[m - 1]; eraseHas = true
        return ex to ey
    }

    private fun pathBox(ex: FloatArray, ey: FloatArray, r: Float): RectF {
        var l = Float.MAX_VALUE; var t = Float.MAX_VALUE; var rr = -Float.MAX_VALUE; var b = -Float.MAX_VALUE
        for (i in ex.indices) { l = min(l, ex[i]); t = min(t, ey[i]); rr = max(rr, ex[i]); b = max(b, ey[i]) }
        return RectF(l - r, t - r, rr + r, b + r)
    }

    /** Stroke eraser: touching a stroke removes it completely. */
    private fun eraseAt(e: MotionEvent) {
        val r = eraserRadius()
        val (ex, ey) = eraserPath(e)
        val box = pathBox(ex, ey, r)
        if (mainBounds.size > 4000) mainBounds.clear()
        val hits = HashSet<String>()
        for (s in doc) {
            if (eraseHighlighterOnly && !s.pen.isHighlighter) continue
            if (!RectF.intersects(mBounds(s), box)) continue
            if (touches(s, ex, ey, r)) hits.add(s.id)
        }
        if (hits.isNotEmpty()) {
            erased += doc.filter { it.id in hits }
            doc = doc.filterNot { it.id in hits }
            removePending(hits)
            requestRebuild()
        }
        requestFront()
    }

    /** Area eraser: cuts the stroke where the eraser passes; the remaining parts stay as separate strokes. */
    private fun eraseArea(e: MotionEvent) {
        val r = eraserRadius()
        val (ex, ey) = eraserPath(e)
        val box = pathBox(ex, ey, r)
        if (mainBounds.size > 4000) mainBounds.clear()
        var changed = false
        val out = ArrayList<Stroke>(doc.size)
        for (s in doc) {
            if ((eraseHighlighterOnly && !s.pen.isHighlighter) || !RectF.intersects(mBounds(s), box)) { out.add(s); continue }
            val pieces = cutStroke(s, ex, ey, r)
            if (pieces == null) { out.add(s); continue }
            changed = true
            removePending(setOf(s.id))
            if (s.id in areaCreated) areaAfter.removeAll { it.id == s.id } else areaBefore.add(s)
            for (p in pieces) { out.add(p); areaAfter.add(p); areaCreated.add(p.id) }
        }
        if (changed) { doc = out; requestRebuild() }
        requestFront()
    }

    private fun cutStroke(s: Stroke, ex: FloatArray, ey: FloatArray, r: Float): List<Stroke>? {
        val src = s.points
        if (src.isEmpty()) return null
        val step = max(2f, r * 0.4f)
        val dense = ArrayList<StrokePoint>(src.size * 2)
        dense.add(src[0])
        for (i in 1 until src.size) {
            val a = src[i - 1]; val b = src[i]
            val k = (hypot(b.x - a.x, b.y - a.y) / step).toInt()
            for (j in 1..k) {
                val t = j / (k + 1f)
                dense.add(StrokePoint(
                    a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t,
                    a.pressure + (b.pressure - a.pressure) * t, a.tilt + (b.tilt - a.tilt) * t,
                    a.orientation, a.tMs + ((b.tMs - a.tMs) * t).toLong()
                ))
            }
            dense.add(b)
        }
        val gone = BooleanArray(dense.size)
        var any = false
        for (i in dense.indices) {
            val p = dense[i]
            var hit = false
            if (ex.size == 1) hit = hypot(p.x - ex[0], p.y - ey[0]) <= r
            else for (j in 1 until ex.size) if (segDistXY(p.x, p.y, ex[j - 1], ey[j - 1], ex[j], ey[j]) <= r) { hit = true; break }
            if (hit) { gone[i] = true; any = true }
        }
        if (!any) return null
        val out = ArrayList<Stroke>()
        var run = ArrayList<StrokePoint>()
        for (i in dense.indices) {
            if (gone[i]) {
                if (run.size >= 2) out.add(s.copy(id = UUID.randomUUID().toString(), points = run))
                run = ArrayList()
            } else run.add(dense[i])
        }
        if (run.size >= 2) out.add(s.copy(id = UUID.randomUUID().toString(), points = run))
        return out
    }

    private fun finishErase() {
        eraseHas = false
        if (erased.isNotEmpty()) { editListener?.onEdit(EditAction.Remove(erased.toList())); erased.clear() }
        if (areaBefore.isNotEmpty()) {
            val before = areaBefore.toList()
            val after = areaAfter.toList()
            val afterIds = after.map { it.id }.toHashSet()
            doc = doc.filterNot { it.id in afterIds } + after            // same order the ViewModel will produce
            editListener?.onEdit(EditAction.Replace(before, after))
            areaBefore.clear(); areaAfter.clear()
        }
        areaCreated.clear()
        safeCommit()                                                      // removes the eraser circle
    }

    private fun segDistXY(px: Float, py: Float, ax: Float, ay: Float, bx: Float, by: Float): Float {
        val dx = bx - ax; val dy = by - ay
        val l2 = dx * dx + dy * dy
        val t = if (l2 == 0f) 0f else (((px - ax) * dx + (py - ay) * dy) / l2).coerceIn(0f, 1f)
        return hypot(px - (ax + t * dx), py - (ay + t * dy))
    }

    private fun touches(s: Stroke, ex: FloatArray, ey: FloatArray, r: Float): Boolean {
        val p = s.points
        for (q in p.indices) {
            val pt = p[q]
            if (ex.size == 1) { if (hypot(pt.x - ex[0], pt.y - ey[0]) <= r) return true; continue }
            for (j in 1 until ex.size) if (segDistXY(pt.x, pt.y, ex[j - 1], ey[j - 1], ex[j], ey[j]) <= r) return true
        }
        return false
    }

    // ------------------------------------------------------------------ select (lasso)
    private fun beginSelect(e: MotionEvent) {
        val px = toPageX(e.x); val py = toPageY(e.y)
        if (selected.isNotEmpty()) {
            val b = RectF(selRect).also { selM.mapRect(it) }
            val corners = arrayOf(
                floatArrayOf(b.left, b.top, b.right, b.bottom), floatArrayOf(b.right, b.top, b.left, b.bottom),
                floatArrayOf(b.right, b.bottom, b.left, b.top), floatArrayOf(b.left, b.bottom, b.right, b.top)
            )
            for (c in corners) {      // [corner x, corner y, opposite x, opposite y]
                if (hypot(e.x - (c[0] * scale + tx), e.y - (c[1] * scale + ty)) < 32f * density) {
                    gesture = G.SEL_SCALE
                    anchorX = c[2]; anchorY = c[3]
                    startDist = max(1f, hypot(px - anchorX, py - anchorY))
                    selBase = Matrix(selM)
                    return
                }
            }
            if (b.contains(px, py)) { gesture = G.SEL_MOVE; lastPx = px; lastPy = py; return }
            commitSelection()
        }
        gesture = G.LASSO
        lasso.clear(); lasso.add(px); lasso.add(py)
        requestFront()
    }

    private fun extendLasso(e: MotionEvent) {
        val px = toPageX(e.x); val py = toPageY(e.y)
        val n = lasso.size
        if (hypot(px - lasso[n - 2], py - lasso[n - 1]) * scale < 3f) return
        lasso.add(px); lasso.add(py)
        requestFront()
    }

    private fun finishLasso() {
        val poly = lasso.toFloatArray()
        lasso.clear()
        if (poly.size >= 6) {
            val picked = doc.filter { s -> s.points.isNotEmpty() && s.points.count { inside(poly, it.x, it.y) } * 2 >= s.points.size }
            if (picked.isNotEmpty()) select(picked)
        }
        safeCommit()                                   // clears the lasso from the front buffer
    }

    private fun inside(poly: FloatArray, x: Float, y: Float): Boolean {
        var c = false
        val n = poly.size / 2
        var j = n - 1
        for (i in 0 until n) {
            val xi = poly[2 * i]; val yi = poly[2 * i + 1]; val xj = poly[2 * j]; val yj = poly[2 * j + 1]
            if ((yi > y) != (yj > y) && x < (xj - xi) * (y - yi) / (yj - yi) + xi) c = !c
            j = i
        }
        return c
    }

    private fun select(list: List<Stroke>) {
        var l = Float.MAX_VALUE; var t = Float.MAX_VALUE; var r = -Float.MAX_VALUE; var b = -Float.MAX_VALUE
        for (s in list) {
            val pad = s.width / 2f
            for (p in s.points) { l = min(l, p.x - pad); t = min(t, p.y - pad); r = max(r, p.x + pad); b = max(b, p.y + pad) }
        }
        selRect = RectF(l, t, r, b)
        selM = Matrix()
        selected = list
        removePending(list.map { it.id }.toHashSet())
        notifySelection()
        requestRebuild()                               // rebuild cache without the floating strokes
    }

    private fun dragSelection(e: MotionEvent) {
        val px = toPageX(e.x); val py = toPageY(e.y)
        if (gesture == G.SEL_MOVE) {
            val m = Matrix(selM); m.postTranslate(px - lastPx, py - lastPy); selM = m
            lastPx = px; lastPy = py
        } else {
            val f = (hypot(px - anchorX, py - anchorY) / startDist).coerceIn(0.1f, 10f)
            val m = Matrix(selBase); m.postScale(f, f, anchorX, anchorY); selM = m
        }
        throttledCommit()
    }

    private fun drawSelection(canvas: Canvas) {
        val sel = selected
        if (sel.isEmpty()) return
        val m = selM
        canvas.save()
        canvas.translate(tx, ty); canvas.scale(scale, scale); canvas.concat(m)
        for (s in sel) liveRenderer.draw(canvas, s)
        canvas.restore()
        val r = RectF(selRect); m.mapRect(r)
        val l = r.left * scale + tx; val t = r.top * scale + ty
        val rr = r.right * scale + tx; val b = r.bottom * scale + ty
        canvas.drawRect(l, t, rr, b, boxPaint)
        for ((cx, cy) in listOf(l to t, rr to t, rr to b, l to b)) {
            canvas.drawCircle(cx, cy, 9f * density, handleFill)
            canvas.drawCircle(cx, cy, 9f * density, handleLine)
        }
    }

    private fun notifySelection() { post { selectionListener?.invoke(selected.isNotEmpty()) } }

    fun selectedStrokes(): List<Stroke> = selected

    /** Applies the pending move/scale to the document (undoable) and returns the resulting strokes. */
    fun commitSelection(): List<Stroke> {
        val sel = selected
        if (sel.isEmpty()) return emptyList()
        val m = selM
        if (m.isIdentity) {
            selected = emptyList(); notifySelection(); requestRebuild(); safeCommit()
            return sel
        }
        val after = sel.map { transformed(it, m) }
        val ids = sel.map { it.id }.toHashSet()
        removePending(ids)
        doc = doc.filterNot { it.id in ids } + after
        selected = emptyList(); selM = Matrix(); notifySelection()
        editListener?.onEdit(EditAction.Replace(sel, after))
        requestRebuild(); safeCommit()
        return after
    }

    fun deleteSelection() {
        val sel = selected
        if (sel.isEmpty()) return
        val ids = sel.map { it.id }.toHashSet()
        removePending(ids)
        doc = doc.filterNot { it.id in ids }
        selected = emptyList(); selM = Matrix(); notifySelection()
        editListener?.onEdit(EditAction.Remove(sel))
        requestRebuild(); safeCommit()
    }

    fun duplicateSelection() {
        val base = commitSelection()
        if (base.isEmpty()) return
        val copies = base.map { s ->
            s.copy(id = UUID.randomUUID().toString(), points = s.points.map { it.copy(x = it.x + 40f, y = it.y + 40f) })
        }
        doc = doc + copies
        editListener?.onEdit(EditAction.Add(copies))
        select(copies)
    }

    /** Levels slanted handwriting: rotates the selection so its text line becomes horizontal (undoable). */
    fun alignSelection() {
        val sel = selected
        if (sel.isEmpty()) return
        var n = 0
        var mx = 0.0; var my = 0.0
        for (s in sel) for (p in s.points) { mx += p.x; my += p.y; n++ }
        if (n < 3) return
        mx /= n; my /= n
        var sxx = 0.0; var syy = 0.0; var sxy = 0.0
        for (s in sel) for (p in s.points) {
            val dx = p.x - mx; val dy = p.y - my
            sxx += dx * dx; syy += dy * dy; sxy += dx * dy
        }
        var deg = Math.toDegrees(0.5 * atan2(2.0 * sxy, sxx - syy)).toFloat()      // direction of the text line
        if (abs(deg) > 45f || abs(deg) < 0.4f) return
        val r = RectF(selRect); selM.mapRect(r)
        val m = Matrix(selM)
        m.postRotate(-deg, r.centerX(), r.centerY())
        selM = m
        val done = commitSelection()
        if (done.isNotEmpty()) select(done)
    }

    fun recolorSelection(color: Int) {
        val base = commitSelection()
        if (base.isEmpty()) return
        val recolored = base.map { it.copy(id = UUID.randomUUID().toString(), colorArgb = color) }
        val ids = base.map { it.id }.toHashSet()
        removePending(ids)
        doc = doc.filterNot { it.id in ids } + recolored
        editListener?.onEdit(EditAction.Replace(base, recolored))
        select(recolored)
    }

    /** Change style: gives the selected strokes another pen, colour and thickness (undoable). */
    fun restyleSelection(newPen: PenType, color: Int, width: Float) {
        val base = commitSelection()
        if (base.isEmpty()) return
        val styled = base.map { it.copy(id = UUID.randomUUID().toString(), pen = newPen, colorArgb = color, width = width) }
        val ids = base.map { it.id }.toHashSet()
        removePending(ids)
        doc = doc.filterNot { it.id in ids } + styled
        editListener?.onEdit(EditAction.Replace(base, styled))
        select(styled)
    }

    fun scrollToTop() {
        ty = 0f
        clampViewport()
        notifyViewport(true)
    }

    private fun transformed(s: Stroke, m: Matrix): Stroke {
        val v = FloatArray(9)
        m.getValues(v)
        val k = sqrt(v[Matrix.MSCALE_X] * v[Matrix.MSCALE_X] + v[Matrix.MSKEW_Y] * v[Matrix.MSKEW_Y])
        val xy = FloatArray(s.points.size * 2)
        s.points.forEachIndexed { i, p -> xy[2 * i] = p.x; xy[2 * i + 1] = p.y }
        m.mapPoints(xy)
        return Stroke(
            UUID.randomUUID().toString(), s.pen, s.colorArgb, s.width * k,
            s.points.mapIndexed { i, p -> p.copy(x = xy[2 * i], y = xy[2 * i + 1]) },
            lineStyle = s.lineStyle
        )
    }

    // ------------------------------------------------------------------ pan / pinch / fling (finger, or pen in reading mode)
    private fun stopFling() {
        removeCallbacks(flingRunnable)
        if (!scroller.isFinished) { scroller.abortAnimation(); notifyViewport(true) }
    }

    private fun handleGesture(e: MotionEvent): Boolean {
        if (lockCanvas) return true
        scaleDetector.onTouchEvent(e)
        if (e.actionMasked == MotionEvent.ACTION_DOWN) {
            touching = true
            removeCallbacks(settleRunnable)
            scaledInGesture = false
            vt?.recycle(); vt = VelocityTracker.obtain()
        }
        vt?.addMovement(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> { focal(e, -1); lastFx = fx; lastFy = fy }
            MotionEvent.ACTION_POINTER_UP -> { focal(e, e.actionIndex); lastFx = fx; lastFy = fy }
            MotionEvent.ACTION_MOVE -> {
                focal(e, -1)
                tx += fx - lastFx; ty += fy - lastFy
                lastFx = fx; lastFy = fy
                clampViewport()
                notifyViewport(false)
            }
            MotionEvent.ACTION_UP -> {
                val tracker = vt
                var flung = false
                if (tracker != null && !scaledInGesture) {
                    tracker.computeCurrentVelocity(1000, 12000f)
                    val vx = tracker.xVelocity; val vy = tracker.yVelocity
                    if (hypot(vx, vy) > 400f) {
                        val pw = pageWidth * scale
                        val minX = if (pw <= width) tx.toInt() else (width - pw).toInt()
                        val maxX = if (pw <= width) tx.toInt() else 0
                        val minY = if (contentHeight > 0f) min(0, (height - contentHeight * scale - 48f * density).toInt()) else -2_000_000
                        scroller.fling(tx.toInt(), ty.toInt(), vx.toInt(), vy.toInt(), minX, maxX, minY, 0)
                        postOnAnimation(flingRunnable)
                        flung = true
                    }
                }
                vt?.recycle(); vt = null
                touching = false
                if (!flung) notifyViewport(true)
            }
            MotionEvent.ACTION_CANCEL -> { vt?.recycle(); vt = null; touching = false; notifyViewport(true) }
        }
        return true
    }

    private fun focal(e: MotionEvent, skip: Int) {
        var x = 0f; var y = 0f; var n = 0
        for (i in 0 until e.pointerCount) { if (i == skip) continue; x += e.getX(i); y += e.getY(i); n++ }
        if (n > 0) { fx = x / n; fy = y / n }
    }

    private fun notifyViewport(final: Boolean) {
        if (final) {
            removeCallbacks(settleRunnable)
            // after a zoom wait a moment so a second pinch does not start a rebuild that is thrown away at once
            if (scale != cacheScale && needsRebuild()) postDelayed(settleRunnable, 140)
            else if (needsRebuild()) requestRebuild(false)
            safeCommit()
        } else {
            throttledCommit()                          // while moving: just blit the cached bitmap
            if (scale == cacheScale && needsRebuild()) requestRebuild(false)    // scrolled past the cached margin
        }
        viewportListener?.invoke(scale, tx, ty)
    }
}
