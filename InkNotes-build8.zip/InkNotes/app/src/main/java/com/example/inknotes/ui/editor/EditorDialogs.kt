package com.example.inknotes.ui.editor

import android.graphics.BitmapFactory
import android.text.format.DateUtils
import android.view.Gravity
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import com.example.inknotes.data.db.PageEntity
import com.example.inknotes.data.db.TagWithCount
import com.example.inknotes.domain.model.PenType
import com.example.inknotes.ink.PenSpecs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File

// =============================================================== customisable toolbar ("Available tools")
enum class ToolbarItem(val label: String) {
    TEXT("Text"), PEN("Pen"), HIGHLIGHTER("Highlighter"), TAPE("Tape"), ERASER("Eraser"), LASSO("Lasso select"),
    CONVERT("S Pen to text"), CLEANUP("Clean up handwriting"), STYLE("Change style"), HELP("Handwriting help"),
    SHAPES("Shapes"), LASER("Laser pointer"), PHOTO("Photo"), PAD("Easy writing pad"), VOICE("Voice recording"),
    LOCK("Lock canvas"), COLORS("Pen colour"), THICKNESS("Pen thickness"), UNDO("Undo"), REDO("Redo"),
    FAVORITES("Favourite pens")
}

/** Saved names -> items in order; nothing saved (or nothing valid) = every tool in the default order. */
fun resolveToolbar(saved: List<String>): List<ToolbarItem> {
    if (saved.isEmpty()) return ToolbarItem.entries.toList()
    val list = saved.mapNotNull { n -> ToolbarItem.entries.firstOrNull { it.name == n } }.distinct()
    return list.ifEmpty { ToolbarItem.entries.toList() }
}

@Composable
fun ToolbarCustomizeDialog(
    current: List<ToolbarItem>,
    onChange: (List<ToolbarItem>) -> Unit,
    onReset: () -> Unit,
    onDismiss: () -> Unit
) {
    val hidden = ToolbarItem.entries.filter { it !in current }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Available tools") },
        text = {
            LazyColumn(Modifier.heightIn(max = 440.dp)) {
                item { Text("Arrows change the order, \u2715 removes a tool from the toolbar.", style = MaterialTheme.typography.bodySmall) }
                itemsIndexed(current) { i, t ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(t.label, Modifier.weight(1f))
                        IconButton(
                            onClick = { onChange(current.toMutableList().also { l -> l.add(i - 1, l.removeAt(i)) }) },
                            enabled = i > 0
                        ) { Icon(Icons.Default.ArrowUpward, "Move up") }
                        IconButton(
                            onClick = { onChange(current.toMutableList().also { l -> l.add(i + 1, l.removeAt(i)) }) },
                            enabled = i < current.lastIndex
                        ) { Icon(Icons.Default.ArrowDownward, "Move down") }
                        IconButton(onClick = { if (current.size > 1) onChange(current - t) }) { Icon(Icons.Default.Close, "Remove") }
                    }
                }
                if (hidden.isNotEmpty()) {
                    item { Text("Hidden tools", Modifier.padding(top = 12.dp), style = MaterialTheme.typography.titleSmall) }
                    items(hidden) { t ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(t.label, Modifier.weight(1f))
                            IconButton(onClick = { onChange(current + t) }) { Icon(Icons.Default.Add, "Add") }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onDismiss) { Text("Done") } },
        dismissButton = { TextButton(onReset) { Text("Reset") } }
    )
}

// =============================================================== page sorter
@Composable
private fun PageThumb(file: File, version: Int, modifier: Modifier) {
    val bmp by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, file, version) {
        value = withContext(Dispatchers.IO) {
            runCatching { BitmapFactory.decodeFile(file.absolutePath)?.asImageBitmap() }.getOrNull()
        }
    }
    Box(modifier.background(Color.White).border(1.dp, MaterialTheme.colorScheme.outlineVariant)) {
        bmp?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
    }
}

@Composable
fun PagesDialog(
    pages: List<PageEntity>,
    currentId: Long,
    version: Int,
    thumbOf: (Long) -> File,
    onOpen: (Long) -> Unit,
    onAdd: () -> Unit,
    onMove: (Long, Int) -> Unit,
    onDelete: (Long) -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Card(Modifier.fillMaxWidth(0.92f).widthIn(max = 520.dp).heightIn(max = 640.dp), shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Pages (${pages.size})", Modifier.weight(1f), style = MaterialTheme.typography.titleLarge)
                    IconButton(onDismiss) { Icon(Icons.Default.Close, "Close") }
                }
                LazyColumn(Modifier.weight(1f, fill = false)) {
                    itemsIndexed(pages, key = { _, p -> p.id }) { i, p ->
                        val current = p.id == currentId
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 6.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(if (current) MaterialTheme.colorScheme.secondaryContainer else Color.Transparent)
                                .clickable { onOpen(p.id) }
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            PageThumb(thumbOf(p.id), version, Modifier.width(72.dp).height(100.dp))
                            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                                Text("Page ${i + 1}", style = MaterialTheme.typography.titleMedium)
                                if (current) Text("Open now", style = MaterialTheme.typography.bodySmall)
                            }
                            IconButton(onClick = { onMove(p.id, -1) }, enabled = i > 0) { Icon(Icons.Default.ArrowUpward, "Move up") }
                            IconButton(onClick = { onMove(p.id, 1) }, enabled = i < pages.lastIndex) { Icon(Icons.Default.ArrowDownward, "Move down") }
                            IconButton(onClick = { onDelete(p.id) }, enabled = pages.size > 1) { Icon(Icons.Default.Delete, "Delete page") }
                        }
                    }
                }
                Button(onAdd, Modifier.fillMaxWidth().padding(top = 8.dp)) {
                    Icon(Icons.Default.Add, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Add page")
                }
            }
        }
    }
}

// =============================================================== tags of the open note
private val tagColors = listOf(0xFFEF5350, 0xFFFFA726, 0xFFFFEE58, 0xFF66BB6A, 0xFF26C6DA, 0xFF42A5F5, 0xFF7E57C2, 0xFFEC407A)

@Composable
fun TagsDialog(
    tags: List<TagWithCount>,
    selected: Set<Long>,
    onToggle: (Long, Boolean) -> Unit,
    onCreate: (String, Int) -> Unit,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tags") },
        text = {
            Column {
                LazyColumn(Modifier.heightIn(max = 300.dp)) {
                    if (tags.isEmpty()) item { Text("No tags yet - create the first one below.", style = MaterialTheme.typography.bodySmall) }
                    items(tags, key = { it.tag.id }) { t ->
                        Row(
                            Modifier.fillMaxWidth().clickable { onToggle(t.tag.id, t.tag.id !in selected) },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(t.tag.id in selected, { onToggle(t.tag.id, it) })
                            Box(Modifier.size(12.dp).clip(CircleShape).background(Color(t.tag.colorArgb)))
                            Text("  #" + t.tag.name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("${t.noteCount}", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                Row(Modifier.padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        name, { name = it }, Modifier.weight(1f), singleLine = true,
                        label = { Text("New tag") }
                    )
                    IconButton(
                        onClick = {
                            onCreate(name, tagColors[tags.size % tagColors.size].toInt())
                            name = ""
                        },
                        enabled = name.isNotBlank()
                    ) { Icon(Icons.Default.Add, "Create tag") }
                }
            }
        },
        confirmButton = { TextButton(onDismiss) { Text("Done") } }
    )
}

// =============================================================== voice recording
private fun clock(ms: Long): String = "%d:%02d".format(ms / 60000, (ms / 1000) % 60)

@Composable
fun VoiceDialog(
    controller: VoiceController,
    hasPermission: Boolean,
    onNeedPermission: () -> Unit,
    onDismiss: () -> Unit
) {
    LaunchedEffect(Unit) { while (true) { delay(250); controller.tick() } }
    val ctx = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Voice recording") },
        text = {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    FilledTonalButton(
                        onClick = {
                            if (controller.isRecording) controller.stop()
                            else if (hasPermission) controller.start() else onNeedPermission()
                        },
                        colors = if (controller.isRecording) ButtonDefaults.filledTonalButtonColors(containerColor = Color(0xFFFFCDD2)) else ButtonDefaults.filledTonalButtonColors()
                    ) {
                        Icon(if (controller.isRecording) Icons.Default.Stop else Icons.Default.Mic, null, tint = if (controller.isRecording) Color(0xFFD32F2F) else LocalContentColor.current)
                        Spacer(Modifier.width(8.dp))
                        Text(if (controller.isRecording) "Stop  " + clock(controller.elapsedMs) else "Record")
                    }
                }
                if (controller.failed) Text("Could not start the microphone.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                if (controller.isRecording) Text("Recording keeps running if you close this - writing is tagged to the recording.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp))
                Spacer(Modifier.height(12.dp))
                if (controller.recordings.isEmpty()) {
                    Text("No recordings in this note yet.", style = MaterialTheme.typography.bodySmall)
                } else LazyColumn(Modifier.heightIn(max = 320.dp)) {
                    items(controller.recordings, key = { it.name }) { f ->
                        val isPlaying = controller.playing == f
                        Column(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton({
                                    if (!isPlaying) controller.play(f) else controller.togglePause()
                                }) {
                                    Icon(
                                        if (isPlaying && !controller.isPaused()) Icons.Default.Pause else Icons.Default.PlayArrow, "Play"
                                    )
                                }
                                val ts = f.nameWithoutExtension.toLongOrNull() ?: f.lastModified()
                                Text(
                                    DateUtils.formatDateTime(ctx, ts, DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_SHOW_TIME),
                                    Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium
                                )
                                IconButton({ controller.delete(f) }) { Icon(Icons.Default.Delete, "Delete recording") }
                            }
                            if (isPlaying && controller.playDur > 0) {
                                Slider(
                                    value = controller.playPos.toFloat(),
                                    onValueChange = { controller.seek(it.toInt()) },
                                    valueRange = 0f..controller.playDur.toFloat()
                                )
                                Text(clock(controller.playPos.toLong()) + " / " + clock(controller.playDur.toLong()), style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onDismiss) { Text("Close") } }
    )
}

// =============================================================== easy writing pad
@Composable
fun WritingPadDialog(
    onInsert: (strokes: List<List<Offset>>, padWidth: Float, padHeight: Float) -> Unit,
    onDismiss: () -> Unit
) {
    val strokes = remember { mutableStateListOf<List<Offset>>() }
    var cur by remember { mutableStateOf<List<Offset>>(emptyList()) }
    var size by remember { mutableStateOf(IntSize.Zero) }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        val window = (LocalView.current.parent as? DialogWindowProvider)?.window
        SideEffect { window?.setDimAmount(0f); window?.setGravity(Gravity.BOTTOM) }
        Card(Modifier.fillMaxWidth(0.96f).widthIn(max = 640.dp).padding(bottom = 12.dp), shape = RoundedCornerShape(24.dp), elevation = CardDefaults.cardElevation(8.dp)) {
            Column(Modifier.padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Easy writing pad", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                    IconButton(onDismiss) { Icon(Icons.Default.Close, "Close") }
                }
                Box(
                    Modifier.fillMaxWidth().height(180.dp).clip(RoundedCornerShape(16.dp)).background(Color.White)
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                        .onSizeChanged { size = it }
                        .pointerInput(Unit) {
                            detectDragGestures(
                                onDragStart = { o -> cur = listOf(o) },
                                onDragEnd = { if (cur.size >= 2) strokes.add(cur); cur = emptyList() },
                                onDragCancel = { cur = emptyList() }
                            ) { change, _ -> change.consume(); cur = cur + change.position }
                        }
                ) {
                    Canvas(Modifier.fillMaxSize()) {
                        fun line(pts: List<Offset>) {
                            if (pts.size < 2) return
                            val path = Path()
                            path.moveTo(pts[0].x, pts[0].y)
                            for (i in 1 until pts.size) path.lineTo(pts[i].x, pts[i].y)
                            drawPath(path, Color(0xFF222222), style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
                        }
                        strokes.forEach { line(it) }
                        line(cur)
                    }
                    if (strokes.isEmpty() && cur.isEmpty()) {
                        Text("Write big here, then tap Insert: it lands on the page at normal size.", Modifier.align(Alignment.Center).padding(16.dp), color = Color.Gray)
                    }
                }
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.End) {
                    TextButton({ if (strokes.isNotEmpty()) strokes.removeAt(strokes.lastIndex) }) { Text("Undo") }
                    TextButton({ strokes.clear(); cur = emptyList() }) { Text("Clear") }
                    Spacer(Modifier.width(8.dp))
                    Button(
                        onClick = { onInsert(strokes.toList(), size.width.toFloat(), size.height.toFloat()); strokes.clear() },
                        enabled = strokes.isNotEmpty()
                    ) { Text("Insert") }
                }
            }
        }
    }
}

// =============================================================== change style of the selected handwriting
private val styleColors = listOf(
    0xFF2A2A2A, 0xFFFF4D4D, 0xFFFFC933, 0xFF2EE6D0, 0xFF2E96FF, 0xFF1F3BFF, 0xFF9B30FF, 0xFFFF7BAC
)

@Composable
fun ChangeStyleDialog(
    startPen: PenType,
    startColor: Int,
    onApply: (PenType, Int, Float) -> Unit,
    onDismiss: () -> Unit
) {
    var pen by remember { mutableStateOf(if (startPen == PenType.TAPE) PenType.FOUNTAIN else startPen) }
    var color by remember { mutableStateOf(startColor) }
    var size by remember { mutableStateOf(30f) }
    val types = listOf(
        PenType.FOUNTAIN, PenType.CALLIGRAPHY, PenType.BALLPOINT, PenType.PENCIL,
        PenType.WATERCOLOR, PenType.BRUSH, PenType.HIGHLIGHTER, PenType.HIGHLIGHTER_ROUND
    )
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Change style") },
        text = {
            Column {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    types.forEach { t -> FilterChip(selected = pen == t, onClick = { pen = t }, label = { Text(t.label) }) }
                }
                Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    styleColors.forEach { c ->
                        val argb = c.toInt()
                        Box(
                            Modifier.size(30.dp).clip(CircleShape).background(Color(argb))
                                .border(if (color == argb) 3.dp else 1.dp, MaterialTheme.colorScheme.outline, CircleShape)
                                .clickable { color = argb }
                        )
                    }
                }
                Text("Thickness", Modifier.padding(top = 12.dp), style = MaterialTheme.typography.bodySmall)
                Slider(size, { size = it }, valueRange = 1f..100f)
            }
        },
        confirmButton = { TextButton({ onApply(pen, color, PenSpecs.of(pen).diameter(size)) }) { Text("Apply") } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } }
    )
}

// =============================================================== handwriting help (other readings of the handwriting)
sealed interface HelpState {
    data object Loading : HelpState
    data class Done(val readings: List<String>) : HelpState
    data class Error(val msg: String) : HelpState
}

@Composable
fun HandwritingHelpDialog(state: HelpState, onPick: (String) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Handwriting help") },
        text = {
            when (state) {
                HelpState.Loading -> Column {
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                    Text("Reading your handwriting... the first time this downloads the language model (internet needed).", Modifier.padding(top = 8.dp))
                }
                is HelpState.Error -> Text(state.msg, color = MaterialTheme.colorScheme.error)
                is HelpState.Done -> Column {
                    if (state.readings.isEmpty()) Text("Nothing could be read. Select clearer handwriting.")
                    else {
                        Text("Pick the right reading to add it as typed text:", style = MaterialTheme.typography.bodySmall)
                        LazyColumn(Modifier.heightIn(max = 300.dp)) {
                            items(state.readings) { r ->
                                TextButton({ onPick(r) }, Modifier.fillMaxWidth()) {
                                    Text(r, Modifier.fillMaxWidth(), style = MaterialTheme.typography.titleMedium)
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onDismiss) { Text("Close") } }
    )
}
