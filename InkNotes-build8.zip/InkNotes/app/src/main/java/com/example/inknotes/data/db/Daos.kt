package com.example.inknotes.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface NoteDao {
    @Query(
        """
        SELECT * FROM notes
        WHERE ((:trashed = 1 AND deletedAt IS NOT NULL) OR (:trashed = 0 AND deletedAt IS NULL))
          AND (:lockedOnly = 0 OR isLocked = 1)
          AND (:frequent = 0 OR openCount > 0)
          AND (:folderId IS NULL OR folderId = :folderId)
          AND (:tagId IS NULL OR id IN (SELECT noteId FROM note_tags WHERE tagId = :tagId))
          AND (:q = '' OR title LIKE '%' || :q || '%' OR searchText LIKE '%' || :q || '%')
        ORDER BY isPinned DESC, CASE WHEN :frequent = 1 THEN openCount END DESC, updatedAt DESC
        """
    )
    fun observe(trashed: Boolean, lockedOnly: Boolean, frequent: Boolean, folderId: Long?, tagId: Long?, q: String): Flow<List<NoteEntity>>

    @Insert suspend fun insert(n: NoteEntity): Long
    @Update suspend fun update(n: NoteEntity)

    @Query("SELECT title FROM notes WHERE id = :id") suspend fun title(id: Long): String?
    @Query("UPDATE notes SET title = :t, updatedAt = :ts WHERE id = :id") suspend fun setTitle(id: Long, t: String, ts: Long)
    @Query("UPDATE notes SET searchText = :t, updatedAt = :ts WHERE id = :id") suspend fun setSearchText(id: Long, t: String, ts: Long)
    @Query("SELECT isLocked FROM notes WHERE id = :id") suspend fun isLocked(id: Long): Boolean?
    @Query("UPDATE notes SET isLocked = :l WHERE id = :id") suspend fun setLocked(id: Long, l: Boolean)
    @Query("UPDATE notes SET folderId = :f WHERE id = :id") suspend fun setFolder(id: Long, f: Long?)
    @Query("SELECT paperColor FROM notes WHERE id = :id") suspend fun paperColor(id: Long): Int?
    @Query("UPDATE notes SET paperColor = :c WHERE id = :id") suspend fun setPaperColor(id: Long, c: Int)
    @Query("UPDATE notes SET isPinned = :pinned WHERE id = :id") suspend fun setPinned(id: Long, pinned: Boolean)
    @Query("UPDATE notes SET deletedAt = :ts WHERE id = :id") suspend fun setDeleted(id: Long, ts: Long?)
    @Query("UPDATE notes SET updatedAt = :ts WHERE id = :id") suspend fun touch(id: Long, ts: Long)
    @Query("UPDATE notes SET openCount = openCount + 1 WHERE id = :id") suspend fun markOpened(id: Long)
    @Query("DELETE FROM notes WHERE deletedAt IS NOT NULL AND deletedAt < :cutoff") suspend fun purge(cutoff: Long)
}

@Dao
interface PageDao {
    @Insert suspend fun insert(p: PageEntity): Long
    @Query("SELECT * FROM pages WHERE id = :id") suspend fun get(id: Long): PageEntity?
    @Query("SELECT * FROM pages WHERE noteId = :noteId ORDER BY position LIMIT 1") suspend fun first(noteId: Long): PageEntity?
    @Query("SELECT * FROM pages WHERE noteId = :noteId ORDER BY position, id") suspend fun all(noteId: Long): List<PageEntity>
    @Query("UPDATE pages SET position = :pos WHERE id = :id") suspend fun setPosition(id: Long, pos: Int)
    @Query("DELETE FROM pages WHERE id = :id") suspend fun delete(id: Long)
    @Query("UPDATE pages SET template = :t WHERE id = :id") suspend fun setTemplate(id: Long, t: String)
    @Query("UPDATE pages SET richTextJson = :json WHERE id = :id") suspend fun setRichText(id: Long, json: String)
    @Query(
        "SELECT p.id FROM pages p JOIN notes n ON n.id = p.noteId " +
            "WHERE n.deletedAt IS NOT NULL AND n.deletedAt < :cutoff"
    )
    suspend fun expiredPageIds(cutoff: Long): List<Long>
}

@Dao
interface FolderDao {
    @Insert suspend fun insert(f: FolderEntity): Long

    @Query(
        "SELECT f.*, (SELECT COUNT(*) FROM notes n WHERE n.folderId = f.id AND n.deletedAt IS NULL) AS noteCount " +
            "FROM folders f ORDER BY f.name COLLATE NOCASE"
    )
    fun observeAll(): Flow<List<FolderWithCount>>
}

@Dao
interface TagDao {
    @Query(
        "SELECT t.*, (SELECT COUNT(*) FROM note_tags x JOIN notes n ON n.id = x.noteId " +
            "WHERE x.tagId = t.id AND n.deletedAt IS NULL) AS noteCount FROM tags t ORDER BY t.name COLLATE NOCASE"
    )
    fun observeAll(): Flow<List<TagWithCount>>

    @Query("SELECT tagId FROM note_tags WHERE noteId = :noteId")
    fun observeIdsFor(noteId: Long): Flow<List<Long>>

    @Insert suspend fun insert(t: TagEntity): Long
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun link(x: NoteTagCrossRef)
    @Query("DELETE FROM note_tags WHERE noteId = :noteId AND tagId = :tagId") suspend fun unlink(noteId: Long, tagId: Long)
    @Query("DELETE FROM note_tags WHERE tagId = :tagId") suspend fun unlinkAll(tagId: Long)
    @Query("DELETE FROM tags WHERE id = :id") suspend fun delete(id: Long)
}
