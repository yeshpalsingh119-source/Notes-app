package com.example.inknotes.ink

import android.graphics.Paint
import com.example.inknotes.domain.model.PenType

enum class Kind { RIBBON, PENCIL, WATERCOLOR, HIGHLIGHT, TAPE }

/**
 * One spec per pen. Size slider 1..100 maps to a diameter in px (minDiameter..maxDiameter).
 * radius = diameter/2 * pressureFactor * tilt * speed * nib * taper, per sample.
 */
data class PenSpec(
    val kind: Kind,
    val minDiameter: Float,
    val maxDiameter: Float,
    val defaultSize: Float,
    val defaultColor: Int,
    val pMin: Float = 1f,           // radius factor at pressure 0 ...
    val pMax: Float = 1f,           // ... and at pressure 1
    val gamma: Float = 0.7f,        // <1 = more sensitive to light pressure
    val alpha: Float = 1f,
    val tiltWiden: Float = 0f,      // extra width at full tilt (pen flat on screen)
    val tiltFade: Float = 0f,       // opacity lost at full tilt
    val speedThin: Float = 0f,      // fast strokes get thinner (fountain)
    val nibDeg: Float? = null,      // calligraphy flat nib angle
    val nibMin: Float = 0.2f,
    val taper: Float = 0f,          // fraction of stroke length that tapers at both ends
    val cap: Paint.Cap = Paint.Cap.ROUND
) {
    fun diameter(size: Float): Float =
        minDiameter + (maxDiameter - minDiameter) * (size.coerceIn(1f, 100f) - 1f) / 99f
}

object PenSpecs {
    fun of(t: PenType): PenSpec = when (t) {
        PenType.FOUNTAIN -> PenSpec(Kind.RIBBON, 2f, 18f, 25f, 0xFF7086F7.toInt(),
            pMin = 0.25f, pMax = 1.35f, gamma = 0.65f, tiltWiden = 0.35f, speedThin = 0.4f, taper = 0.06f)
        PenType.CALLIGRAPHY -> PenSpec(Kind.RIBBON, 3f, 26f, 20f, 0xFFD4A90E.toInt(),
            pMin = 0.8f, pMax = 1.2f, nibDeg = 40f, nibMin = 0.12f)
        PenType.BALLPOINT -> PenSpec(Kind.RIBBON, 2f, 22f, 30f, 0xFF7086F7.toInt(),
            pMin = 0.75f, pMax = 1.15f, gamma = 1f)
        PenType.PENCIL -> PenSpec(Kind.PENCIL, 3f, 34f, 30f, 0xFF7086F7.toInt(),
            pMin = 0.5f, pMax = 1.2f, alpha = 0.6f, tiltWiden = 2.2f, tiltFade = 0.45f, taper = 0.04f)
        PenType.WATERCOLOR -> PenSpec(Kind.WATERCOLOR, 6f, 60f, 34f, 0xFF2E93F7.toInt(),
            pMin = 0.35f, pMax = 1.3f, alpha = 0.9f, tiltWiden = 0.8f, taper = 0.18f)
        PenType.BRUSH -> PenSpec(Kind.RIBBON, 8f, 90f, 34f, 0xFFF48F8A.toInt(),
            pMin = 0.3f, pMax = 1.5f, gamma = 0.6f, alpha = 0.85f, tiltWiden = 1.2f, taper = 0.08f)
        PenType.HIGHLIGHTER -> PenSpec(Kind.HIGHLIGHT, 12f, 80f, 35f, 0xFFFDE047.toInt(),
            alpha = 0.45f, cap = Paint.Cap.SQUARE)
        PenType.HIGHLIGHTER_ROUND -> PenSpec(Kind.HIGHLIGHT, 12f, 80f, 35f, 0xFFFDE047.toInt(),
            alpha = 0.45f, cap = Paint.Cap.ROUND)
        PenType.TAPE -> PenSpec(Kind.TAPE, 14f, 90f, 40f, 0xFF2E96FF.toInt(), cap = Paint.Cap.BUTT)
    }
}
