package com.example.inknotes.ink

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ComposeShader
import android.graphics.DashPathEffect
import android.graphics.DiscretePathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Shader
import com.example.inknotes.domain.model.LineStyle
import com.example.inknotes.domain.model.PenType
import com.example.inknotes.domain.model.Stroke
import com.example.inknotes.domain.model.StrokePoint
import java.nio.ByteBuffer
import java.util.Random
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

private val HALF_PI = (PI / 2).toFloat()

/**
 * Turns a stroke into a variable-width outline (ribbon) and paints it per pen kind:
 *  RIBBON      solid fill (fountain / calligraphy / ballpoint / brush)
 *  PENCIL      grain texture, lighter + wider when tilted
 *  WATERCOLOR  rough edges + soft bleed, tapered ends
 *  HIGHLIGHT   constant-width translucent stroke, flat or round tip
 * multiplyHighlighters = true for export (real Multiply). Thread-safe via @Synchronized.
 */
class StrokeRenderer(private val multiplyHighlighters: Boolean) {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeJoin = Paint.Join.ROUND }
    private val multiply = PorterDuffXfermode(PorterDuff.Mode.MULTIPLY)
    private val rough = DiscretePathEffect(3f, 1.4f)
    private val cache = HashMap<String, Path>()
    private val grainBase: Shader by lazy { BitmapShader(makeGrain(), Shader.TileMode.REPEAT, Shader.TileMode.REPEAT) }
    private val grainByColor = HashMap<Int, Shader>()

    /** Committed stroke (geometry cached: strokes are immutable). */
    @Synchronized
    fun draw(c: Canvas, s: Stroke) {
        if (s.points.isEmpty()) return
        val spec = effective(PenSpecs.of(s.pen), s.lineStyle)
        if (cache.size > 1500) cache.clear()
        val path = cache.getOrPut(s.id) { build(s.points, spec, s.width, s.lineStyle) }
        render(c, path, spec, s.pen, s.colorArgb, s.width, avgTilt(s.points), s.lineStyle, false)
    }

    /** Stroke being drawn right now (rebuilt per frame, no cache, cheap preview of grain / rough edges). */
    @Synchronized
    fun drawLive(c: Canvas, pen: PenType, color: Int, width: Float, lineStyle: Int, pts: List<StrokePoint>) {
        if (pts.isEmpty()) return
        val spec = effective(PenSpecs.of(pen), lineStyle)
        render(c, build(pts, spec, width, lineStyle), spec, pen, color, width, avgTilt(pts), lineStyle, true)
    }

    private fun effective(spec: PenSpec, lineStyle: Int): PenSpec =
        if (lineStyle == LineStyle.TAPER && spec.kind != Kind.HIGHLIGHT && spec.kind != Kind.TAPE) spec.copy(taper = max(spec.taper, 0.35f)) else spec

    private fun dashed(spec: PenSpec, lineStyle: Int) =
        spec.kind != Kind.HIGHLIGHT && spec.kind != Kind.TAPE && (lineStyle == LineStyle.DASH || lineStyle == LineStyle.DOT)

    // ------------------------------------------------------------------ painting
    private fun render(
        c: Canvas, path: Path, spec: PenSpec, pen: PenType, color: Int, diameter: Float, tilt: Float,
        lineStyle: Int, preview: Boolean
    ) {
        val a = (Color.alpha(color) * spec.alpha * (1f - spec.tiltFade * tilt)).toInt().coerceIn(8, 255)
        val xfer = if (pen.isHighlighter && multiplyHighlighters) multiply else null
        if (dashed(spec, lineStyle)) {
            val w = max(1f, diameter * 0.75f)
            line.xfermode = null
            line.color = color; line.alpha = a
            line.strokeWidth = w
            if (lineStyle == LineStyle.DASH) {
                line.strokeCap = Paint.Cap.BUTT
                line.pathEffect = DashPathEffect(floatArrayOf(w * 3f, w * 2.2f), 0f)
            } else {
                line.strokeCap = Paint.Cap.ROUND
                line.pathEffect = DashPathEffect(floatArrayOf(0.01f, w * 2f), 0f)
            }
            c.drawPath(path, line)
            line.pathEffect = null
            return
        }
        when (spec.kind) {
            Kind.RIBBON -> {
                fill.shader = null; fill.pathEffect = null; fill.xfermode = null
                fill.color = color; fill.alpha = a
                c.drawPath(path, fill)
            }
            Kind.PENCIL -> {
                fill.pathEffect = null; fill.xfermode = null
                if (preview) { fill.shader = null; fill.color = color } else fill.shader = grainShader(color)
                fill.alpha = a
                c.drawPath(path, fill)
                fill.shader = null
            }
            Kind.WATERCOLOR -> {
                fill.shader = null; fill.xfermode = null
                fill.pathEffect = if (preview) null else rough
                fill.color = color; fill.alpha = (a * 0.8f).toInt()
                c.drawPath(path, fill)
                if (preview) { fill.pathEffect = null; return }
                line.pathEffect = rough; line.xfermode = null
                line.color = color; line.alpha = (a * 0.35f).toInt()
                line.strokeWidth = 2.4f; line.strokeCap = Paint.Cap.ROUND
                c.drawPath(path, line)
                fill.pathEffect = null; line.pathEffect = null
            }
            Kind.TAPE -> {
                line.pathEffect = null; line.xfermode = null
                line.shader = tapeShader(color, lineStyle)
                line.color = Color.WHITE; line.alpha = 255          // the shader supplies the colour
                line.strokeWidth = diameter; line.strokeCap = Paint.Cap.BUTT
                c.drawPath(path, line)
                line.shader = null
            }
            Kind.HIGHLIGHT -> {
                line.pathEffect = null; line.xfermode = xfer
                line.color = color; line.alpha = a
                line.strokeWidth = diameter; line.strokeCap = spec.cap
                c.drawPath(path, line)
                line.xfermode = null
            }
        }
    }

    // ------------------------------------------------------------------ geometry
    private fun build(raw: List<StrokePoint>, spec: PenSpec, diameter: Float, lineStyle: Int): Path {
        val path = Path()
        val pts = decimate(raw, max(0.7f, diameter * 0.06f))

        if (spec.kind == Kind.HIGHLIGHT || spec.kind == Kind.TAPE || dashed(spec, lineStyle)) {
            val p0 = pts[0]
            path.moveTo(p0.x, p0.y)
            if (pts.size == 1) { path.lineTo(p0.x + 0.01f, p0.y); return path }
            for (i in 1 until pts.size) {
                val a = pts[i - 1]; val b = pts[i]
                path.quadTo(a.x, a.y, (a.x + b.x) / 2f, (a.y + b.y) / 2f)
            }
            path.lineTo(pts.last().x, pts.last().y)
            return path
        }

        val n = pts.size
        if (n == 1) {
            path.addCircle(pts[0].x, pts[0].y, max(0.6f, diameter / 2f * pressureFactor(pts[0], spec)), Path.Direction.CW)
            return path
        }

        val cum = FloatArray(n)
        for (i in 1 until n) cum[i] = cum[i - 1] + hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y)
        val total = cum[n - 1]

        val dx = FloatArray(n)
        val dy = FloatArray(n)
        for (i in 0 until n) {
            val a = pts[max(i - 1, 0)]
            val b = pts[min(i + 1, n - 1)]
            val ux = b.x - a.x
            val uy = b.y - a.y
            val l = hypot(ux, uy).let { if (it < 1e-4f) 1f else it }
            dx[i] = ux / l
            dy[i] = uy / l
        }

        val r = FloatArray(n)
        var speed = 0f
        for (i in 0 until n) {
            val p = pts[i]
            var f = pressureFactor(p, spec)
            f *= 1f + spec.tiltWiden * (p.tilt / HALF_PI).coerceIn(0f, 1f)
            if (spec.speedThin > 0f && i > 0) {
                val q = pts[i - 1]
                val v = hypot(p.x - q.x, p.y - q.y) / max(1f, (p.tMs - q.tMs).toFloat())
                speed += 0.25f * ((v / 2.5f).coerceIn(0f, 1f) - speed)
                f *= 1f - spec.speedThin * speed
            }
            spec.nibDeg?.let { nib ->
                val ang = atan2(dy[i], dx[i]).toDouble()
                f *= spec.nibMin + (1f - spec.nibMin) * abs(sin(ang - Math.toRadians(nib.toDouble()))).toFloat()
            }
            if (spec.taper > 0f && total > 1f) {
                val edge = min(cum[i], total - cum[i])
                val k = (edge / max(6f, spec.taper * total)).coerceIn(0f, 1f)
                f *= 0.2f + 0.8f * (k * k * (3f - 2f * k))
            }
            r[i] = max(0.45f, diameter / 2f * f)
        }
        repeat(2) {                                   // smooth radii so width changes flow
            var prev = r[0]
            for (i in 1 until n - 1) { val cur = r[i]; r[i] = (prev + cur + r[i + 1]) / 3f; prev = cur }
        }

        // outline: left side -> end cap -> right side (reversed) -> start cap
        val cap = 8
        val m = 2 * n + 2 * (cap - 1)
        val ox = FloatArray(m)
        val oy = FloatArray(m)
        var k = 0
        for (i in 0 until n) { ox[k] = pts[i].x - dy[i] * r[i]; oy[k] = pts[i].y + dx[i] * r[i]; k++ }
        val e = n - 1
        for (j in 1 until cap) {
            val th = (PI * j / cap).toFloat()
            val c = cos(th); val s = sin(th)
            ox[k] = pts[e].x + r[e] * (-dy[e] * c + dx[e] * s)
            oy[k] = pts[e].y + r[e] * (dx[e] * c + dy[e] * s)
            k++
        }
        for (i in n - 1 downTo 0) { ox[k] = pts[i].x + dy[i] * r[i]; oy[k] = pts[i].y - dx[i] * r[i]; k++ }
        for (j in 1 until cap) {
            val th = (PI * j / cap).toFloat()
            val c = cos(th); val s = sin(th)
            ox[k] = pts[0].x - r[0] * (-dy[0] * c + dx[0] * s)
            oy[k] = pts[0].y - r[0] * (dx[0] * c + dy[0] * s)
            k++
        }

        path.moveTo((ox[0] + ox[1]) / 2f, (oy[0] + oy[1]) / 2f)
        for (i in 1..m) {
            val a = i % m
            val b = (i + 1) % m
            path.quadTo(ox[a], oy[a], (ox[a] + ox[b]) / 2f, (oy[a] + oy[b]) / 2f)
        }
        path.close()
        return path
    }

    private fun pressureFactor(p: StrokePoint, spec: PenSpec): Float {
        val pf = p.pressure.coerceIn(0f, 1f).pow(spec.gamma)
        return spec.pMin + (spec.pMax - spec.pMin) * pf
    }

    private fun avgTilt(p: List<StrokePoint>): Float {
        var s = 0f
        for (q in p) s += q.tilt
        return ((s / p.size) / HALF_PI).coerceIn(0f, 1f)
    }

    private fun decimate(p: List<StrokePoint>, minDist: Float): List<StrokePoint> {
        if (p.size < 3) return p
        val out = ArrayList<StrokePoint>(p.size)
        out.add(p[0])
        for (i in 1 until p.size - 1) {
            val l = out.last()
            if (hypot(p[i].x - l.x, p[i].y - l.y) >= minDist) out.add(p[i])
        }
        out.add(p.last())
        return out
    }

    // ------------------------------------------------------------------ washi tape patterns
    private val tapeShaders = HashMap<Int, Shader>()

    /** pattern: 0 plain, 1 stripes, 2 dots, 3 checks, 4 waves. Tiles are drawn once per colour + pattern. */
    private fun tapeShader(color: Int, pattern: Int): Shader = tapeShaders.getOrPut(color * 31 + pattern) {
        val n = 32
        val bmp = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val base = Color.argb(235, Color.red(color), Color.green(color), Color.blue(color))
        c.drawColor(base)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val light = Color.argb(110, 255, 255, 255)
        when (pattern) {
            1 -> { p.color = light; p.strokeWidth = 5f; for (i in -n..n step 16) c.drawLine(i.toFloat(), n.toFloat(), (i + n).toFloat(), 0f, p) }
            2 -> { p.color = light; for (y in 0 until 2) for (x in 0 until 2) c.drawCircle(8f + x * 16f, 8f + y * 16f, 3.2f, p) }
            3 -> { p.color = light; c.drawRect(0f, 0f, 16f, 16f, p); c.drawRect(16f, 16f, 32f, 32f, p) }
            4 -> {
                p.color = light; p.style = Paint.Style.STROKE; p.strokeWidth = 3f
                val w = Path(); w.moveTo(0f, 16f)
                w.quadTo(8f, 4f, 16f, 16f); w.quadTo(24f, 28f, 32f, 16f)
                c.drawPath(w, p)
            }
        }
        BitmapShader(bmp, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
    }

    // ------------------------------------------------------------------ pencil grain
    private fun grainShader(color: Int): Shader = grainByColor.getOrPut(color) {
        val solid = LinearGradient(0f, 0f, 1f, 0f, color, color, Shader.TileMode.CLAMP)
        ComposeShader(grainBase, solid, PorterDuff.Mode.SRC_IN)      // colour only where the grain has alpha
    }

    private fun makeGrain(): Bitmap {
        val n = 96
        val bytes = ByteArray(n * n)
        val rnd = Random(7)
        for (i in bytes.indices) {
            val r = rnd.nextFloat()
            bytes[i] = (if (r < 0.62f) 255 else (r * 120).toInt()).toByte()
        }
        val bmp = Bitmap.createBitmap(n, n, Bitmap.Config.ALPHA_8)
        bmp.copyPixelsFromBuffer(ByteBuffer.wrap(bytes))
        return bmp
    }
}
