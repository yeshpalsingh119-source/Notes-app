package com.example.inknotes.data.di

import android.content.Context
import androidx.room.Room
import com.example.inknotes.data.db.AppDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DataModule {
    @Provides @Singleton
    fun db(@ApplicationContext c: Context): AppDatabase =
        Room.databaseBuilder(c, AppDatabase::class.java, "notes.db").build()

    @Provides fun noteDao(db: AppDatabase) = db.noteDao()
    @Provides fun pageDao(db: AppDatabase) = db.pageDao()
    @Provides fun folderDao(db: AppDatabase) = db.folderDao()
    @Provides fun tagDao(db: AppDatabase) = db.tagDao()
}
