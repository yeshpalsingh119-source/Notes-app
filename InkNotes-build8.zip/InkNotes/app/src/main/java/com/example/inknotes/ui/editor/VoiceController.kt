package com.example.inknotes.ui.editor

import android.content.Context
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.File

/**
 * Voice recordings of one note: filesDir/audio/<noteId>/<start time ms>.m4a.
 * Recording keeps running when the dialog is closed, so you can write while it records.
 * Strokes written during a recording remember it (Stroke.recordingId / recordingOffsetMs).
 */
class VoiceController(private val ctx: Context, noteId: Long) {
    private val dir = File(ctx.filesDir, "audio/$noteId")

    var recordings by mutableStateOf(load())
        private set
    var isRecording by mutableStateOf(false)
        private set
    var elapsedMs by mutableStateOf(0L)
        private set
    var playing by mutableStateOf<File?>(null)
        private set
    var playPos by mutableStateOf(0)
        private set
    var playDur by mutableStateOf(0)
        private set
    var failed by mutableStateOf(false)
        private set

    /** Name of the running recording (for strokes) and when it started (SystemClock.elapsedRealtime). */
    var currentName: String? = null
        private set
    var startedAt = 0L
        private set

    private var recorder: MediaRecorder? = null
    private var player: MediaPlayer? = null

    private fun load(): List<File> =
        dir.listFiles { f -> f.extension == "m4a" }.orEmpty().sortedByDescending { it.name }

    @Suppress("DEPRECATION")
    fun start(): Boolean {
        stopPlayback()
        if (isRecording) return true
        dir.mkdirs()
        val f = File(dir, "${System.currentTimeMillis()}.m4a")
        return try {
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(96_000)
            r.setAudioSamplingRate(44_100)
            r.setOutputFile(f.absolutePath)
            r.prepare()
            r.start()
            recorder = r
            startedAt = SystemClock.elapsedRealtime()
            currentName = f.name
            elapsedMs = 0L
            isRecording = true
            failed = false
            true
        } catch (e: Exception) {
            runCatching { f.delete() }
            failed = true
            false
        }
    }

    fun stop() {
        val r = recorder ?: return
        recorder = null
        runCatching { r.stop() }
        runCatching { r.release() }
        isRecording = false
        currentName = null
        recordings = load()
    }

    fun play(f: File) {
        stopPlayback()
        runCatching {
            val mp = MediaPlayer()
            mp.setDataSource(f.absolutePath)
            mp.prepare()
            mp.setOnCompletionListener { stopPlayback() }
            mp.start()
            player = mp
            playing = f
            playDur = mp.duration
            playPos = 0
        }
    }

    fun togglePause() {
        val p = player ?: return
        runCatching { if (p.isPlaying) p.pause() else p.start() }
    }

    fun seek(ms: Int) { runCatching { player?.seekTo(ms) }; playPos = ms }

    fun isPaused(): Boolean = player?.let { runCatching { !it.isPlaying }.getOrDefault(true) } ?: true

    fun stopPlayback() {
        runCatching { player?.release() }
        player = null
        playing = null
        playPos = 0
    }

    fun delete(f: File) {
        if (playing == f) stopPlayback()
        runCatching { f.delete() }
        recordings = load()
    }

    /** Called a few times a second while the dialog is open. */
    fun tick() {
        if (isRecording) elapsedMs = SystemClock.elapsedRealtime() - startedAt
        val p = player
        if (p != null) runCatching { playPos = p.currentPosition }
    }

    fun release() {
        stop()
        stopPlayback()
    }
}
