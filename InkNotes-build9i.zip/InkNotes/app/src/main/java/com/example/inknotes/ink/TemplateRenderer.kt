package com.example.inknotes.ink

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import com.example.inknotes.domain.model.PageTemplate
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/** Width of a page in page-space px (the grey desk is shown left/right of it, like Samsung Notes). */
const val PAGE_W = 1584f
/** Samsung Notes "Normal" page: A4-like, 1 : 1.414 of the width (measured from the Samsung Notes page thumbnails). */
const val PAGE_H = 2240f

object TemplateRenderer {
    private val fill = Paint()
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 1f }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 28f }
    private val days = arrayOf("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")

    fun drawDesk(c: Canvas, v: RectF, desk: Int) {
        fill.color = desk
        c.drawRect(v, fill)
    }

    /** Paper + template lines for the visible part of the page ([0, PAGE_W] horizontally, [0, pageH] vertically, or endless when pageH = 0). */
    fun draw(c: Canvas, t: PageTemplate, v: RectF, paper: Int, ink: Int, zoom: Float, desk: Int, pageH: Float = 0f) {
        drawDesk(c, v, desk)
        // pageH > 0: a finite page [0, pageH]; 0: the old endless page
        val page = if (pageH > 0f) RectF(max(v.left, 0f), max(v.top, 0f), min(v.right, PAGE_W), min(v.bottom, pageH))
                   else RectF(max(v.left, 0f), v.top, min(v.right, PAGE_W), v.bottom)
        if (page.width() <= 0f || page.height() <= 0f) return
        fill.color = paper
        c.drawRect(page, fill)
        line.color = ink
        line.alpha = 0x30
        line.strokeWidth = 1f / zoom.coerceAtLeast(0.1f)
        when (t) {
            PageTemplate.BLANK -> Unit
            PageTemplate.RULED_NARROW -> horizontal(c, page, 28f)
            PageTemplate.RULED_MEDIUM -> horizontal(c, page, 36f)
            PageTemplate.RULED_WIDE -> horizontal(c, page, 48f)
            PageTemplate.GRID -> { horizontal(c, page, 36f); vertical(c, page, 36f) }
            PageTemplate.DOTTED -> dots(c, page, 36f * (if (zoom < 0.6f) 3 else if (zoom < 0.9f) 2 else 1), 1.6f / zoom.coerceAtLeast(0.1f))
            PageTemplate.CORNELL -> {
                horizontal(c, page, 36f)
                line.alpha = 0x80
                val w = 2f / zoom.coerceAtLeast(0.1f)
                line.strokeWidth = w
                c.drawLine(PAGE_W * 0.28f, page.top, PAGE_W * 0.28f, page.bottom, line)
                if (page.top <= 120f && page.bottom >= 120f) c.drawLine(page.left, 120f, page.right, 120f, line)
            }
            PageTemplate.MUSIC -> staves(c, page)
            PageTemplate.GRID_NARROW -> { horizontal(c, page, 24f); vertical(c, page, 24f) }
            PageTemplate.WEEKLY -> weekly(c, page)
            PageTemplate.DAILY -> daily(c, page)
            PageTemplate.TODO -> todo(c, page)
            PageTemplate.JOURNAL -> journal(c, page, zoom)
        }
    }

    /** One band per weekday (Monday ... Sunday, then repeating), the name written in the corner of each band. */
    private fun weekly(c: Canvas, v: RectF) {
        val band = 240f
        label.color = line.color
        label.alpha = 0x70
        var i = floor(v.top / band).toInt()
        var y = i * band
        while (y <= v.bottom) {
            c.drawLine(v.left, y, v.right, y, line)
            c.drawText(days[((i % 7) + 7) % 7], max(v.left, 0f) + 24f, y + 40f, label)
            i++
            y += band
        }
    }

    /** Daily planner: a date header, then one line per hour (6:00 ...) with a time column on the left. */
    private fun daily(c: Canvas, v: RectF) {
        val top = 120f
        val step = 56f
        label.color = line.color
        label.alpha = 0x70
        if (v.top <= top && v.bottom >= top) c.drawLine(v.left, top, v.right, top, line)
        var i = max(0, floor((v.top - top) / step).toInt())
        var y = top + i * step
        while (y <= v.bottom) {
            if (y > top) c.drawLine(v.left, y, v.right, y, line)
            if (i < 18) c.drawText("%d:00".format(6 + i), v.left + 20f, y + step - 16f, label)
            i++
            y += step
        }
        c.drawLine(v.left + 130f, max(v.top, top), v.left + 130f, v.bottom, line)
    }

    /** To-do list: ruled lines with a tick box at the start of every line. */
    private fun todo(c: Canvas, v: RectF) {
        val step = 56f
        var y = floor(v.top / step) * step
        while (y <= v.bottom) {
            c.drawLine(v.left, y, v.right, y, line)
            val l = v.left + 40f; val t = y + 14f; val r = l + 28f; val b = t + 28f
            c.drawLine(l, t, r, t, line); c.drawLine(l, b, r, b, line)
            c.drawLine(l, t, l, b, line); c.drawLine(r, t, r, b, line)
            y += step
        }
    }

    /** Journal: lined paper with a margin line and a heading rule near the top. */
    private fun journal(c: Canvas, v: RectF, zoom: Float) {
        horizontal(c, v, 40f)
        line.alpha = 0x70
        line.strokeWidth = 2f / zoom.coerceAtLeast(0.1f)
        c.drawLine(v.left + 96f, v.top, v.left + 96f, v.bottom, line)
        if (v.top <= 110f && v.bottom >= 110f) c.drawLine(v.left, 110f, v.right, 110f, line)
    }

    private fun staves(c: Canvas, v: RectF) {
        val gap = 14f
        val group = 5 * gap + 70f
        var top = floor(v.top / group) * group
        while (top <= v.bottom) {
            for (i in 0 until 5) c.drawLine(v.left, top + i * gap, v.right, top + i * gap, line)
            top += group
        }
    }

    private fun horizontal(c: Canvas, v: RectF, step: Float) {
        var y = floor(v.top / step) * step
        while (y <= v.bottom) { c.drawLine(v.left, y, v.right, y, line); y += step }
    }

    private fun vertical(c: Canvas, v: RectF, step: Float) {
        var x = floor(v.left / step) * step
        while (x <= v.right) { c.drawLine(x, v.top, x, v.bottom, line); x += step }
    }

    private fun dots(c: Canvas, v: RectF, step: Float, r: Float) {
        var y = floor(v.top / step) * step
        while (y <= v.bottom) {
            var x = floor(v.left / step) * step
            while (x <= v.right) { c.drawCircle(x, y, r, line); x += step }
            y += step
        }
    }
}
