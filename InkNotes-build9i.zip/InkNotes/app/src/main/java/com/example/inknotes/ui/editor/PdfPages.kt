package com.example.inknotes.ui.editor

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.util.LruCache
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.ConcurrentLinkedDeque
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.floor
import kotlin.math.roundToInt

/**
 * An imported PDF shown as a vertical stack of pages (page space: width PAGE_W, small gap between pages).
 * Ink is drawn on top by the ink view (same coordinates).
 *
 * Engine ported from the "Galaxy Notes" app (UltraLargePdfEngine), which stays smooth with 1000-page PDFs:
 *  - layout is instant: every page gets the box of page 1 (no openPage() for all 1000 pages); a page with a
 *    different shape is centred inside its box, so nothing is cropped;
 *  - only TWO bitmap widths ever exist (STD_W and HD_W), so zooming never re-renders; the bitmap is just stretched;
 *  - RGB_565 bitmaps (half the memory / GPU upload of ARGB_8888) in a byte-limited LruCache;
 *  - LIFO render queue with a sliding window around the viewport (+-PREFETCH pages): pages the user scrolled past are
 *    dropped from the queue, neighbours are pre-rendered at STD_W, WORKERS pages are rendered in parallel;
 *  - [trim] releases memory when Android asks for it.
 */
class PdfPages(file: File) {
    /** One PdfRenderer (+ its own file handle and lock). PdfRenderer opens one page at a time, so parallel rendering needs several. */
    private class Engine(file: File) {
        val pfd: ParcelFileDescriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
        val renderer = PdfRenderer(pfd)
        val lock = Any()
        fun close() = synchronized(lock) { runCatching { renderer.close() }; runCatching { pfd.close() } }
    }

    private val engines = List(WORKERS) { Engine(file) }
    @Volatile private var closed = false

    val pageCount: Int = engines[0].renderer.pageCount

    var tops: FloatArray = FloatArray(0)
        private set
    var heights: FloatArray = FloatArray(0)
        private set

    /** Page-space height of the whole document; 0 until the layout has been measured. */
    var contentHeight by mutableFloatStateOf(0f)
        private set

    /** Bumped whenever a page bitmap arrives, so the canvas redraws. */
    var version by mutableIntStateOf(0)
        private set

    private var boxH = 0f
    private var step = 1f
    private var boxAspect = 1.414f

    private data class Key(val page: Int, val widthPx: Int)
    private class Task(val page: Int, val widthPx: Int)

    // Never recycled by hand: Compose may still be drawing a bitmap that was just evicted (the GC frees it).
    private val cache = object : LruCache<Key, Bitmap>(MAX_CACHE_BYTES) {
        override fun sizeOf(key: Key, value: Bitmap): Int = value.allocationByteCount
    }
    private val queue = ConcurrentLinkedDeque<Task>()
    private val busy = Array(WORKERS) { AtomicBoolean(false) }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    @Volatile private var winFrom = 0
    @Volatile private var winTo = 0

    init { live.add(this) }

    /** Instant: only page 1 is opened. */
    suspend fun loadLayout(pageW: Float, gap: Float = 24f) {
        val first = withContext(Dispatchers.Default) {
            val e = engines[0]
            synchronized(e.lock) {
                if (closed || pageCount == 0) return@synchronized 1 to 1
                val p = e.renderer.openPage(0)
                try { p.width to p.height } finally { p.close() }
            }
        }
        boxAspect = first.second.toFloat() / first.first.coerceAtLeast(1)
        boxH = pageW * boxAspect
        step = boxH + gap
        val t = FloatArray(pageCount) { it * step }
        val h = FloatArray(pageCount) { boxH }
        tops = t
        heights = h
        contentHeight = if (pageCount > 0) (pageCount - 1) * step + boxH + gap else 0f
    }

    /** Pages intersecting [topY, bottomY] in page space (O(1), no loop over all pages). */
    fun visibleRange(topY: Float, bottomY: Float): IntRange? {
        if (tops.isEmpty() || step <= 0f) return null
        val first = floor(topY / step).toInt().coerceIn(0, pageCount - 1)
        val last = floor(bottomY / step).toInt().coerceIn(0, pageCount - 1)
        if (bottomY < 0f || topY > contentHeight) return null
        return first..maxOf(first, last)
    }

    /** Best bitmap that exists right now for the page (HD if ready, else the standard one, else null). */
    fun bitmap(page: Int): Bitmap? = cache.get(Key(page, HD_W)) ?: cache.get(Key(page, STD_W))

    /**
     * Asks for the pages [first]..[last] (the ones on screen). [hd] = zoomed in enough to need the sharp bitmap.
     * Never blocks; stale requests are dropped, so fast scrolling through 1000 pages does no wasted work.
     */
    fun request(first: Int, last: Int, hd: Boolean) {
        if (closed || pageCount == 0) return
        winFrom = first - PREFETCH
        winTo = last + PREFETCH
        queue.removeIf { it.page < winFrom || it.page > winTo }
        val want = if (hd) HD_W else STD_W
        val order = ArrayList<Task>()
        for (p in first..last) if (cache.get(Key(p, want)) == null) order.add(Task(p, want))
        for (d in 1..PREFETCH) {                            // neighbours: standard size, nearest first
            for (p in intArrayOf(last + d, first - d)) {
                if (p in 0 until pageCount && cache.get(Key(p, STD_W)) == null && cache.get(Key(p, HD_W)) == null) order.add(Task(p, STD_W))
            }
        }
        if (order.isEmpty()) return
        for (t in order.asReversed()) {
            queue.removeIf { it.page == t.page && it.widthPx == t.widthPx }
            queue.addFirst(t)                               // LIFO: the newest request is rendered first
        }
        kick()
    }

    private fun kick() {
        if (closed) return
        for (w in 0 until WORKERS) {
            if (queue.isEmpty()) return
            if (!busy[w].compareAndSet(false, true)) continue
            scope.launch {
                try {
                    while (!closed) {
                        val t = queue.pollFirst() ?: break
                        if (t.page < winFrom || t.page > winTo) continue
                        if (cache.get(Key(t.page, t.widthPx)) != null) continue
                        val bmp = runCatching { render(t.page, t.widthPx, Bitmap.Config.RGB_565, engines[w]) }.getOrNull() ?: continue
                        cache.put(Key(t.page, t.widthPx), bmp)
                        withContext(Dispatchers.Main) { version += 1 }
                    }
                } finally {
                    busy[w].set(false)
                    if (!closed && !queue.isEmpty()) kick()
                }
            }
        }
    }

    /** Renders one page, full quality (used by the exporter). The caller owns (and may recycle) the bitmap. */
    fun renderPage(i: Int, widthPx: Int): Bitmap? = render(i, widthPx, Bitmap.Config.ARGB_8888, engines[0])

    /**
     * The returned bitmap has the shape of the layout box; a page of another shape sits centred on white.
     * PdfRenderer only renders into ARGB_8888, so the page is drawn there first and, for the on-screen cache,
     * converted to RGB_565 (half the memory and GPU upload).
     */
    private fun render(i: Int, widthPx: Int, config: Bitmap.Config, engine: Engine): Bitmap? = synchronized(engine.lock) {
        if (closed || i < 0 || i >= pageCount) return null
        val page = engine.renderer.openPage(i)
        try {
            val boxW = widthPx.coerceAtLeast(1)
            val boxHpx = (boxW * boxAspect).roundToInt().coerceAtLeast(1)
            val pageAspect = page.height.toFloat() / page.width.coerceAtLeast(1)
            val full: Bitmap
            if (kotlin.math.abs(pageAspect / boxAspect - 1f) < 0.01f) {
                full = Bitmap.createBitmap(boxW, boxHpx, Bitmap.Config.ARGB_8888)
                full.eraseColor(Color.WHITE)
                page.render(full, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            } else {
                val fitW: Int
                val fitH: Int
                if (boxW * pageAspect <= boxHpx) {
                    fitW = boxW
                    fitH = (boxW * pageAspect).roundToInt().coerceAtLeast(1)
                } else {
                    fitH = boxHpx
                    fitW = (boxHpx / pageAspect).roundToInt().coerceAtLeast(1)
                }
                val part = Bitmap.createBitmap(fitW, fitH, Bitmap.Config.ARGB_8888)
                part.eraseColor(Color.WHITE)
                page.render(part, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                full = Bitmap.createBitmap(boxW, boxHpx, Bitmap.Config.ARGB_8888)
                full.eraseColor(Color.WHITE)
                Canvas(full).drawBitmap(part, (boxW - fitW) * 0.5f, (boxHpx - fitH) * 0.5f, null)
                part.recycle()                                 // never shown, safe to recycle
            }
            if (config == Bitmap.Config.ARGB_8888) full
            else {
                val small = full.copy(config, false)
                if (small != null) { full.recycle(); small } else full   // never shown yet, safe to recycle
            }
        } finally { page.close() }
    }

    /** Android is short of memory: drop the bitmaps (they are re-rendered on demand). */
    fun trim(aggressive: Boolean) {
        if (aggressive) cache.evictAll() else cache.trimToSize(MAX_CACHE_BYTES / 3)
    }

    fun close() {
        closed = true
        live.remove(this)
        queue.clear()
        scope.cancel()
        for (e in engines) e.close()
        cache.evictAll()
    }

    companion object {
        const val STD_W = 1440
        const val HD_W = 2160
        const val WORKERS = 2                  // pages rendered at the same time
        const val PREFETCH = 4                 // pages kept ready above and below the screen
        const val MAX_CACHE_BYTES = 112 * 1024 * 1024
        private val live = CopyOnWriteArrayList<PdfPages>()

        /** Called from MainActivity.onTrimMemory. */
        fun trimAll(aggressive: Boolean) {
            for (p in live) runCatching { p.trim(aggressive) }
        }
    }
}
