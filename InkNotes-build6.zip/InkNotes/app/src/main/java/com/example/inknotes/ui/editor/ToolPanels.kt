package com.example.inknotes.ui.editor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.FormatAlignCenter
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import com.example.inknotes.domain.model.LineStyle
import com.example.inknotes.domain.model.PenType
import com.example.inknotes.domain.model.ShapeKind
import com.example.inknotes.domain.model.Tool
import kotlin.math.roundToInt

enum class PanelKind { PEN, HIGHLIGHTER, ERASER, SHAPE }

private val palette = listOf(0xFFFF4D4D, 0xFFFFC933, 0xFFFCEB00, 0xFF2EE6D0, 0xFF2E96FF, 0xFF1F3BFF, 0xFF9B30FF, 0xFF2A2A2A)
    .map { it.toInt() }

// =============================================================== bottom toolbar (Samsung Notes style)
@Composable
fun DrawToolbar(
    pen: PenState,
    history: HistoryState,
    onToolTap: (Tool) -> Unit,
    hasSelection: Boolean,
    onConvert: () -> Unit,
    onAlign: () -> Unit,
    onAnchor: (Tool, Float) -> Unit,
    onText: () -> Unit,
    onPhoto: () -> Unit,
    onFavorite: (Favorite) -> Unit,
    onColor: (Int) -> Unit,
    onThickness: () -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit
) {
    val onSurface = MaterialTheme.colorScheme.onSurface
    Surface(color = MaterialTheme.colorScheme.surface, tonalElevation = 0.dp) {
      Column {
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
        Box(Modifier.fillMaxWidth().navigationBarsPadding(), contentAlignment = Alignment.Center) {
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            ToolButton(false, onText) { Icon(Icons.Default.Keyboard, "Text") }
            ToolButton(pen.tool == Tool.PEN, { onToolTap(Tool.PEN) }, modifier = Modifier.onGloballyPositioned { c -> onAnchor(Tool.PEN, c.positionInWindow().x + c.size.width / 2f) }) {
                ToolGlyph(Glyph.PEN, onSurface, Color(pen.settings[pen.pen]?.color ?: 0xFF7086F7.toInt()))
            }
            ToolButton(pen.tool == Tool.HIGHLIGHTER, { onToolTap(Tool.HIGHLIGHTER) }, modifier = Modifier.onGloballyPositioned { c -> onAnchor(Tool.HIGHLIGHTER, c.positionInWindow().x + c.size.width / 2f) }) {
                ToolGlyph(Glyph.HIGHLIGHTER, onSurface, Color(pen.settings[pen.highlighter]?.color ?: 0xFFFDE047.toInt()))
            }
            ToolButton(pen.tool == Tool.ERASER, { onToolTap(Tool.ERASER) }, modifier = Modifier.onGloballyPositioned { c -> onAnchor(Tool.ERASER, c.positionInWindow().x + c.size.width / 2f) }) { ToolGlyph(Glyph.ERASER, onSurface, Color(0xFFF48F8A)) }
            ToolButton(pen.tool == Tool.SELECT, { onToolTap(Tool.SELECT) }) { ToolGlyph(Glyph.LASSO, onSurface, onSurface) }
            ToolButton(false, onConvert, enabled = hasSelection) { Icon(Icons.Default.TextFields, "Convert handwriting to text") }
            ToolButton(false, onAlign, enabled = hasSelection) { Icon(Icons.Default.FormatAlignCenter, "Align handwriting") }
            ToolButton(pen.tool == Tool.SHAPE, { onToolTap(Tool.SHAPE) }, modifier = Modifier.onGloballyPositioned { c -> onAnchor(Tool.SHAPE, c.positionInWindow().x + c.size.width / 2f) }) { ToolGlyph(Glyph.SHAPES, onSurface, onSurface) }
            ToolButton(false, onPhoto) { Icon(Icons.Default.Image, "Photo") }
            BarDivider()
            pen.recentColors.forEach { c -> ColorDot(c, c == pen.active.color) { onColor(c) } }
            ToolButton(false, onThickness) {
                Box(
                    Modifier.width(26.dp).height((2f + pen.active.size / 14f).dp)
                        .clip(CircleShape).background(onSurface)
                )
            }
            BarDivider()
            ToolButton(false, onUndo, enabled = history.canUndo) { Icon(Icons.AutoMirrored.Filled.Undo, "Undo") }
            ToolButton(false, onRedo, enabled = history.canRedo) { Icon(Icons.AutoMirrored.Filled.Redo, "Redo") }
            if (pen.favorites.isNotEmpty()) {
                BarDivider()
                pen.favorites.forEach { f ->
                    ToolButton(false, { onFavorite(f) }) {
                        ToolGlyph(if (f.pen.isHighlighter) Glyph.HIGHLIGHTER else Glyph.PEN, onSurface, Color(f.color))
                    }
                }
            }
        }
        }
      }
    }
}

@Composable
private fun BarDivider() {
    Box(Modifier.padding(horizontal = 6.dp).width(1.dp).height(24.dp).background(MaterialTheme.colorScheme.outlineVariant))
}

@Composable
fun ToolButton(
    selected: Boolean, onClick: () -> Unit, enabled: Boolean = true,
    modifier: Modifier = Modifier, content: @Composable () -> Unit
) {
    Box(
        modifier.size(44.dp).clip(CircleShape)
            .background(if (selected) MaterialTheme.colorScheme.surfaceVariant else Color.Transparent)
            .alpha(if (enabled) 1f else 0.35f)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) { content() }
}

@Composable
private fun ColorDot(color: Int, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.padding(horizontal = 4.dp).size(28.dp).clip(CircleShape).background(Color(color))
            .border(if (selected) 3.dp else 1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant, CircleShape)
            .clickable(onClick = onClick)
    )
}

// =============================================================== tool glyphs
enum class Glyph { PEN, HIGHLIGHTER, ERASER, LASSO, SHAPES }

@Composable
fun ToolGlyph(g: Glyph, tint: Color, accent: Color, modifier: Modifier = Modifier.size(28.dp)) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val sw = 2.2f.dp.toPx()
        when (g) {
            Glyph.PEN, Glyph.HIGHLIGHTER -> rotate(40f, center) {
                val bw = w * 0.30f
                val l = center.x - bw / 2f
                drawRoundRect(tint, Offset(l, h * 0.05f), Size(bw, h * 0.62f), CornerRadius(3f.dp.toPx()), style = Stroke(sw))
                val tip = Path().apply {
                    moveTo(l, h * 0.70f); lineTo(l + bw, h * 0.70f)
                    lineTo(if (g == Glyph.PEN) center.x else l + bw * 0.8f, h * 0.96f)
                    lineTo(if (g == Glyph.PEN) center.x else l + bw * 0.2f, h * 0.96f)
                    close()
                }
                if (g == Glyph.HIGHLIGHTER) drawPath(tip, accent) else drawPath(tip, tint, style = Stroke(sw, join = StrokeJoin.Round))
                drawRect(accent, Offset(l, h * 0.40f), Size(bw, h * 0.12f))
            }
            Glyph.ERASER -> rotate(-40f, center) {
                val bw = w * 0.42f
                val l = center.x - bw / 2f
                drawRoundRect(tint, Offset(l, h * 0.12f), Size(bw, h * 0.76f), CornerRadius(4f.dp.toPx()), style = Stroke(sw))
                drawRoundRect(accent, Offset(l, h * 0.50f), Size(bw, h * 0.38f), CornerRadius(4f.dp.toPx()))
            }
            Glyph.SHAPES -> {
                drawCircle(tint, w * 0.24f, Offset(w * 0.37f, h * 0.40f), style = Stroke(sw))
                drawRect(tint, Offset(w * 0.45f, h * 0.45f), Size(w * 0.40f, h * 0.40f), style = Stroke(sw))
            }
            Glyph.LASSO -> drawOval(
                tint, Offset(w * 0.12f, h * 0.2f), Size(w * 0.76f, h * 0.6f),
                style = Stroke(sw, pathEffect = PathEffect.dashPathEffect(floatArrayOf(7.dp.toPx(), 5.dp.toPx())))
            )
        }
    }
}

// =============================================================== compact floating panel (Dialog = always above the ink surface)
// Opens just above the toolbar, centred over the tool that was tapped (like Samsung Notes).
@Composable
fun ToolPanelDialog(
    kind: PanelKind,
    pen: PenState,
    anchorX: Float,
    update: ((PenState) -> PenState) -> Unit,
    onClearAll: () -> Unit,
    onPickColor: () -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        val window = (LocalView.current.parent as? DialogWindowProvider)?.window
        SideEffect { window?.setDimAmount(0f) }
        val none = remember { MutableInteractionSource() }
        val density = LocalDensity.current
        val screenWdp = LocalConfiguration.current.screenWidthDp
        val cardWdp = minOf(320, screenWdp - 16)
        val cardPx = with(density) { cardWdp.dp.toPx() }
        val edgePx = with(density) { 8.dp.toPx() }
        val screenPx = with(density) { screenWdp.dp.toPx() }
        val maxLeft = (screenPx - cardPx - edgePx).coerceAtLeast(edgePx)
        val left = if (anchorX > 0f) (anchorX - cardPx / 2f).coerceIn(edgePx, maxLeft) else (screenPx - cardPx) / 2f
        Box(
            Modifier.fillMaxSize().clickable(interactionSource = none, indication = null, onClick = onDismiss),
            contentAlignment = Alignment.BottomStart
        ) {
            Card(
                Modifier.padding(bottom = 96.dp)
                    .offset { IntOffset(left.roundToInt(), 0) }
                    .width(cardWdp.dp)
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { },
                shape = RoundedCornerShape(24.dp),
                elevation = CardDefaults.cardElevation(8.dp)
            ) {
                Column(Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        if (kind == PanelKind.PEN || kind == PanelKind.HIGHLIGHTER) {
                            val fav = pen.isFavorite()
                            IconButton(onClick = { update { it.toggleFavorite() } }, modifier = Modifier.size(36.dp)) {
                                Icon(
                                    if (fav) Icons.Default.Star else Icons.Default.StarBorder, "Favourite pen",
                                    tint = if (fav) Color(0xFFFFB300) else MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        } else Spacer(Modifier.size(36.dp))
                        Text(
                            when (kind) {
                                PanelKind.ERASER -> "Eraser"
                                PanelKind.SHAPE -> "Shapes"
                                else -> pen.activeType.label
                            },
                            Modifier.weight(1f), textAlign = TextAlign.Center,
                            style = MaterialTheme.typography.titleSmall
                        )
                        IconButton(onClick = onDismiss, modifier = Modifier.size(36.dp)) {
                            Icon(Icons.Default.Close, "Close", modifier = Modifier.size(22.dp))
                        }
                    }
                    when (kind) {
                        PanelKind.ERASER -> EraserContent(pen, update, onClearAll)
                        PanelKind.SHAPE -> ShapeContent(pen, update)
                        else -> PenContent(kind, pen, update, onPickColor)
                    }
                }
            }
        }
    }
}

@Composable
private fun PenContent(kind: PanelKind, pen: PenState, update: ((PenState) -> PenState) -> Unit, onPickColor: () -> Unit) {
    val types = if (kind == PanelKind.PEN) {
        listOf(PenType.FOUNTAIN, PenType.CALLIGRAPHY, PenType.BALLPOINT, PenType.PENCIL, PenType.WATERCOLOR, PenType.BRUSH)
    } else listOf(PenType.HIGHLIGHTER, PenType.HIGHLIGHTER_ROUND)
    val current = pen.activeType

    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        types.forEach { t ->
            val col = Color(pen.settings[t]?.color ?: 0xFF7086F7.toInt())
            Box(Modifier.clip(RoundedCornerShape(12.dp)).clickable { update { it.withPen(t) } }) {
                PenIllustration(t, col, t == current, Modifier.width(44.dp).height(104.dp))
            }
        }
    }

    SizeRow(pen.active.size) { v -> update { it.withSize(v) } }

    if (kind == PanelKind.PEN) {
        Row(Modifier.fillMaxWidth().padding(bottom = 2.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for (ls in listOf(LineStyle.SOLID, LineStyle.TAPER, LineStyle.DASH, LineStyle.DOT)) {
                LineStyleChip(ls, pen.lineStyle == ls, Modifier.weight(1f)) { update { it.copy(lineStyle = ls) } }
            }
        }
        // Hold-to-shape is always on (it also straightens lines), so neither toggle is shown any more.
    }

    Row(Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        palette.forEach { c ->
            Box(
                Modifier.size(26.dp).clip(CircleShape).background(Color(c)).clickable { update { it.withColor(c) } },
                contentAlignment = Alignment.Center
            ) {
                if (pen.active.color == c) Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(16.dp))
            }
        }
        Box(
            Modifier.size(26.dp).clip(CircleShape)
                .background(Brush.sweepGradient(listOf(Color.Red, Color.Yellow, Color.Green, Color.Cyan, Color.Blue, Color.Magenta, Color.Red)))
                .clickable(onClick = onPickColor),
            contentAlignment = Alignment.Center
        ) { Box(Modifier.size(15.dp).clip(CircleShape).background(Color(pen.active.color))) }
    }
}

@Composable
private fun LineStyleChip(style: Int, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val ink = MaterialTheme.colorScheme.onSurface
    Box(
        modifier.height(32.dp).clip(RoundedCornerShape(16.dp))
            .background(if (selected) MaterialTheme.colorScheme.outlineVariant else MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxWidth(0.62f).height(14.dp)) {
            val y = size.height / 2f
            val w = size.width
            when (style) {
                LineStyle.SOLID -> drawLine(ink, Offset(0f, y), Offset(w, y), strokeWidth = 3.dp.toPx(), cap = StrokeCap.Round)
                LineStyle.TAPER -> {
                    val p = Path().apply {
                        moveTo(0f, y - 2.5f.dp.toPx()); lineTo(w, y - 0.6f.dp.toPx())
                        lineTo(w, y + 0.6f.dp.toPx()); lineTo(0f, y + 2.5f.dp.toPx()); close()
                    }
                    drawPath(p, ink)
                }
                LineStyle.DASH -> drawLine(
                    ink, Offset(0f, y), Offset(w, y), strokeWidth = 3.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(9.dp.toPx(), 6.dp.toPx()))
                )
                else -> drawLine(
                    ink, Offset(0f, y), Offset(w, y), strokeWidth = 3.dp.toPx(), cap = StrokeCap.Round,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(0.1f, 8.dp.toPx()))
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SizeRow(size: Float, onChange: (Float) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = { onChange((size - 1f).coerceAtLeast(1f)) }, modifier = Modifier.size(32.dp)) {
            Icon(Icons.Default.Remove, "Smaller", modifier = Modifier.size(20.dp))
        }
        Slider(
            value = size, onValueChange = onChange,
            valueRange = 1f..100f, modifier = Modifier.weight(1f),
            thumb = {
                Surface(shape = CircleShape, shadowElevation = 3.dp, modifier = Modifier.size(30.dp)) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("${size.roundToInt()}", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        )
        IconButton(onClick = { onChange((size + 1f).coerceAtMost(100f)) }, modifier = Modifier.size(32.dp)) {
            Icon(Icons.Default.Add, "Bigger", modifier = Modifier.size(20.dp))
        }
    }
}

@Composable
private fun EraserContent(pen: PenState, update: ((PenState) -> PenState) -> Unit, onClearAll: () -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FilterChip(!pen.areaEraser, { update { it.copy(areaEraser = false) } }, { Text("Erase by stroke") })
        FilterChip(pen.areaEraser, { update { it.copy(areaEraser = true) } }, { Text("Erase by area") })
    }
    SizeRow(pen.eraserSize) { v -> update { it.copy(eraserSize = v) } }
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("Erase highlighter only", Modifier.weight(1f))
        Switch(pen.eraseHighlighterOnly, { v -> update { it.copy(eraseHighlighterOnly = v) } })
    }
    TextButton(onClearAll) { Text("Clear all handwriting") }
}

@Composable
private fun ShapeContent(pen: PenState, update: ((PenState) -> PenState) -> Unit) {
    Text("Shape", style = MaterialTheme.typography.titleMedium)
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        ShapeKind.entries.forEach { k ->
            FilterChip(pen.shape == k, { update { it.copy(shape = k) } }, { Text(k.label) })
        }
    }
    SizeRow(pen.active.size) { v -> update { it.withSize(v) } }
    Text("Drag on the page to draw the shape with the current pen", style = MaterialTheme.typography.labelSmall, modifier = Modifier.alpha(0.6f))
}

// =============================================================== colour picker (HSV)
@Composable
fun ColorPickerDialog(initial: Int, onDismiss: () -> Unit, onPick: (Int) -> Unit) {
    val hsv = remember { FloatArray(3).also { android.graphics.Color.colorToHSV(initial, it) } }
    var h by remember { mutableFloatStateOf(hsv[0]) }
    var s by remember { mutableFloatStateOf(hsv[1]) }
    var v by remember { mutableFloatStateOf(hsv[2]) }
    val argb = android.graphics.Color.HSVToColor(floatArrayOf(h, s, v))
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Custom colour") },
        text = {
            Column {
                Box(Modifier.fillMaxWidth().height(48.dp).clip(RoundedCornerShape(12.dp)).background(Color(argb)))
                Text("Hue"); Slider(h, { h = it }, valueRange = 0f..360f)
                Text("Saturation"); Slider(s, { s = it })
                Text("Brightness"); Slider(v, { v = it })
            }
        },
        confirmButton = { TextButton({ onPick(argb) }) { Text("Select") } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } }
    )
}

// =============================================================== pen illustrations (like the Samsung panel)
private fun shade(c: Color, f: Float) =
    Color((c.red * f).coerceIn(0f, 1f), (c.green * f).coerceIn(0f, 1f), (c.blue * f).coerceIn(0f, 1f), c.alpha)

@Composable
private fun PenIllustration(type: PenType, color: Color, selected: Boolean, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val top = size.height * 0.24f
        val ph = size.height - top
        fun y(f: Float) = top + ph * f
        val cx = w / 2f
        val bw = w * 0.5f
        val bl = cx - bw / 2f
        val hair = 1.2f.dp.toPx()
        val dark = Color(0xFF3A3A40)
        val metal = Brush.horizontalGradient(listOf(Color(0xFFB4B7C2), Color(0xFFF8F9FC), Color(0xFFC2C5CF)), startX = bl, endX = bl + bw)
        val bodyBrush = Brush.horizontalGradient(listOf(shade(color, 0.78f), shade(color, 1.1f), shade(color, 0.84f)), startX = bl, endX = bl + bw)
        val bandBrush = Brush.horizontalGradient(listOf(Color(0xFFE4E5EB), Color.White, Color(0xFFD6D8E0)), startX = bl, endX = bl + bw)

        if (selected) {
            val wave = Path().apply {
                moveTo(w * 0.12f, top * 0.75f)
                cubicTo(w * 0.30f, top * 0.05f, w * 0.45f, top * 0.95f, w * 0.65f, top * 0.40f)
                cubicTo(w * 0.75f, top * 0.15f, w * 0.88f, top * 0.45f, w * 0.92f, top * 0.30f)
            }
            drawPath(wave, color, style = Stroke(width = 5.dp.toPx(), cap = StrokeCap.Round))
        }
        // soft contact shadow
        drawOval(Color.Black.copy(alpha = 0.07f), Offset(bl - 4f, size.height - 8.dp.toPx()), Size(bw + 8f, 8.dp.toPx()))

        // grip, ferrule band, glossy streak
        drawRoundRect(bodyBrush, Offset(bl, y(0.46f)), Size(bw, ph * 0.60f), CornerRadius(bw * 0.3f))
        drawRect(bandBrush, Offset(bl, y(0.70f)), Size(bw, ph * 0.075f))
        drawRoundRect(Color.White.copy(alpha = 0.28f), Offset(bl + bw * 0.16f, y(0.50f)), Size(bw * 0.13f, ph * 0.17f), CornerRadius(bw * 0.06f))

        when (type) {
            PenType.FOUNTAIN, PenType.CALLIGRAPHY -> {
                val peak = if (type == PenType.CALLIGRAPHY) cx + bw * 0.22f else cx
                val nib = Path().apply {
                    moveTo(bl + bw * 0.08f, y(0.44f)); lineTo(peak, y(0.04f)); lineTo(bl + bw * 0.92f, y(0.44f)); close()
                }
                drawPath(nib, metal)
                drawPath(nib, dark.copy(alpha = 0.45f), style = Stroke(hair))
                drawLine(dark, Offset(peak, y(0.22f)), Offset(cx, y(0.44f)), strokeWidth = hair)
                drawCircle(dark, bw * 0.045f, Offset(peak, y(0.22f)))
                drawRect(Color(0xFF2C2C31), Offset(bl, y(0.435f)), Size(bw, ph * 0.04f))
            }
            PenType.BALLPOINT -> {
                val cone = Path().apply {
                    moveTo(bl + bw * 0.1f, y(0.46f)); lineTo(cx - bw * 0.1f, y(0.10f))
                    lineTo(cx + bw * 0.1f, y(0.10f)); lineTo(bl + bw * 0.9f, y(0.46f)); close()
                }
                drawPath(cone, metal)
                drawPath(cone, dark.copy(alpha = 0.35f), style = Stroke(hair))
                drawCircle(shade(color, 0.7f), bw * 0.08f, Offset(cx, y(0.085f)))
            }
            PenType.PENCIL -> {
                val wood = Path().apply {
                    moveTo(bl + bw * 0.04f, y(0.46f)); lineTo(cx, y(0.12f)); lineTo(bl + bw * 0.96f, y(0.46f)); close()
                }
                drawPath(wood, Brush.horizontalGradient(listOf(Color(0xFFE2BC8A), Color(0xFFF5DDB8), Color(0xFFE6C493)), startX = bl, endX = bl + bw))
                val lead = Path().apply {
                    moveTo(cx - bw * 0.14f, y(0.26f)); lineTo(cx, y(0.10f)); lineTo(cx + bw * 0.14f, y(0.26f)); close()
                }
                drawPath(lead, shade(color, 0.85f))
            }
            PenType.WATERCOLOR, PenType.BRUSH -> {
                drawRect(metal, Offset(bl, y(0.36f)), Size(bw, y(0.46f) - y(0.36f)))
                val bristle = Path().apply {
                    moveTo(bl + bw * 0.06f, y(0.36f))
                    if (type == PenType.WATERCOLOR) quadraticBezierTo(cx, y(-0.02f), bl + bw * 0.94f, y(0.36f))
                    else cubicTo(bl, y(0.08f), bl + bw, y(0.08f), bl + bw * 0.94f, y(0.36f))
                    close()
                }
                val tipBrush = if (type == PenType.WATERCOLOR)
                    Brush.verticalGradient(listOf(Color.White, color), startY = y(0.04f), endY = y(0.36f))
                else Brush.verticalGradient(listOf(shade(color, 1.1f), shade(color, 0.85f)), startY = y(0.08f), endY = y(0.36f))
                drawPath(bristle, tipBrush)
            }
            PenType.HIGHLIGHTER, PenType.HIGHLIGHTER_ROUND -> {
                val tip = Path().apply {
                    moveTo(bl + bw * 0.04f, y(0.46f)); lineTo(bl + bw * 0.22f, y(0.12f))
                    lineTo(bl + bw * 0.78f, y(0.12f)); lineTo(bl + bw * 0.96f, y(0.46f)); close()
                }
                drawPath(tip, Brush.horizontalGradient(listOf(shade(color, 0.9f), shade(color, 1.1f), shade(color, 0.9f)), startX = bl, endX = bl + bw))
                if (type == PenType.HIGHLIGHTER_ROUND) drawCircle(color, bw * 0.28f, Offset(cx, y(0.12f)))
            }
        }
    }
}
