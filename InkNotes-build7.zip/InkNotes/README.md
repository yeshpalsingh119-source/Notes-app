# InkNotes - Samsung Notes-inspired app (build 7)

Kotlin + Jetpack Compose (Material 3, One UI feel), Clean Architecture/MVVM, Hilt, Room, Flow.
Target device: Samsung Galaxy Tab S10 Lite (S Pen). Android Studio: open the folder, sync, run on tablet/emulator.

**Status: NOT compiled yet** (no Android SDK / network where this was generated). Dependency versions are
placeholders - bump AGP/Kotlin/KSP/Hilt together in Android Studio. `androidx.graphics` low-latency API
(`CanvasFrontBufferedRenderer`) may need small signature tweaks for your exact version.

## Layout
```
domain/      models (Stroke, PenType...), UndoRedoStack (200 steps)
data/        Room (notes, folders, pages, tags), StrokeFileStore (chunked JSON), NotesRepository, Hilt module
ink/         InkSurfaceView (low-latency S Pen), StrokeRenderer, PenSpecs, TemplateRenderer
ui/home      collapsing One UI header, drawer, nested folders, grid/list modes, search
ui/editor    3 layers: Compose paper/template -> (rich text, Phase 2) -> ink SurfaceView; pen toolbar
```

## Phase 1 (in this zip)
- Home: collapsing large app bar, drawer (permanent on tablet), nested folders with colour + total count,
  Grid S/M/L + List + Simple list, pinned first, trash (30-day purge), title/text search, long-press pin/trash
- Editor: low-latency stylus ink, pressure + tilt, 5 pens + 2 highlighters (+ straight snap), stroke eraser
  (+ "erase highlighter only"), S Pen button / eraser tip = eraser, finger-draw toggle, palm rejection,
  pinch-zoom + pan, templates (blank, 3 rulings, grid, dotted), dark paper, undo/redo, auto-save after every stroke

## Build 5 (this zip)
- App icon (adaptive), One UI colour theme (no wallpaper-tinted colours), richer pen illustrations.
- Area eraser (cuts strokes, undoable) + stroke eraser, eraser size slider, eraser circle.
- Scroll lag: ink cache now covers the view + a margin, so normal scrolling never rebuilds; viewport rebuilds never starve.
  Debug HUD (menu > Pen debug info) also shows strokes / rebuild time / dropped frames.
- Shapes tool (drag: line, rectangle, circle, triangle, arrow), favourite pens (star in the pen panel), pen settings remembered.
- Align handwriting (select > ruler icon), Cornell + music-staff templates.
- Export to PNG / vector PDF (menu > Export), Add note to folder, Lock note (fingerprint / face / screen lock to open).

## Build 4
- Lag fixes: front-buffer frames are coalesced (one in flight at a time), palm/touch-area rejection while the pen is near,
  zoom/pan rebuild only draws visible strokes and aborts when superseded, finished strokes stay visible via a pending list.
- Page like Samsung Notes: grey desk + centred white page, clamped scrolling, fling scroll.
- Reading mode: pen AND finger scroll (menu book icon, top bar).
- Hold to shape (pen panel): hold 0.5 s -> line / triangle / rectangle / circle / ellipse preview + haptic tick. "Straighten lines" = lines only.
- Pen panel: line styles (solid / tapered / dashed / dotted), reference colours. Flat centred toolbar.
- PDF import (PDF icon on home): pages stacked under the ink, rendered lazily by zoom level, annotate with pen/highlighter.
- Home like the reference: left rail, page thumbnails, book covers, round pencil FAB. Editor menu: Note style, Background colour, finger drawing.

## Build 3
- Latency: unbuffered touch dispatch, front-buffer live stroke + 14 ms pen-tip prediction, max refresh rate request.
  (1 ms is physically impossible - the panel refreshes every ~11 ms at 90 Hz; goal = as close to Samsung Notes as possible.)
- Lag/crash fixes: committed strokes live in a bitmap cache updated on a background thread (no full redraw per stroke),
  compact point storage + 20-stroke chunks (was MB-sized JSON rewrites per stroke), crash report saved + shown on next launch.
- Pens: fountain, calligraphy, ballpoint, pencil, watercolor, brush + 2 highlighters, each with its own look, colour and size (1-100);
  pressure (gamma curve + smoothing) and tilt (pencil/brush/watercolor widen + fade). Overflow menu > "Pen debug info" shows live
  pressure / tilt / orientation so you can check what the S Pen really reports.
- Samsung-style UI: bottom toolbar + floating pen panel (pen illustrations, size slider, straighten lines, colours, custom colour).
- Select tool (lasso): move, resize (corner handles), duplicate, recolour, delete, convert handwriting to text (ML Kit, English + Hindi).
- Photos (gallery): move, pinch resize/rotate, layer order, delete. Reading mode. Share as text. Clear all (undoable).

## Phase 2a (earlier)
- Rich-text layer (Text mode): block based - bold / italic / underline / strike, size, colour, highlight,
  alignment, bullets, indent, interactive checklists (tick = strikethrough). Formatting is per line/block,
  not per character (per-character spans = later). Typed text feeds the home-screen search index.
- Draw/Text toggle in the top bar. In Text mode finger pan/zoom is off (switch back to Draw to pan).

## Get an APK without Android Studio
Push this folder to a GitHub repo (branch `main`): Actions -> "Build debug APK" -> download artifact
`InkNotes-debug-apk` -> install `app-debug.apk` on the tablet (allow unknown sources). Or in Android Studio:
Build > Build APK(s). Expect a few compile errors on the very first build (never compiled yet) - fix/ask.

## Next phases
- Phase 2b: floating text boxes, area eraser, lasso, shape snap/straighten,
  ML Kit handwriting-to-text + OCR index, favourites dock, colour picker/eyedropper, multi-page + page sorter,
  Cornell/planner/music templates, page thumbnails, PDF import/markup (PdfRenderer), image editing
- Phase 3: audio-synced strokes, biometric AES-256 note lock, exports (PDF/DOCX/PPTX/PNG/TXT),
  Easy Writing Pad, reading mode, shared notebooks (needs a backend)

## Tab S10 Lite notes
- Mid-range chip: next perf step is caching committed strokes in a bitmap/tile cache (currently the multi
  buffer redraws every stroke on commit/pan/zoom - fine for hundreds, not thousands). Add a Baseline Profile.
- Manifest already: resizeable (split-screen/DeX), configChanges so rotation doesn't recreate the ink surface.
- Highlighter Multiply only applies on export/flatten; live overlay approximates with alpha.
- Don't ship Samsung branding/assets - behaviour is inspired, visuals are your own.
