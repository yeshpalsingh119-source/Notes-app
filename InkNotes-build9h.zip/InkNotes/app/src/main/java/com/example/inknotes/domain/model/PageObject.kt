package com.example.inknotes.domain.model

import kotlinx.serialization.Serializable

/**
 * Sticky note or table placed on a page. x/y/w/h in page px (top-left + size).
 * STICKY uses [text]; TABLE uses [rows] x [cols] and [cells] (row-major).
 */
@Serializable
data class PageObject(
    val id: String,
    val kind: String,                 // "STICKY", "TABLE" or "TEXT"
    val x: Float,
    val y: Float,
    val w: Float,
    val h: Float,
    val color: Int = 0xFFFFF59D.toInt(),
    val text: String = "",
    val rows: Int = 0,
    val cols: Int = 0,
    val cells: List<String> = emptyList()
) {
    val isSticky: Boolean get() = kind == KIND_STICKY
    val isTable: Boolean get() = kind == KIND_TABLE
    val isText: Boolean get() = kind == KIND_TEXT

    companion object {
        const val KIND_STICKY = "STICKY"
        const val KIND_TABLE = "TABLE"
        const val KIND_TEXT = "TEXT"        // Maths solver result (blue text next to the equation)
    }
}
