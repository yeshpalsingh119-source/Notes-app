package com.example.inknotes.ui.editor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.inknotes.domain.model.PageTemplate

/** Cover colours. Note.coverIndex: 0 = no cover, 1..8 = "Pattern" cover (full colour + spine), 9..16 = "Text" cover (colour band). */
val coverColors: List<Int> = listOf(
    0xFF3F4A9E, 0xFF2E7D6B, 0xFFB5527A, 0xFFC27A2C, 0xFF5B6F7E, 0xFF8E5BA6, 0xFFB23A3A, 0xFF2B2B2B
).map { it.toInt() }

private class TemplateGroup(val name: String, val items: List<Pair<PageTemplate, String>>)

private val templateGroups = listOf(
    TemplateGroup(
        "Basic",
        listOf(
            PageTemplate.BLANK to "Blank page", PageTemplate.RULED_MEDIUM to "Lined", PageTemplate.RULED_NARROW to "Lined (narrow)",
            PageTemplate.RULED_WIDE to "Lined (wide)", PageTemplate.GRID to "Grid", PageTemplate.GRID_NARROW to "Grid (narrow)"
        )
    ),
    TemplateGroup("Academic", listOf(PageTemplate.CORNELL to "Cornell", PageTemplate.MUSIC to "Music", PageTemplate.DOTTED to "Dotted")),
    TemplateGroup("Planners", listOf(PageTemplate.WEEKLY to "Weekly", PageTemplate.DAILY to "Daily", PageTemplate.TODO to "To-do")),
    TemplateGroup("Journals", listOf(PageTemplate.JOURNAL to "Journal")),
    TemplateGroup("Creative", emptyList()),
    TemplateGroup("Custom", emptyList())
)

/** Tiny drawing of a page template (tiles of the Note style panel). */
@Composable
fun TemplateMini(t: PageTemplate, modifier: Modifier = Modifier) {
    Canvas(modifier.background(Color.White)) {
        val w = size.width
        val h = size.height
        val ink = Color(0xFFB8BEC8)
        fun lines(step: Float) {
            var y = step
            while (y < h) { drawLine(ink, Offset(0f, y), Offset(w, y), 1f); y += step }
        }
        fun grid(step: Float) {
            lines(step)
            var x = step
            while (x < w) { drawLine(ink, Offset(x, 0f), Offset(x, h), 1f); x += step }
        }
        when (t) {
            PageTemplate.BLANK -> Unit
            PageTemplate.RULED_NARROW -> lines(h / 16f)
            PageTemplate.RULED_MEDIUM -> lines(h / 11f)
            PageTemplate.RULED_WIDE -> lines(h / 8f)
            PageTemplate.GRID -> grid(h / 10f)
            PageTemplate.GRID_NARROW -> grid(h / 18f)
            PageTemplate.DOTTED -> {
                val st = h / 10f
                var y = st
                while (y < h) {
                    var x = st
                    while (x < w) { drawCircle(ink, 1.6f, Offset(x, y)); x += st }
                    y += st
                }
            }
            PageTemplate.CORNELL -> {
                lines(h / 12f)
                drawLine(Color(0xFFE57373), Offset(w * 0.3f, 0f), Offset(w * 0.3f, h * 0.8f), 1.5f)
                drawLine(Color(0xFFE57373), Offset(0f, h * 0.8f), Offset(w, h * 0.8f), 1.5f)
            }
            PageTemplate.MUSIC -> {
                var y = h * 0.1f
                repeat(5) {
                    for (k in 0 until 5) drawLine(ink, Offset(6f, y + k * h * 0.02f), Offset(w - 6f, y + k * h * 0.02f), 1f)
                    y += h * 0.18f
                }
            }
            else -> lines(h / 9f)
        }
    }
}

@Composable
private fun CoverMini(index: Int, modifier: Modifier = Modifier) {
    val c = Color(coverColors[(index - 1).coerceAtLeast(0) % coverColors.size])
    if (index <= 8) {
        Box(modifier.background(c)) { Box(Modifier.width(6.dp).fillMaxHeight().background(Color(0x33000000))) }
    } else {
        Box(modifier.background(Color(0xFFF7EEEA))) { Box(Modifier.fillMaxWidth().fillMaxHeight(0.3f).background(c.copy(alpha = 0.85f))) }
    }
}

/**
 * Samsung "Note style": two tiles (Cover / Page), page templates in tabs (Basic, Academic, Planners, Journals,
 * Creative, Custom), cover choices (Pattern / Illustration / Text) and an Apply button.
 */
@Composable
fun NoteStylePanel(
    template: PageTemplate,
    cover: Int,
    onApply: (PageTemplate, Int) -> Unit,
    onPdf: () -> Unit,
    onNotBuilt: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var tab by remember { mutableIntStateOf(1) }                 // 0 = Cover tile selected, 1 = Page tile selected
    var group by remember { mutableIntStateOf(0) }
    var kind by remember { mutableIntStateOf(0) }                // cover: 0 Pattern, 1 Illustration, 2 Text
    var selT by remember { mutableStateOf(template) }
    var selC by remember { mutableIntStateOf(cover) }
    var customMenu by remember { mutableStateOf(false) }
    val accent = MaterialTheme.colorScheme.primary
    val changed = selT != template || selC != cover

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Card(Modifier.width(420.dp).heightIn(max = 600.dp), shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Note style", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    IconButton(onDismiss) { Icon(Icons.Default.Close, "Close") }
                }
                Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFFEDEDF0))
                                .border(if (tab == 0) 2.dp else 0.dp, if (tab == 0) accent else Color.Transparent, RoundedCornerShape(10.dp))
                                .clickable { tab = 0 },
                            contentAlignment = Alignment.Center
                        ) {
                            if (selC == 0) Icon(Icons.Default.Add, "Add cover")
                            else {
                                CoverMini(selC, Modifier.fillMaxHeight(0.85f).width(90.dp).clip(RoundedCornerShape(6.dp)))
                                IconButton({ selC = 0 }, Modifier.align(Alignment.TopEnd).size(28.dp)) { Icon(Icons.Default.Close, "Remove cover", Modifier.size(16.dp)) }
                            }
                        }
                        Text(if (selC == 0) "Add cover" else "Cover", Modifier.padding(top = 4.dp), fontSize = 12.sp)
                    }
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFFEDEDF0))
                                .border(if (tab == 1) 2.dp else 0.dp, if (tab == 1) accent else Color.Transparent, RoundedCornerShape(10.dp))
                                .clickable { tab = 1 },
                            contentAlignment = Alignment.Center
                        ) {
                            TemplateMini(selT, Modifier.fillMaxHeight(0.85f).width(90.dp).clip(RoundedCornerShape(4.dp)))
                        }
                        Text("Page", Modifier.padding(top = 4.dp), fontSize = 12.sp)
                    }
                }
                Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState())) {
                    if (tab == 1) {
                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            templateGroups.forEachIndexed { i, g ->
                                val on = i == group
                                TextButton(
                                    onClick = { group = i },
                                    colors = ButtonDefaults.textButtonColors(contentColor = if (on) accent else MaterialTheme.colorScheme.onSurface),
                                    contentPadding = PaddingValues(horizontal = 10.dp)
                                ) { Text(g.name, fontWeight = if (on) FontWeight.Bold else FontWeight.Normal, fontSize = 13.sp) }
                            }
                        }
                        val g = templateGroups[group]
                        if (g.name == "Custom") {
                            Box(Modifier.padding(top = 8.dp)) {
                                Box(
                                    Modifier.width(92.dp).height(126.dp).clip(RoundedCornerShape(6.dp)).background(Color(0xFFEDEDF0)).clickable { customMenu = true },
                                    contentAlignment = Alignment.Center
                                ) { Icon(Icons.Default.Add, "Add") }
                                DropdownMenu(customMenu, { customMenu = false }) {
                                    DropdownMenuItem(text = { Text("Image") }, onClick = { customMenu = false; onNotBuilt("Image page templates are not built yet") })
                                    DropdownMenuItem(text = { Text("PDF") }, onClick = { customMenu = false; onPdf() })
                                }
                            }
                        } else if (g.items.isEmpty()) {
                            Text("No templates in this tab yet.", Modifier.padding(vertical = 16.dp), color = MaterialTheme.colorScheme.outline)
                        } else {
                            g.items.chunked(3).forEach { row ->
                                Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    row.forEach { (t, label) ->
                                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                            TemplateMini(
                                                t,
                                                Modifier.fillMaxWidth().aspectRatio(0.72f).clip(RoundedCornerShape(4.dp))
                                                    .border(if (selT == t) 2.dp else 1.dp, if (selT == t) accent else Color(0xFFD0D0D6), RoundedCornerShape(4.dp))
                                                    .clickable { selT = t }
                                            )
                                            Text(label, Modifier.padding(top = 4.dp), fontSize = 11.sp, textAlign = TextAlign.Center, maxLines = 1)
                                        }
                                    }
                                    repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                                }
                            }
                        }
                    } else {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf("Pattern", "Illustration", "Text").forEachIndexed { i, label ->
                                val on = i == kind
                                TextButton(
                                    onClick = { kind = i },
                                    colors = ButtonDefaults.textButtonColors(contentColor = if (on) accent else MaterialTheme.colorScheme.onSurface),
                                    contentPadding = PaddingValues(horizontal = 12.dp)
                                ) { Text(label, fontWeight = if (on) FontWeight.Bold else FontWeight.Normal, fontSize = 13.sp) }
                            }
                        }
                        if (kind == 1) {
                            Text("Illustration covers are not built yet.", Modifier.padding(vertical = 16.dp), color = MaterialTheme.colorScheme.outline)
                        } else {
                            Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                coverColors.forEachIndexed { i, c ->
                                    val idx = if (kind == 0) i + 1 else i + 9
                                    Box(
                                        Modifier.size(34.dp).clip(CircleShape).background(Color(c))
                                            .border(if (selC == idx) 3.dp else 0.dp, if (selC == idx) accent else Color.Transparent, CircleShape)
                                            .clickable { selC = idx },
                                        contentAlignment = Alignment.Center
                                    ) { if (selC == idx) Icon(Icons.Default.Check, null, Modifier.size(16.dp), tint = Color.White) }
                                }
                            }
                        }
                    }
                }
                Button(
                    onClick = { onApply(selT, selC) }, enabled = changed,
                    modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
                ) { Text("Apply") }
            }
        }
    }
}

