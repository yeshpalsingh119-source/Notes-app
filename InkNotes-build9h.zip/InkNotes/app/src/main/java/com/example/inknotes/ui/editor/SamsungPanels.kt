package com.example.inknotes.ui.editor

import android.graphics.RectF
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.layout
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

/** Colour sets of the Samsung colour pages (swipe sideways). Page 0 is "recently used". */
val colorPalettes: List<List<Int>> = listOf(
    listOf(0xFFF03A47, 0xFFFFB92E, 0xFFFFE600, 0xFF2EE6C8, 0xFF2E96FF, 0xFF1F4FFF, 0xFF9B30FF, 0xFF222222),
    listOf(0xFFFFE04D, 0xFFF0506E, 0xFF6FDB8F, 0xFF7A8CFA, 0xFFDADADA, 0xFF666666, 0xFFFFB800, 0xFF2DCC5A),
    listOf(0xFFE57368, 0xFFFFB300, 0xFF1B3A4B, 0xFF3A7D7B, 0xFF5B7DB1, 0xFF4A3F8E, 0xFF9B5B3B, 0xFFD2B48C),
    listOf(0xFFFF8A80, 0xFFFFD180, 0xFFFFFF8D, 0xFFA7FFEB, 0xFF80D8FF, 0xFF8C9EFF, 0xFFEA80FC, 0xFFBDBDBD)
).map { set -> set.map { it.toInt() } }

/**
 * Colour row with sideways pages + dots (first dot = recent colours), and the rainbow button for a custom colour.
 * [selected] gets the tick.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ColorPages(selected: Int?, recent: List<Int>, onPick: (Int) -> Unit, onCustom: () -> Unit) {
    val pages = 1 + colorPalettes.size
    val pager = rememberPagerState(initialPage = 1) { pages }
    Column(Modifier.fillMaxWidth()) {
        HorizontalPager(pager, Modifier.fillMaxWidth().height(34.dp)) { page ->
            val colors = if (page == 0) recent.distinct().take(8) else colorPalettes[page - 1]
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                colors.forEach { c ->
                    Box(
                        Modifier.size(26.dp).clip(CircleShape).background(Color(c))
                            .border(1.dp, Color(0x33000000), CircleShape)
                            .clickable { onPick(c) },
                        contentAlignment = Alignment.Center
                    ) {
                        if (selected == c) Icon(Icons.Default.Check, null, Modifier.size(16.dp), tint = if (isLight(c)) Color(0xFF222222) else Color.White)
                    }
                }
                repeat(8 - colors.size) { Spacer(Modifier.size(26.dp)) }
                Box(
                    Modifier.size(26.dp).clip(CircleShape).clickable(onClick = onCustom).background(
                        Brush.sweepGradient(listOf(Color.Red, Color.Yellow, Color.Green, Color.Cyan, Color.Blue, Color.Magenta, Color.Red))
                    )
                )
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 6.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            repeat(pages) { i ->
                val on = pager.currentPage == i
                Box(
                    Modifier.padding(horizontal = 4.dp).size(if (i == 0) 8.dp else 6.dp).clip(CircleShape)
                        .background(if (on) Color(0xFF555555) else Color(0xFFCFCFD4))
                )
            }
        }
    }
}

private fun isLight(argb: Int): Boolean {
    val r = (argb shr 16) and 0xFF; val g = (argb shr 8) and 0xFF; val b = argb and 0xFF
    return (0.299f * r + 0.587f * g + 0.114f * b) > 170f
}

/** Samsung slider row: minus, slider whose thumb shows the number, plus. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SizeSliderRow(value: Float, onChange: (Float) -> Unit, onFinished: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(32.dp).clickable { onChange((value - 1f).coerceIn(1f, 100f)); onFinished() }, contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Remove, "Thinner", Modifier.size(20.dp))
        }
        Slider(
            value = value, onValueChange = onChange, onValueChangeFinished = onFinished,
            valueRange = 1f..100f, modifier = Modifier.weight(1f),
            thumb = {
                Box(
                    Modifier.size(32.dp).shadow(2.dp, CircleShape).background(Color.White, CircleShape),
                    contentAlignment = Alignment.Center
                ) { Text("${value.roundToInt()}", fontSize = 11.sp, fontWeight = FontWeight.Medium, color = Color(0xFF222222)) }
            }
        )
        Box(Modifier.size(32.dp).clickable { onChange((value + 1f).coerceIn(1f, 100f)); onFinished() }, contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Add, "Thicker", Modifier.size(20.dp))
        }
    }
}

/** Content of the Change style panel: thickness slider + colour pages. Applies live (one undo step). */
@Composable
fun StyleContent(
    startColor: Int,
    recent: List<Int>,
    onApply: (color: Int?, size: Float?) -> Unit,
    onCustomColor: () -> Unit
) {
    var size by remember { mutableFloatStateOf(30f) }
    var color by remember { mutableStateOf<Int?>(null) }
    Spacer(Modifier.height(6.dp))
    SizeSliderRow(size, { size = it }, { onApply(null, size) })
    ColorPages(color ?: startColor, recent, onPick = { color = it; onApply(it, null) }, onCustom = onCustomColor)
}

/** Selection mode panel: lasso or rectangle. */
@Composable
fun SelectModeContent(rect: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        for (r in listOf(false, true)) {
            val sel = rect == r
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(16.dp))
                    .background(if (sel) Color(0xFFD9E3FF) else Color(0xFFEFEFF2))
                    .clickable { onChange(r) }.padding(vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Canvas(Modifier.size(width = 44.dp, height = 28.dp)) {
                    val dash = PathEffect.dashPathEffect(floatArrayOf(6.dp.toPx(), 4.dp.toPx()))
                    val st = Stroke(width = 1.8f.dp.toPx(), cap = StrokeCap.Round, pathEffect = dash)
                    if (r) drawRect(Color(0xFF333333), Offset(2.dp.toPx(), 2.dp.toPx()), Size(size.width - 4.dp.toPx(), size.height - 4.dp.toPx()), style = st)
                    else drawOval(Color(0xFF333333), Offset(2.dp.toPx(), 2.dp.toPx()), Size(size.width - 4.dp.toPx(), size.height - 4.dp.toPx()), style = st)
                }
                Text(if (r) "Rectangle" else "Lasso", Modifier.padding(top = 6.dp), style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}

/**
 * Floating toolbar above the selection: Cut, Copy, Paste, Delete, Change style, Convert to text, more.
 * [bounds] = selection box in the px of the box this is placed in.
 */
@Composable
fun SelectionToolbar(
    bounds: RectF,
    onCut: () -> Unit, onCopy: () -> Unit, onPaste: () -> Unit, onDelete: () -> Unit,
    onStyle: () -> Unit, onConvert: () -> Unit, onSelectAll: () -> Unit, onDuplicate: () -> Unit
) {
    var more by remember { mutableStateOf(false) }
    Box(
        Modifier.fillMaxSize().layout { measurable, constraints ->
            val p = measurable.measure(constraints.copy(minWidth = 0, minHeight = 0))
            layout(constraints.maxWidth, constraints.maxHeight) {
                val edge = 8.dp.roundToPx()
                val above = 64.dp.roundToPx()                       // room for the rotate handle
                var y = (bounds.top - above - p.height).roundToInt()
                if (y < edge) y = (bounds.bottom + 16.dp.roundToPx()).roundToInt()
                val x = ((bounds.left + bounds.right) / 2f - p.width / 2f).roundToInt()
                    .coerceIn(edge, (constraints.maxWidth - p.width - edge).coerceAtLeast(edge))
                p.place(x, y.coerceIn(edge, (constraints.maxHeight - p.height - edge).coerceAtLeast(edge)))
            }
        }
    ) {
        Surface(shape = RoundedCornerShape(22.dp), shadowElevation = 6.dp, color = MaterialTheme.colorScheme.surface) {
            Row(Modifier.padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                for ((label, action) in listOf(
                    "Cut" to onCut, "Copy" to onCopy, "Paste" to onPaste, "Delete" to onDelete,
                    "Change style" to onStyle, "Convert to text" to onConvert
                )) {
                    Text(
                        label, fontSize = 12.sp, maxLines = 1,
                        modifier = Modifier.clip(RoundedCornerShape(14.dp)).clickable(onClick = action).padding(horizontal = 9.dp, vertical = 11.dp)
                    )
                }
                Box {
                    Box(Modifier.size(36.dp).clickable { more = true }, contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.MoreVert, "More", Modifier.size(18.dp))
                    }
                    DropdownMenu(more, { more = false }) {
                        DropdownMenuItem(text = { Text("Select all") }, onClick = { more = false; onSelectAll() })
                        DropdownMenuItem(text = { Text("Duplicate") }, onClick = { more = false; onDuplicate() })
                    }
                }
            }
        }
    }
}
