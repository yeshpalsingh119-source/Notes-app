package com.example.inknotes.ui.editor

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.inknotes.data.db.PageEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

@Composable
private fun PanelThumb(file: File, version: Int, modifier: Modifier) {
    val bmp by produceState<ImageBitmap?>(null, file, version) {
        value = withContext(Dispatchers.IO) {
            runCatching { BitmapFactory.decodeFile(file.absolutePath)?.asImageBitmap() }.getOrNull()
        }
    }
    Box(modifier.background(Color.White)) {
        bmp?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit) }
    }
}

/**
 * Samsung left page panel: header "1/N" + Select + bookmark + search, page thumbnails with their number,
 * a + tile at the end, and a long-press menu (Add page, Copy, Cut, Delete, Erase page, Share, Save as file).
 */
@Composable
fun PagePanel(
    pages: List<PageEntity>,
    currentId: Long,
    version: Int,
    thumbOf: (Long) -> File,
    onOpen: (Long) -> Unit,
    onAdd: () -> Unit,
    onDelete: (List<Long>) -> Unit,
    onErase: (Long) -> Unit,
    onBookmark: (Long) -> Unit,
    onSaveAs: (Long) -> Unit,
    hasClip: Boolean,
    onCopy: (Long, Boolean) -> Unit,          // (page, cut)
    onPaste: () -> Unit,
    onNotBuilt: (String) -> Unit
) {
    var selectMode by remember { mutableStateOf(false) }
    var chosen by remember { mutableStateOf(setOf<Long>()) }
    var menuFor by remember { mutableStateOf<Long?>(null) }
    val idx = (pages.indexOfFirst { it.id == currentId } + 1).coerceAtLeast(1)
    val currentMarked = pages.firstOrNull { it.id == currentId }?.bookmarked == true
    val red = Color(0xFFE5484D)

    Column(Modifier.width(144.dp).fillMaxHeight().background(Color(0xFFF4F4F6))) {
        Row(Modifier.fillMaxWidth().padding(start = 10.dp, end = 4.dp, top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(if (selectMode) "${chosen.size}" else "$idx/${pages.size}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(Modifier.weight(1f))
            TextButton(
                onClick = { selectMode = !selectMode; chosen = emptySet() },
                contentPadding = PaddingValues(horizontal = 6.dp), modifier = Modifier.height(32.dp)
            ) { Text(if (selectMode) "Done" else "Select", fontSize = 12.sp) }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), horizontalArrangement = Arrangement.End) {
            IconButton({ onBookmark(currentId) }, Modifier.size(34.dp)) {
                Icon(if (currentMarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder, "Bookmark page", Modifier.size(20.dp), tint = if (currentMarked) red else Color(0xFF444444))
            }
            IconButton({ onNotBuilt("Search in pages is not built yet") }, Modifier.size(34.dp)) {
                Icon(Icons.Default.Search, "Search", Modifier.size(20.dp), tint = Color(0xFF444444))
            }
        }
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            items(pages, key = { it.id }) { p ->
                val n = pages.indexOfFirst { it.id == p.id } + 1
                val current = p.id == currentId
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        Modifier.width(104.dp).height(144.dp)
                            .border(if (current) 2.dp else 1.dp, if (current) red else Color(0xFFD0D0D6), RoundedCornerShape(4.dp))
                            .pointerInput(p.id, selectMode) {
                                detectTapGestures(
                                    onTap = {
                                        if (selectMode) chosen = if (p.id in chosen) chosen - p.id else chosen + p.id
                                        else onOpen(p.id)
                                    },
                                    onLongPress = { if (!selectMode) menuFor = p.id }
                                )
                            }
                    ) {
                        PanelThumb(thumbOf(p.id), version, Modifier.fillMaxSize())
                        if (p.bookmarked) Box(Modifier.align(Alignment.TopEnd).padding(end = 6.dp).width(10.dp).height(18.dp).background(red))
                        if (selectMode) {
                            val on = p.id in chosen
                            Icon(
                                if (on) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked, null,
                                Modifier.align(Alignment.TopStart).padding(4.dp).size(20.dp),
                                tint = if (on) Color(0xFF3E7BFA) else Color(0xFF888888)
                            )
                        }
                        DropdownMenu(menuFor == p.id, { menuFor = null }) {
                            DropdownMenuItem(text = { Text("Add page") }, onClick = { menuFor = null; onAdd() })
                            DropdownMenuItem(text = { Text("Copy") }, onClick = { menuFor = null; onCopy(p.id, false) })
                            DropdownMenuItem(text = { Text("Cut") }, onClick = { menuFor = null; onCopy(p.id, true) })
                            if (hasClip) DropdownMenuItem(text = { Text("Paste") }, onClick = { menuFor = null; onPaste() })
                            DropdownMenuItem(text = { Text("Delete") }, enabled = pages.size > 1, onClick = { menuFor = null; onDelete(listOf(p.id)) })
                            DropdownMenuItem(text = { Text("Erase page") }, onClick = { menuFor = null; onErase(p.id) })
                            DropdownMenuItem(text = { Text("Share") }, onClick = { menuFor = null; onSaveAs(p.id) })
                            DropdownMenuItem(text = { Text("Save as file") }, onClick = { menuFor = null; onSaveAs(p.id) })
                        }
                    }
                    Text("$n", Modifier.padding(top = 4.dp), fontSize = 11.sp, color = if (current) red else Color(0xFF555555))
                }
            }
            item {
                Box(
                    Modifier.width(104.dp).height(144.dp).clip(RoundedCornerShape(4.dp)).background(Color(0xFFE9E9EE)).clickable { onAdd() },
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Default.Add, "Add page", tint = Color(0xFF666666)) }
            }
        }
        if (selectMode) {
            Button(
                onClick = { onDelete(chosen.toList()); chosen = emptySet(); selectMode = false },
                enabled = chosen.isNotEmpty() && chosen.size < pages.size,
                modifier = Modifier.fillMaxWidth().padding(8.dp)
            ) { Text("Delete") }
        }
    }
}
