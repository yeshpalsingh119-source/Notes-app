package com.example.inknotes.ui.editor

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.util.LruCache
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.ConcurrentLinkedDeque
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * High-performance PDF engine optimized for ultra-smooth scrolling and zooming on 1000+ page PDFs.
 *
 * Key Optimizations:
 * 1. Zero-Allocation Rendering: Reuses a scratch ARGB_8888 bitmap and pools evicted RGB_565 bitmaps,
 *    eliminating GC pauses during high-speed scrolling and flings.
 * 2. Directional & Priority Prefetch: Lookahead prefetching biased in the scroll direction (+8 ahead,
 *    +2 behind), rendering visible pages immediately with LIFO priority.
 * 3. Dynamic Memory Budget: Cache scaled up to 256 MB (or 1/3 max heap) for instant page access.
 * 4. Batched UI Notifications: Throttles Compose canvas invalidations to ~60 FPS, eliminating main-thread
 *    context-switch stalls during rapid page decoding.
 * 5. Instant O(1) Layout: Only opens page 1 once; computes layout bounds mathematically.
 */
class PdfPages(file: File) {
    private val pfd: ParcelFileDescriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    private val renderer = PdfRenderer(pfd)
    private val lock = Any()
    @Volatile private var closed = false

    val pageCount: Int = renderer.pageCount

    var tops: FloatArray = FloatArray(0)
        private set
    var heights: FloatArray = FloatArray(0)
        private set

    /** Page-space height of the whole document; 0 until the layout has been measured. */
    var contentHeight by mutableFloatStateOf(0f)
        private set

    /** Bumped when page bitmaps arrive, triggering Compose canvas redraw. */
    var version by mutableIntStateOf(0)
        private set

    private var boxH = 0f
    private var step = 1f
    private var boxAspect = 1.414f

    private data class Key(val page: Int, val widthPx: Int)
    private class Task(val page: Int, val widthPx: Int, val priority: Int)

    // Pool of reusable RGB_565 bitmaps from evicted entries to avoid memory churn and GC pauses
    private val bitmapPool = ConcurrentLinkedQueue<Bitmap>()
    private val maxPoolSize = 16

    // Byte-limited LRU Cache scaled to device RAM
    private val cache = object : LruCache<Key, Bitmap>(CALCULATED_MAX_CACHE_BYTES) {
        override fun sizeOf(key: Key, value: Bitmap): Int = value.allocationByteCount

        override fun entryRemoved(evicted: Boolean, key: Key, oldValue: Bitmap, newValue: Bitmap?) {
            if (evicted && !oldValue.isRecycled) {
                if (bitmapPool.size < maxPoolSize) {
                    bitmapPool.offer(oldValue)
                }
            }
        }
    }

    private val queue = ConcurrentLinkedDeque<Task>()
    private val running = AtomicBoolean(false)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    @Volatile private var winFrom = 0
    @Volatile private var winTo = 0
    @Volatile private var lastFirstPage = 0
    @Volatile private var updateScheduled = false

    // Single reusable scratch ARGB_8888 bitmap for PdfRenderer
    private var scratchArgb: Bitmap? = null

    init { live.add(this) }

    /** Instant layout: only page 1 is opened to measure aspect ratio. */
    suspend fun loadLayout(pageW: Float, gap: Float = 24f) {
        val first = withContext(Dispatchers.Default) {
            synchronized(lock) {
                if (closed || pageCount == 0) return@synchronized 1 to 1
                val p = renderer.openPage(0)
                try { p.width to p.height } finally { p.close() }
            }
        }
        boxAspect = first.second.toFloat() / first.first.coerceAtLeast(1)
        boxH = pageW * boxAspect
        step = boxH + gap
        val t = FloatArray(pageCount) { it * step }
        val h = FloatArray(pageCount) { boxH }
        tops = t
        heights = h
        contentHeight = if (pageCount > 0) (pageCount - 1) * step + boxH + gap else 0f
    }

    /** Pages intersecting [topY, bottomY] in page space (O(1) calculation, instant on 1000 pages). */
    fun visibleRange(topY: Float, bottomY: Float): IntRange? {
        if (tops.isEmpty() || step <= 0f) return null
        val first = floor(topY / step).toInt().coerceIn(0, pageCount - 1)
        val last = floor(bottomY / step).toInt().coerceIn(0, pageCount - 1)
        if (bottomY < 0f || topY > contentHeight) return null
        return first..maxOf(first, last)
    }

    /** Best bitmap that exists right now for the page (HD if ready, else standard, else null). */
    fun bitmap(page: Int): Bitmap? = cache.get(Key(page, HD_W)) ?: cache.get(Key(page, STD_W))

    /**
     * Priority request for on-screen pages and directional lookahead.
     * Stale requests outside the active sliding window are dropped immediately.
     */
    fun request(first: Int, last: Int, hd: Boolean) {
        if (closed || pageCount == 0) return

        val scrollingDown = first >= lastFirstPage
        lastFirstPage = first

        // Directional sliding window: bias prefetch in the direction of travel
        winFrom = if (scrollingDown) max(0, first - 3) else max(0, first - 8)
        winTo = if (scrollingDown) min(pageCount - 1, last + 8) else min(pageCount - 1, last + 3)

        // Drop obsolete tasks outside active window
        queue.removeIf { it.page < winFrom || it.page > winTo }

        val want = if (hd) HD_W else STD_W
        val tasks = ArrayList<Task>()

        // 1. Visible pages (Highest priority: 0)
        for (p in first..last) {
            if (cache.get(Key(p, want)) == null) {
                tasks.add(Task(p, want, 0))
            }
        }

        // 2. Immediate lookahead in scroll direction (Priority: 1)
        if (scrollingDown) {
            for (p in (last + 1)..min(pageCount - 1, last + 6)) {
                if (cache.get(Key(p, STD_W)) == null && cache.get(Key(p, HD_W)) == null) {
                    tasks.add(Task(p, STD_W, 1))
                }
            }
            for (p in max(0, first - 2) until first) {
                if (cache.get(Key(p, STD_W)) == null && cache.get(Key(p, HD_W)) == null) {
                    tasks.add(Task(p, STD_W, 2))
                }
            }
        } else {
            for (p in (first - 1) downTo max(0, first - 6)) {
                if (cache.get(Key(p, STD_W)) == null && cache.get(Key(p, HD_W)) == null) {
                    tasks.add(Task(p, STD_W, 1))
                }
            }
            for (p in (last + 1)..min(pageCount - 1, last + 2)) {
                if (cache.get(Key(p, STD_W)) == null && cache.get(Key(p, HD_W)) == null) {
                    tasks.add(Task(p, STD_W, 2))
                }
            }
        }

        if (tasks.isEmpty()) return

        // Push tasks to LIFO queue: priority 0 tasks at the very front
        for (t in tasks.asReversed()) {
            queue.removeIf { it.page == t.page && it.widthPx == t.widthPx }
            if (t.priority == 0) {
                queue.addFirst(t)
            } else {
                queue.addLast(t)
            }
        }

        kick()
    }

    private fun kick() {
        if (closed || !running.compareAndSet(false, true)) return
        scope.launch {
            try {
                while (!closed) {
                    val t = queue.pollFirst() ?: break
                    if (t.page < winFrom || t.page > winTo) continue
                    if (cache.get(Key(t.page, t.widthPx)) != null) continue

                    val bmp = runCatching { render(t.page, t.widthPx, Bitmap.Config.RGB_565) }.getOrNull() ?: continue
                    cache.put(Key(t.page, t.widthPx), bmp)

                    notifyPageRendered()
                }
            } finally {
                running.set(false)
                if (!closed && !queue.isEmpty()) kick()
            }
        }
    }

    /** Batches Compose canvas redraw triggers to 60 FPS, eliminating main-thread stalls. */
    private fun notifyPageRendered() {
        if (updateScheduled) return
        updateScheduled = true
        scope.launch(Dispatchers.Main) {
            delay(16)
            updateScheduled = false
            if (!closed) version++
        }
    }

    /** Renders one page at full quality (ARGB_8888) for export. The caller owns the bitmap. */
    fun renderPage(i: Int, widthPx: Int): Bitmap? = render(i, widthPx, Bitmap.Config.ARGB_8888, export = true)

    /**
     * High-speed rendering with reusable scratch ARGB_8888 buffer and pooled RGB_565 target bitmaps.
     */
    private fun render(i: Int, widthPx: Int, config: Bitmap.Config, export: Boolean = false): Bitmap? = synchronized(lock) {
        if (closed || i < 0 || i >= pageCount) return null
        val page = renderer.openPage(i)
        try {
            val boxW = widthPx.coerceAtLeast(1)
            val boxHpx = (boxW * boxAspect).roundToInt().coerceAtLeast(1)
            val pageAspect = page.height.toFloat() / page.width.coerceAtLeast(1)

            // 1. Prepare reusable scratch ARGB_8888 buffer
            var scratch = scratchArgb
            if (scratch == null || scratch.isRecycled || scratch.width != boxW || scratch.height != boxHpx) {
                scratch?.recycle()
                scratch = Bitmap.createBitmap(boxW, boxHpx, Bitmap.Config.ARGB_8888)
                if (!export) scratchArgb = scratch
            }
            scratch.eraseColor(Color.WHITE)

            if (abs(pageAspect / boxAspect - 1f) < 0.01f) {
                page.render(scratch, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            } else {
                val fitW: Int
                val fitH: Int
                if (boxW * pageAspect <= boxHpx) {
                    fitW = boxW
                    fitH = (boxW * pageAspect).roundToInt().coerceAtLeast(1)
                } else {
                    fitH = boxHpx
                    fitW = (boxHpx / pageAspect).roundToInt().coerceAtLeast(1)
                }
                val part = Bitmap.createBitmap(fitW, fitH, Bitmap.Config.ARGB_8888)
                part.eraseColor(Color.WHITE)
                page.render(part, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                Canvas(scratch).drawBitmap(part, (boxW - fitW) * 0.5f, (boxHpx - fitH) * 0.5f, null)
                part.recycle()
            }

            if (config == Bitmap.Config.ARGB_8888 || export) {
                return if (export) scratch.copy(Bitmap.Config.ARGB_8888, false) else scratch
            }

            // 2. Convert to RGB_565 using a pooled bitmap if available
            var dest: Bitmap? = null
            while (dest == null && !bitmapPool.isEmpty()) {
                val candidate = bitmapPool.poll()
                if (candidate != null && !candidate.isRecycled && candidate.width == boxW && candidate.height == boxHpx && candidate.config == Bitmap.Config.RGB_565) {
                    dest = candidate
                } else {
                    candidate?.recycle()
                }
            }

            if (dest == null) {
                dest = Bitmap.createBitmap(boxW, boxHpx, Bitmap.Config.RGB_565)
            }

            // Draw scratch onto RGB_565 destination bitmap
            Canvas(dest).drawBitmap(scratch, 0f, 0f, null)
            dest
        } finally {
            page.close()
        }
    }

    /** Releases memory when system is under memory pressure. */
    fun trim(aggressive: Boolean) {
        if (aggressive) {
            cache.evictAll()
            while (!bitmapPool.isEmpty()) bitmapPool.poll()?.recycle()
            scratchArgb?.recycle()
            scratchArgb = null
        } else {
            cache.trimToSize(CALCULATED_MAX_CACHE_BYTES / 3)
            while (bitmapPool.size > 4) bitmapPool.poll()?.recycle()
        }
    }

    fun close() {
        closed = true
        live.remove(this)
        queue.clear()
        scope.cancel()
        synchronized(lock) {
            scratchArgb?.recycle()
            scratchArgb = null
            runCatching { renderer.close() }
            runCatching { pfd.close() }
        }
        cache.evictAll()
        while (!bitmapPool.isEmpty()) bitmapPool.poll()?.recycle()
    }

    companion object {
        const val STD_W = 1440
        const val HD_W = 2160

        // Scale memory budget up to 256MB based on available heap
        val CALCULATED_MAX_CACHE_BYTES: Int = run {
            val maxMem = Runtime.getRuntime().maxMemory()
            ((maxMem / 3).coerceIn(128L * 1024 * 1024, 256L * 1024 * 1024)).toInt()
        }

        const val MAX_CACHE_BYTES = 256 * 1024 * 1024
        private val live = CopyOnWriteArrayList<PdfPages>()

        /** Called from MainActivity.onTrimMemory. */
        fun trimAll(aggressive: Boolean) {
            for (p in live) runCatching { p.trim(aggressive) }
        }
    }
}
