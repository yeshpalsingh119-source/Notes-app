package com.example.inknotes.ui.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.inknotes.domain.model.PageObject
import kotlin.math.roundToInt

/** State of a finger gesture on an object (kept across recompositions). mode: -1 none, 0 select only, 1 move, 2 resize. */
class ObjectDrag {
    var mode = -1
    var id = ""
    var sx = 0f
    var sy = 0f
    var lx = 0f
    var ly = 0f
    var dist = 0f
    var moved = false
}

val stickyColors: List<Int> = listOf(0xFFFFF59D, 0xFFFFCC80, 0xFFF8BBD0, 0xFFB3E5FC).map { it.toInt() }

/** Index of the table cell under a page point (row-major), or -1 when the object is not a table. */
fun cellAt(o: PageObject, px: Float, py: Float): Int {
    if (!o.isTable || o.rows <= 0 || o.cols <= 0) return -1
    val r = (((py - o.y) / o.h) * o.rows).toInt().coerceIn(0, o.rows - 1)
    val c = (((px - o.x) / o.w) * o.cols).toInt().coerceIn(0, o.cols - 1)
    return r * o.cols + c
}

/**
 * Sticky notes, tables and maths answers. Only DRAWS: the ink view handles the finger (tap = select, drag = move,
 * corner = resize) and the pen, so the pen can write on top of them. Placed with the same viewport modifier as photos.
 */
@Composable
fun ObjectLayer(objects: List<PageObject>, selectedId: String?, modifier: Modifier = Modifier) {
    val d = LocalDensity.current
    val primary = MaterialTheme.colorScheme.primary
    Box(modifier) {
        for (o in objects) {
            key(o.id) {
                val sel = o.id == selectedId
                Box(
                    Modifier.offset { IntOffset(o.x.roundToInt(), o.y.roundToInt()) }
                        .size(with(d) { o.w.toDp() }, with(d) { o.h.toDp() })
                ) {
                    when {
                        o.isSticky -> StickyBody(o, d)
                        o.isTable -> TableBody(o, d)
                        else -> Text(
                            o.text, color = Color(o.color), fontSize = with(d) { (o.h * 0.8f).toSp() }, maxLines = 1
                        )
                    }
                    if (sel && !o.isText) {
                        Box(Modifier.fillMaxSize().border(with(d) { 4f.toDp() }, primary))
                        Box(
                            Modifier.align(Alignment.BottomEnd).offset(with(d) { 18f.toDp() }, with(d) { 18f.toDp() })
                                .size(with(d) { 36f.toDp() }).clip(CircleShape).background(primary)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun StickyBody(o: PageObject, d: Density) {
    Box(Modifier.fillMaxSize().background(Color(o.color))) {
        Box(
            Modifier.align(Alignment.TopCenter).offset(y = with(d) { (-14f).toDp() })
                .width(with(d) { 130f.toDp() }).height(with(d) { 32f.toDp() }).background(Color(0x88FFFFFF))
        )
        Text(
            o.text, Modifier.padding(with(d) { 24f.toDp() }), fontSize = with(d) { 38f.toSp() },
            color = Color(0xFF3A3A3A), overflow = TextOverflow.Clip
        )
    }
}

@Composable
private fun TableBody(o: PageObject, d: Density) {
    val line = Color(0xFFB9B4C9)
    Column(Modifier.fillMaxSize().background(Color.White).border(with(d) { 2f.toDp() }, line)) {
        for (r in 0 until o.rows) {
            Row(Modifier.weight(1f).fillMaxWidth()) {
                for (c in 0 until o.cols) {
                    val header = r == 0 || c == 0
                    Box(
                        Modifier.weight(1f).fillMaxHeight()
                            .background(if (header) Color(o.color) else Color.White)
                            .border(with(d) { 1f.toDp() }, line)
                            .padding(with(d) { 8f.toDp() })
                    ) {
                        Text(
                            o.cells.getOrElse(r * o.cols + c) { "" }, fontSize = with(d) { 30f.toSp() },
                            color = Color(0xFF333333), maxLines = 3, overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

/** Floating menu above the selected object (not scaled with the page): sticky = Background colour + Delete, table = rows/columns. */
@Composable
fun ObjectMenu(
    o: PageObject,
    onColor: (Int) -> Unit,
    onAddRow: () -> Unit,
    onAddCol: () -> Unit,
    onStyle: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(modifier, shape = RoundedCornerShape(24.dp), shadowElevation = 6.dp, color = MaterialTheme.colorScheme.surface) {
        Row(Modifier.padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            if (o.isSticky) {
                Text("Background colour", Modifier.padding(end = 8.dp), fontSize = 12.sp)
                stickyColors.forEach { c ->
                    Box(
                        Modifier.padding(horizontal = 3.dp).size(26.dp).clip(CircleShape).background(Color(c))
                            .border(if (o.color == c) 2.dp else 1.dp, MaterialTheme.colorScheme.outline, CircleShape)
                            .clickable { onColor(c) }
                    )
                }
            } else {
                TextButton(onAddRow, contentPadding = PaddingValues(horizontal = 8.dp)) { Text("Add row", fontSize = 12.sp) }
                TextButton(onAddCol, contentPadding = PaddingValues(horizontal = 8.dp)) { Text("Add column", fontSize = 12.sp) }
                TextButton(onStyle, contentPadding = PaddingValues(horizontal = 8.dp)) { Text("Table style", fontSize = 12.sp) }
            }
            IconButton(onDelete, Modifier.size(36.dp)) { Icon(Icons.Default.Delete, if (o.isTable) "Delete table" else "Delete") }
        }
    }
}

/** Samsung "Table properties": Rows x Columns, Cancel / Done. */
@Composable
fun TablePropertiesDialog(onCancel: () -> Unit, onDone: (Int, Int) -> Unit) {
    var rows by remember { mutableIntStateOf(3) }
    var cols by remember { mutableIntStateOf(3) }
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text("Table properties") },
        text = {
            Column {
                Stepper("Rows", rows, 1, 12) { rows = it }
                Spacer(Modifier.height(8.dp))
                Stepper("Columns", cols, 1, 8) { cols = it }
            }
        },
        confirmButton = { TextButton({ onDone(rows, cols) }) { Text("Done") } },
        dismissButton = { TextButton(onCancel) { Text("Cancel") } }
    )
}

@Composable
private fun Stepper(label: String, value: Int, min: Int, max: Int, onChange: (Int) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        IconButton({ onChange((value - 1).coerceAtLeast(min)) }) { Icon(Icons.Default.Remove, "Less") }
        Text("$value", Modifier.width(28.dp), style = MaterialTheme.typography.titleMedium)
        IconButton({ onChange((value + 1).coerceAtMost(max)) }) { Icon(Icons.Default.Add, "More") }
    }
}

/** Text of a sticky note or of one table cell. */
@Composable
fun ObjectTextDialog(title: String, initial: String, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth()) },
        confirmButton = { TextButton({ onSave(text) }) { Text("Done") } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } }
    )
}
