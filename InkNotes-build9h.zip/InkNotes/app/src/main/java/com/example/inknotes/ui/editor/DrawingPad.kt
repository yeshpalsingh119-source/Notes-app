package com.example.inknotes.ui.editor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.CanvasDrawScope
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

private enum class PadBrush(val label: String) { PENCIL("Pencil"), MARKER("Marker"), BRUSH("Brush"), SPRAY("Spray") }

private class PadStroke(val brush: PadBrush, val color: Color, val width: Float, val seed: Int) {
    val pts = ArrayList<Offset>()
}

private fun DrawScope.drawPaper() {
    drawRect(Color(0xFFFFFCF5))
    val r = Random(7)                                           // faint paper grain
    repeat(1400) {
        drawCircle(Color(0x12000000), 1.2f, Offset(r.nextFloat() * size.width, r.nextFloat() * size.height))
    }
}

private fun DrawScope.drawPadStroke(s: PadStroke) {
    if (s.pts.isEmpty()) return
    if (s.brush == PadBrush.SPRAY) {
        val r = Random(s.seed)
        for (p in s.pts) repeat(14) {
            val a = r.nextFloat() * 6.2831855f
            val d = r.nextFloat() * s.width * 2f
            drawCircle(s.color.copy(alpha = 0.55f), 1.7f, Offset(p.x + cos(a) * d, p.y + sin(a) * d))
        }
        return
    }
    val alpha = if (s.brush == PadBrush.MARKER) 0.45f else if (s.brush == PadBrush.PENCIL) 0.9f else 0.85f
    val width = if (s.brush == PadBrush.MARKER) s.width * 2.5f else s.width
    if (s.pts.size == 1) { drawCircle(s.color.copy(alpha = alpha), width / 2f, s.pts[0]); return }
    val path = Path()
    path.moveTo(s.pts[0].x, s.pts[0].y)
    for (i in 1 until s.pts.size) {
        val a = s.pts[i - 1]
        val b = s.pts[i]
        path.quadraticBezierTo(a.x, a.y, (a.x + b.x) / 2f, (a.y + b.y) / 2f)
    }
    path.lineTo(s.pts.last().x, s.pts.last().y)
    drawPath(
        path, s.color.copy(alpha = alpha),
        style = Stroke(width = width, cap = if (s.brush == PadBrush.MARKER) StrokeCap.Square else StrokeCap.Round, join = StrokeJoin.Round)
    )
}

private val padColors = listOf(0xFF222222, 0xFFE53935, 0xFFFB8C00, 0xFFFDD835, 0xFF43A047, 0xFF1E88E5, 0xFF8E24AA, 0xFF795548)
    .map { Color(it) }

/**
 * Insert > Drawing: a full-screen sketch pad on textured paper (Pencil, Marker, Brush, Spray + colours, undo / redo).
 * Done hands the picture back; the editor puts it on the page as an image.
 */
@Composable
fun DrawingPad(onCancel: () -> Unit, onDone: (ImageBitmap) -> Unit) {
    val strokes = remember { mutableStateListOf<PadStroke>() }
    val undone = remember { mutableStateListOf<PadStroke>() }
    var brush by remember { mutableStateOf(PadBrush.PENCIL) }
    var color by remember { mutableStateOf(padColors[0]) }
    var width by remember { mutableFloatStateOf(6f) }
    var tick by remember { mutableIntStateOf(0) }              // bumped while a stroke grows, to redraw
    var current by remember { mutableStateOf<PadStroke?>(null) }
    var size by remember { mutableStateOf(IntSize.Zero) }
    val density = LocalDensity.current
    val accent = MaterialTheme.colorScheme.primary

    Dialog(onDismissRequest = onCancel, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = Color(0xFFF2F2F4)) {
            Column(Modifier.fillMaxSize().systemBarsPadding()) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onCancel) { Icon(Icons.Default.Close, "Cancel") }
                    PadBrush.entries.forEach { b ->
                        TextButton(
                            onClick = { brush = b },
                            colors = ButtonDefaults.textButtonColors(contentColor = if (b == brush) accent else MaterialTheme.colorScheme.onSurface)
                        ) { Text(b.label) }
                    }
                    Spacer(Modifier.weight(1f))
                    padColors.forEach { c ->
                        Box(
                            Modifier.padding(horizontal = 4.dp).size(30.dp).clip(CircleShape).background(c)
                                .border(if (c == color) 3.dp else 1.dp, if (c == color) accent else Color(0x33000000), CircleShape)
                                .clickable { color = c }
                        )
                    }
                }
                Canvas(
                    Modifier.weight(1f).fillMaxWidth().onSizeChanged { size = it }
                        .pointerInput(brush, color, width) {
                            detectDragGestures(
                                onDragStart = { o ->
                                    val s = PadStroke(brush, color, width, (o.x * 31f + o.y).toInt())
                                    s.pts.add(o)
                                    current = s
                                    tick++
                                },
                                onDrag = { change, _ ->
                                    change.consume()
                                    current?.pts?.add(change.position)
                                    tick++
                                },
                                onDragEnd = {
                                    current?.let { strokes.add(it); undone.clear() }
                                    current = null
                                    tick++
                                },
                                onDragCancel = { current = null; tick++ }
                            )
                        }
                ) {
                    val t = tick
                    if (t >= 0) {
                        drawPaper()
                        strokes.forEach { drawPadStroke(it) }
                        current?.let { drawPadStroke(it) }
                    }
                }
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton({ if (strokes.isNotEmpty()) undone.add(strokes.removeAt(strokes.lastIndex)); tick++ }, enabled = strokes.isNotEmpty()) {
                        Icon(Icons.AutoMirrored.Filled.Undo, "Undo")
                    }
                    IconButton({ if (undone.isNotEmpty()) strokes.add(undone.removeAt(undone.lastIndex)); tick++ }, enabled = undone.isNotEmpty()) {
                        Icon(Icons.AutoMirrored.Filled.Redo, "Redo")
                    }
                    Text("Size", Modifier.padding(start = 16.dp, end = 8.dp))
                    Slider(width, { width = it }, Modifier.width(220.dp), valueRange = 2f..40f)
                    Spacer(Modifier.weight(1f))
                    Button(
                        onClick = {
                            if (size.width > 0 && size.height > 0) {
                                val img = ImageBitmap(size.width, size.height)
                                val canvas = androidx.compose.ui.graphics.Canvas(img)
                                CanvasDrawScope().draw(density, LayoutDirection.Ltr, canvas, Size(size.width.toFloat(), size.height.toFloat())) {
                                    drawPaper()
                                    strokes.forEach { drawPadStroke(it) }
                                }
                                onDone(img)
                            } else onCancel()
                        },
                        enabled = strokes.isNotEmpty()
                    ) { Text("Done") }
                }
            }
        }
    }
}
