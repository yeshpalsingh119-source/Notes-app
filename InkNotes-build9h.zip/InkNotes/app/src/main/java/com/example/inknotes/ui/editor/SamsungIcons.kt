package com.example.inknotes.ui.editor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp

/** Line icons for the toolbar, in the style of Samsung Notes (pen + extra symbol, tape roll, marker, ...). */
enum class SnKind { KEYBOARD, CLEANUP, HELP, CONVERT, TAPE, LASER, STYLE, PAD, LOCK, LOCK_OPEN, CUSTOMIZE }

@Composable
fun SnIcon(kind: SnKind, tint: Color, modifier: Modifier = Modifier.size(26.dp)) {
    Canvas(modifier) {
        val u = size.minDimension / 24f
        val sw = 1.5f * u
        val st = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round)
        fun o(x: Float, y: Float) = Offset(x * u, y * u)
        fun line(x1: Float, y1: Float, x2: Float, y2: Float) =
            drawLine(tint, o(x1, y1), o(x2, y2), strokeWidth = sw, cap = StrokeCap.Round)
        fun dot(x: Float, y: Float, r: Float) = drawCircle(tint, r * u, o(x, y))
        fun ring(x: Float, y: Float, r: Float) = drawCircle(tint, r * u, o(x, y), style = st)

        // the small tilted pen used by the first icons of the second group
        fun pen() {
            val p = Path().apply {
                moveTo(3f * u, 19f * u)
                lineTo(4.2f * u, 14.2f * u)
                lineTo(13.2f * u, 5.2f * u)
                lineTo(16.8f * u, 8.8f * u)
                lineTo(7.8f * u, 17.8f * u)
                close()
            }
            drawPath(p, tint, style = st)
            line(4.2f, 14.2f, 7.8f, 17.8f)
        }

        when (kind) {
            SnKind.KEYBOARD -> {
                drawRoundRect(tint, o(2.5f, 6.5f), Size(19f * u, 11f * u), CornerRadius(2.2f * u), style = st)
                for (x in listOf(6.2f, 9.4f, 12.6f, 15.8f, 19f)) dot(x, 10.2f, 0.8f)
                for (x in listOf(7.8f, 11f, 14.2f, 17.4f)) dot(x, 12.9f, 0.8f)
                line(8.2f, 15.2f, 15.8f, 15.2f)
            }
            SnKind.CLEANUP -> {
                pen()
                for ((x, y) in listOf(14f to 19.5f, 17.2f to 16.8f, 19.6f to 19.8f, 21f to 15.8f, 16.8f to 21.6f, 21.2f to 21.8f)) dot(x, y, 0.9f)
            }
            SnKind.HELP -> {
                pen()
                ring(17f, 17f, 4.4f)
                line(15.2f, 19.4f, 17f, 14.8f)
                line(17f, 14.8f, 18.8f, 19.4f)
                line(15.9f, 18f, 18.1f, 18f)
            }
            SnKind.CONVERT -> {
                pen()
                line(13.8f, 15.2f, 21f, 15.2f)
                line(17.4f, 15.2f, 17.4f, 21.4f)
                line(16.2f, 21.4f, 18.6f, 21.4f)
            }
            SnKind.TAPE -> rotate(-45f, o(12f, 12f)) {
                val p = Path().apply {
                    moveTo(5.5f * u, 8.2f * u)
                    lineTo(17.5f * u, 8.2f * u)
                    lineTo(18.8f * u, 9.6f * u)
                    lineTo(17.5f * u, 11f * u)
                    lineTo(18.8f * u, 12.4f * u)
                    lineTo(17.5f * u, 13.8f * u)
                    lineTo(18.8f * u, 15.2f * u)
                    lineTo(5.5f * u, 15.2f * u)
                    close()
                }
                drawPath(p, tint, style = st)
                line(5.5f, 11.7f, 13f, 11.7f)
            }
            SnKind.LASER -> rotate(45f, o(12f, 12f)) {
                val body = Path().apply {
                    moveTo(8.6f * u, 4f * u); lineTo(15.4f * u, 4f * u)
                    lineTo(15.4f * u, 15f * u); lineTo(8.6f * u, 15f * u); close()
                }
                drawPath(body, Color(0xFFFFE04D))
                drawPath(body, tint, style = st)
                val tip = Path().apply {
                    moveTo(8.6f * u, 15f * u); lineTo(15.4f * u, 15f * u); lineTo(12f * u, 21f * u); close()
                }
                drawPath(tip, tint, style = st)
                line(8.6f, 9f, 15.4f, 9f)
            }
            SnKind.STYLE -> {
                val a = Path().apply {
                    moveTo(5f * u, 20f * u); lineTo(12f * u, 4f * u); lineTo(19f * u, 20f * u)
                    moveTo(8f * u, 14.6f * u); lineTo(16f * u, 14.6f * u)
                }
                drawPath(a, tint, style = Stroke(width = 5f * u, cap = StrokeCap.Round, join = StrokeJoin.Round))
                drawPath(a, Color.White, style = Stroke(width = 3.7f * u, cap = StrokeCap.Round, join = StrokeJoin.Round))
                drawPath(a, Color(0xFFE53935), style = Stroke(width = 2.1f * u, cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
            SnKind.PAD -> {
                line(3f, 4.5f, 21f, 4.5f)
                line(3f, 19.5f, 21f, 19.5f)
                ring(7.4f, 12.4f, 2.6f)
                line(10f, 9.6f, 10f, 15f)
                line(16.4f, 8f, 16.4f, 16f)
                line(14.6f, 9.8f, 16.4f, 8f)
                line(18.2f, 9.8f, 16.4f, 8f)
                line(14.6f, 14.2f, 16.4f, 16f)
                line(18.2f, 14.2f, 16.4f, 16f)
            }
            SnKind.LOCK, SnKind.LOCK_OPEN -> {
                drawRoundRect(tint, o(3.5f, 3f), Size(14f * u, 16f * u), CornerRadius(3f * u), style = st)
                drawRoundRect(Color.White, o(12.6f, 13.2f), Size(8.8f * u, 8f * u), CornerRadius(1.6f * u))
                drawRoundRect(tint, o(12.8f, 13.6f), Size(8.4f * u, 7.4f * u), CornerRadius(1.6f * u), style = st)
                val shackle = Path().apply {
                    moveTo(14.6f * u, 13.6f * u)
                    lineTo(14.6f * u, 11.8f * u)
                    cubicTo(14.6f * u, 9.4f * u, 19.4f * u, 9.4f * u, 19.4f * u, 11.8f * u)
                    if (kind == SnKind.LOCK) lineTo(19.4f * u, 13.6f * u)
                }
                drawPath(shackle, tint, style = st)
                dot(17f, 17.2f, 0.9f)
            }
            SnKind.CUSTOMIZE -> {
                ring(6.6f, 6.6f, 2.9f)
                ring(17.4f, 6.6f, 2.9f)
                ring(6.6f, 17.4f, 2.9f)
                ring(17.4f, 17.4f, 2.1f)
                for (i in 0 until 6) {
                    val ang = Math.toRadians(i * 60.0)
                    val cx = kotlin.math.cos(ang).toFloat()
                    val cy = kotlin.math.sin(ang).toFloat()
                    line(17.4f + cx * 3.1f, 17.4f + cy * 3.1f, 17.4f + cx * 4.1f, 17.4f + cy * 4.1f)
                }
            }
        }
    }
}
