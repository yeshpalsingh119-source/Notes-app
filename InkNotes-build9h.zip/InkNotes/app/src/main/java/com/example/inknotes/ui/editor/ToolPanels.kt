package com.example.inknotes.ui.editor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Adjust
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Spellcheck
import androidx.compose.material.icons.filled.Straighten
import androidx.compose.material.icons.filled.Style
import androidx.compose.material.icons.filled.DragIndicator
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.FormatAlignCenter
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.layout
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import com.example.inknotes.domain.model.LineStyle
import com.example.inknotes.domain.model.PenType
import com.example.inknotes.domain.model.ShapeKind
import com.example.inknotes.domain.model.Tool
import kotlin.math.roundToInt

enum class PanelKind { PEN, HIGHLIGHTER, ERASER, SHAPE, TAPE, LASER, HELP, STYLE, SELECT }

/** Where the toolbar is docked. It is moved by dragging its handle to another edge. */
enum class ToolbarDock { BOTTOM, TOP, LEFT, RIGHT }

private val palette = listOf(0xFFFF4D4D, 0xFFFFC933, 0xFFFCEB00, 0xFF2EE6D0, 0xFF2E96FF, 0xFF1F3BFF, 0xFF9B30FF, 0xFF2A2A2A)
    .map { it.toInt() }

// =============================================================== toolbar (Samsung Notes style, can be docked to any edge)
@Composable
fun DrawToolbar(
    pen: PenState,
    history: HistoryState,
    dock: ToolbarDock,
    items: List<ToolbarItem>,
    recording: Boolean,
    onDockTo: (Float, Float) -> Unit,
    onToolTap: (Tool) -> Unit,
    hasSelection: Boolean,
    onConvert: () -> Unit,
    onAlign: () -> Unit,
    onStyle: () -> Unit,
    onHelp: () -> Unit,
    onPad: () -> Unit,
    onVoice: () -> Unit,
    onAnchor: (String, Rect) -> Unit,
    onLockCanvas: () -> Unit,
    onText: () -> Unit,
    onPhoto: () -> Unit,
    onFavorite: (Favorite) -> Unit,
    onColor: (Int) -> Unit,
    onThickness: () -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onCustomize: () -> Unit = {}
) {
    val onSurface = MaterialTheme.colorScheme.onSurface
    val vertical = dock == ToolbarDock.LEFT || dock == ToolbarDock.RIGHT

    // drag handle: drop it near another edge to dock the toolbar there
    var handleCenter by remember { mutableStateOf(Offset.Zero) }
    var dragTotal by remember { mutableStateOf(Offset.Zero) }
    val dockCallback = rememberUpdatedState(onDockTo)
    val handle: @Composable () -> Unit = {
        Box(
            Modifier.size(44.dp)
                .onGloballyPositioned { handleCenter = it.boundsInWindow().center }
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragStart = { dragTotal = Offset.Zero },
                        onDragEnd = { dockCallback.value(handleCenter.x + dragTotal.x, handleCenter.y + dragTotal.y) },
                        onDragCancel = { }
                    ) { change, drag -> change.consume(); dragTotal += drag }
                },
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Default.DragIndicator, "Move toolbar (drag to another edge)", Modifier.size(22.dp), tint = onSurface.copy(alpha = 0.55f)) }
    }

    fun anchored(key: String) = Modifier.onGloballyPositioned { c -> onAnchor(key, c.boundsInWindow()) }

    val buttons: @Composable () -> Unit = {
        handle()
        items.forEach { item ->
            when (item) {
                ToolbarItem.TEXT -> ToolButton(false, onText) { SnIcon(SnKind.KEYBOARD, onSurface) }
                ToolbarItem.PEN -> ToolButton(pen.tool == Tool.PEN, { onToolTap(Tool.PEN) }, modifier = anchored("PEN")) {
                    ToolGlyph(Glyph.PEN, onSurface, Color(pen.settings[pen.pen]?.color ?: 0xFF7086F7.toInt()))
                }
                ToolbarItem.HIGHLIGHTER -> ToolButton(pen.tool == Tool.HIGHLIGHTER, { onToolTap(Tool.HIGHLIGHTER) }, modifier = anchored("HIGHLIGHTER")) {
                    ToolGlyph(Glyph.HIGHLIGHTER, onSurface, Color(pen.settings[pen.highlighter]?.color ?: 0xFFFDE047.toInt()))
                }
                ToolbarItem.TAPE -> ToolButton(pen.tool == Tool.TAPE, { onToolTap(Tool.TAPE) }, modifier = anchored("TAPE")) {
                    SnIcon(SnKind.TAPE, onSurface)
                }
                ToolbarItem.ERASER -> ToolButton(pen.tool == Tool.ERASER, { onToolTap(Tool.ERASER) }, modifier = anchored("ERASER")) {
                    ToolGlyph(Glyph.ERASER, onSurface, Color(0xFFF48F8A))
                }
                ToolbarItem.LASSO -> ToolButton(pen.tool == Tool.SELECT, { onToolTap(Tool.SELECT) }, modifier = anchored("SELECT")) { ToolGlyph(Glyph.LASSO, onSurface, onSurface) }
                ToolbarItem.CONVERT -> ToolButton(false, onConvert, enabled = hasSelection) { SnIcon(SnKind.CONVERT, onSurface) }
                ToolbarItem.CLEANUP -> ToolButton(false, onAlign, enabled = hasSelection) { SnIcon(SnKind.CLEANUP, onSurface) }
                ToolbarItem.STYLE -> ToolButton(false, onStyle, modifier = anchored("STYLE")) { SnIcon(SnKind.STYLE, onSurface) }
                ToolbarItem.HELP -> ToolButton(pen.helpGuideline || pen.helpAlign || pen.helpFix, onHelp, modifier = anchored("HELP")) { SnIcon(SnKind.HELP, onSurface) }
                ToolbarItem.SHAPES -> ToolButton(pen.tool == Tool.SHAPE, { onToolTap(Tool.SHAPE) }, modifier = anchored("SHAPE")) {
                    ToolGlyph(Glyph.SHAPES, onSurface, onSurface)
                }
                ToolbarItem.LASER -> ToolButton(pen.tool == Tool.LASER, { onToolTap(Tool.LASER) }, modifier = anchored("LASER")) {
                    SnIcon(SnKind.LASER, onSurface)
                }
                ToolbarItem.PHOTO -> ToolButton(false, onPhoto) { Icon(Icons.Default.Image, "Photo") }
                ToolbarItem.PAD -> ToolButton(false, onPad) { SnIcon(SnKind.PAD, onSurface) }
                ToolbarItem.VOICE -> ToolButton(recording, onVoice) {
                    Icon(Icons.Default.Mic, "Voice recording", tint = if (recording) Color(0xFFD32F2F) else onSurface)
                }
                ToolbarItem.LOCK -> ToolButton(pen.lockCanvas, onLockCanvas) {
                    SnIcon(if (pen.lockCanvas) SnKind.LOCK else SnKind.LOCK_OPEN, onSurface)
                }
                ToolbarItem.COLORS -> {
                    BarDivider(vertical)
                    pen.recentColors.forEach { c -> ColorDot(c, c == pen.active.color) { onColor(c) } }
                }
                ToolbarItem.THICKNESS -> ToolButton(false, onThickness) {
                    Box(Modifier.width(26.dp).height((2f + pen.active.size / 14f).dp).clip(CircleShape).background(onSurface))
                }
                ToolbarItem.UNDO -> {
                    BarDivider(vertical)
                    ToolButton(false, onUndo, enabled = history.canUndo) { Icon(Icons.AutoMirrored.Filled.Undo, "Undo") }
                }
                ToolbarItem.REDO -> ToolButton(false, onRedo, enabled = history.canRedo) { Icon(Icons.AutoMirrored.Filled.Redo, "Redo") }
                ToolbarItem.FAVORITES -> {
                    if (pen.favorites.isNotEmpty()) {
                        BarDivider(vertical)
                        pen.favorites.forEach { f ->
                            ToolButton(false, { onFavorite(f) }) {
                                ToolGlyph(if (f.pen.isHighlighter) Glyph.HIGHLIGHTER else Glyph.PEN, onSurface, Color(f.color))
                            }
                        }
                    }
                }
            }
            Unit
        }
        BarDivider(vertical)
        ToolButton(false, onCustomize) { SnIcon(SnKind.CUSTOMIZE, onSurface) }
    }

    Surface(color = MaterialTheme.colorScheme.surface, tonalElevation = 0.dp) {
        if (vertical) {
            Row(Modifier.fillMaxHeight()) {
                if (dock == ToolbarDock.RIGHT) VerticalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                Column(
                    Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 6.dp, vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) { buttons() }
                if (dock == ToolbarDock.LEFT) VerticalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            }
        } else {
            Column {
                if (dock == ToolbarDock.BOTTOM) HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                Box(
                    if (dock == ToolbarDock.BOTTOM) Modifier.fillMaxWidth().navigationBarsPadding() else Modifier.fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) { buttons() }
                }
                if (dock == ToolbarDock.TOP) HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            }
        }
    }
}

@Composable
private fun BarDivider(vertical: Boolean = false) {
    val c = MaterialTheme.colorScheme.outlineVariant
    if (vertical) Box(Modifier.padding(vertical = 6.dp).width(24.dp).height(1.dp).background(c))
    else Box(Modifier.padding(horizontal = 6.dp).width(1.dp).height(24.dp).background(c))
}

@Composable
fun ToolButton(
    selected: Boolean, onClick: () -> Unit, enabled: Boolean = true,
    modifier: Modifier = Modifier, content: @Composable () -> Unit
) {
    Box(
        modifier.size(44.dp).clip(CircleShape)
            .background(if (selected) MaterialTheme.colorScheme.surfaceVariant else Color.Transparent)
            .alpha(if (enabled) 1f else 0.35f)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) { content() }
}

@Composable
private fun ColorDot(color: Int, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.padding(horizontal = 4.dp).size(28.dp).clip(CircleShape).background(Color(color))
            .border(if (selected) 3.dp else 1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant, CircleShape)
            .clickable(onClick = onClick)
    )
}

// =============================================================== tool glyphs
enum class Glyph { PEN, HIGHLIGHTER, ERASER, LASSO, SHAPES }

@Composable
fun ToolGlyph(g: Glyph, tint: Color, accent: Color, modifier: Modifier = Modifier.size(28.dp)) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val sw = 2.2f.dp.toPx()
        when (g) {
            Glyph.PEN, Glyph.HIGHLIGHTER -> rotate(40f, center) {
                val bw = w * 0.30f
                val l = center.x - bw / 2f
                drawRoundRect(tint, Offset(l, h * 0.05f), Size(bw, h * 0.62f), CornerRadius(3f.dp.toPx()), style = Stroke(sw))
                val tip = Path().apply {
                    moveTo(l, h * 0.70f); lineTo(l + bw, h * 0.70f)
                    lineTo(if (g == Glyph.PEN) center.x else l + bw * 0.8f, h * 0.96f)
                    lineTo(if (g == Glyph.PEN) center.x else l + bw * 0.2f, h * 0.96f)
                    close()
                }
                if (g == Glyph.HIGHLIGHTER) drawPath(tip, accent) else drawPath(tip, tint, style = Stroke(sw, join = StrokeJoin.Round))
                drawRect(accent, Offset(l, h * 0.40f), Size(bw, h * 0.12f))
            }
            Glyph.ERASER -> rotate(-40f, center) {
                val bw = w * 0.42f
                val l = center.x - bw / 2f
                drawRoundRect(tint, Offset(l, h * 0.12f), Size(bw, h * 0.76f), CornerRadius(4f.dp.toPx()), style = Stroke(sw))
                drawRoundRect(accent, Offset(l, h * 0.50f), Size(bw, h * 0.38f), CornerRadius(4f.dp.toPx()))
            }
            Glyph.SHAPES -> {
                drawCircle(tint, w * 0.24f, Offset(w * 0.37f, h * 0.40f), style = Stroke(sw))
                drawRect(tint, Offset(w * 0.45f, h * 0.45f), Size(w * 0.40f, h * 0.40f), style = Stroke(sw))
            }
            Glyph.LASSO -> drawOval(
                tint, Offset(w * 0.12f, h * 0.2f), Size(w * 0.76f, h * 0.6f),
                style = Stroke(sw, pathEffect = PathEffect.dashPathEffect(floatArrayOf(7.dp.toPx(), 5.dp.toPx())))
            )
        }
    }
}

// =============================================================== compact floating panel (Dialog = always above the ink surface)
// Opens next to the toolbar, right at the tool that was tapped (above it when the toolbar is at the bottom,
// below it at the top, beside it when it is docked left / right).
@Composable
fun ToolPanelDialog(
    kind: PanelKind,
    pen: PenState,
    anchor: Rect?,            // the tapped tool button, in SCREEN pixels
    dock: ToolbarDock,
    update: ((PenState) -> PenState) -> Unit,
    onClearAll: () -> Unit,
    onRemoveTape: () -> Unit,
    onPickColor: () -> Unit,
    onDismiss: () -> Unit,
    onPickLaserColor: () -> Unit = {},
    customContent: @Composable ColumnScope.() -> Unit = {}
) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        val view = LocalView.current
        val window = (view.parent as? DialogWindowProvider)?.window
        SideEffect { window?.setDimAmount(0f) }
        val none = remember { MutableInteractionSource() }
        val cardWdp = minOf(320, LocalConfiguration.current.screenWidthDp - 16)
        Box(
            Modifier.fillMaxSize().clickable(interactionSource = none, indication = null, onClick = onDismiss)
        ) {
            Card(
                Modifier
                    .layout { measurable, constraints ->
                        val placeable = measurable.measure(constraints)
                        layout(constraints.maxWidth, constraints.maxHeight) {
                            val loc = IntArray(2)
                            view.getLocationOnScreen(loc)          // this window's origin on screen
                            val gap = 8.dp.roundToPx()
                            val edge = 8.dp.roundToPx()
                            val w = placeable.width
                            val h = placeable.height
                            val maxX = (constraints.maxWidth - w - edge).coerceAtLeast(edge)
                            val maxY = (constraints.maxHeight - h - edge).coerceAtLeast(edge)
                            var x = 0
                            var y = 0
                            if (anchor == null) {
                                x = (constraints.maxWidth - w) / 2
                                y = constraints.maxHeight - h - 96.dp.roundToPx()
                            } else {
                                val aL = anchor.left - loc[0]; val aR = anchor.right - loc[0]
                                val aT = anchor.top - loc[1]; val aB = anchor.bottom - loc[1]
                                when (dock) {
                                    ToolbarDock.BOTTOM -> { x = ((aL + aR) / 2f - w / 2f).roundToInt(); y = (aT - gap - h).roundToInt() }
                                    ToolbarDock.TOP -> { x = ((aL + aR) / 2f - w / 2f).roundToInt(); y = (aB + gap).roundToInt() }
                                    ToolbarDock.LEFT -> { x = (aR + gap).roundToInt(); y = ((aT + aB) / 2f - h / 2f).roundToInt() }
                                    ToolbarDock.RIGHT -> { x = (aL - gap - w).roundToInt(); y = ((aT + aB) / 2f - h / 2f).roundToInt() }
                                }
                            }
                            placeable.place(x.coerceIn(edge, maxX), y.coerceIn(edge, maxY))
                        }
                    }
                    .width(cardWdp.dp)
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { },
                shape = RoundedCornerShape(24.dp),
                elevation = CardDefaults.cardElevation(8.dp)
            ) {
                Column(Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
                    if (kind == PanelKind.LASER || kind == PanelKind.HELP || kind == PanelKind.STYLE || kind == PanelKind.SELECT) Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            when (kind) {
                                PanelKind.LASER -> "Laser pointer"
                                PanelKind.HELP -> "Handwriting help"
                                PanelKind.STYLE -> "Change style"
                                else -> "Selection mode"
                            },
                            Modifier.weight(1f).padding(start = 6.dp), style = MaterialTheme.typography.titleSmall
                        )
                        Box(
                            Modifier.size(32.dp).clip(CircleShape).background(Color(0xFFEFEFF2)).clickable(onClick = onDismiss),
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.Default.Close, "Close", Modifier.size(18.dp), tint = Color(0xFF222222)) }
                    } else Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        if (kind == PanelKind.PEN || kind == PanelKind.HIGHLIGHTER) {
                            val fav = pen.isFavorite()
                            IconButton(onClick = { update { it.toggleFavorite() } }, modifier = Modifier.size(36.dp)) {
                                Icon(
                                    if (fav) Icons.Default.Star else Icons.Default.StarBorder, "Favourite pen",
                                    tint = if (fav) Color(0xFFFFB300) else MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        } else if (kind == PanelKind.TAPE) {
                            IconButton(onClick = { update { it.copy(tapeHidden = !it.tapeHidden) } }, modifier = Modifier.size(36.dp)) {
                                Icon(
                                    if (pen.tapeHidden) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    if (pen.tapeHidden) "Show tape" else "Hide tape", modifier = Modifier.size(22.dp)
                                )
                            }
                        } else Spacer(Modifier.size(36.dp))
                        Text(
                            when (kind) {
                                PanelKind.ERASER -> "Handwriting eraser"
                                PanelKind.SHAPE -> "Shapes"
                                PanelKind.TAPE -> "Tape"
                                else -> pen.activeType.label
                            },
                            Modifier.weight(1f), textAlign = TextAlign.Center,
                            style = MaterialTheme.typography.titleSmall
                        )
                        IconButton(onClick = onDismiss, modifier = Modifier.size(36.dp)) {
                            Icon(Icons.Default.Close, "Close", modifier = Modifier.size(22.dp))
                        }
                    }
                    when (kind) {
                        PanelKind.ERASER -> EraserContent(pen, update, onClearAll)
                        PanelKind.SHAPE -> ShapeContent(pen, update)
                        PanelKind.TAPE -> TapeContent(pen, update, onRemoveTape, onPickColor)
                        PanelKind.LASER -> LaserContent(pen, update, onPickLaserColor)
                        PanelKind.HELP -> HelpContent(pen, update)
                        PanelKind.STYLE, PanelKind.SELECT -> customContent()
                        else -> PenContent(kind, pen, update, onPickColor)
                    }
                }
            }
        }
    }
}

@Composable
private fun TapeSwatch(color: Color, pattern: Int, modifier: Modifier) {
    Canvas(modifier.clip(RoundedCornerShape(8.dp))) {
        drawRect(color)
        val light = Color.White.copy(alpha = 0.45f)
        val u = 8.dp.toPx()
        when (pattern) {
            1 -> { var x = -size.height; while (x < size.width) { drawLine(light, Offset(x, size.height), Offset(x + size.height, 0f), strokeWidth = 2.dp.toPx()); x += u } }
            2 -> { var y = u / 2; while (y < size.height) { var x = u / 2; while (x < size.width) { drawCircle(light, 1.6.dp.toPx(), Offset(x, y)); x += u }; y += u } }
            3 -> { var y = 0f; var row = 0; while (y < size.height) { var x = if (row % 2 == 0) 0f else u; while (x < size.width) { drawRect(light, Offset(x, y), Size(u, u)); x += 2 * u }; y += u; row++ } }
            4 -> { var x = 0f; while (x < size.width) { drawArc(light, 0f, 180f, false, Offset(x, size.height / 2 - u / 2), Size(u, u), style = Stroke(width = 1.6.dp.toPx())); x += u }; }
        }
    }
}

@Composable
private fun TapeContent(pen: PenState, update: ((PenState) -> PenState) -> Unit, onRemoveTape: () -> Unit, onPickColor: () -> Unit) {
    var tab by remember { mutableStateOf(0) }       // 0 colour, 1 pattern
    val col = Color(pen.settings[PenType.TAPE]?.color ?: 0xFF2E96FF.toInt())
    TapeSwatch(col, pen.tapePattern, Modifier.fillMaxWidth().height(34.dp).padding(vertical = 4.dp))
    SizeRow(pen.active.size) { v -> update { it.withSize(v) } }
    Row(Modifier.fillMaxWidth().padding(bottom = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FilterChip(tab == 0, { tab = 0 }, { Text("Colour") }, Modifier.weight(1f))
        FilterChip(tab == 1, { tab = 1 }, { Text("Pattern") }, Modifier.weight(1f))
    }
    if (tab == 0) {
        Spacer(Modifier.height(4.dp))
        ColorPages(
            selected = pen.active.color,
            recent = pen.settings.values.map { it.color },
            onPick = { c -> update { it.withColor(c) } },
            onCustom = onPickColor
        )
    } else {
        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (p in 0..4) {
                Box(
                    Modifier.weight(1f).height(36.dp)
                        .border(if (pen.tapePattern == p) 3.dp else 1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
                        .clip(RoundedCornerShape(8.dp)).clickable { update { it.copy(tapePattern = p) } }
                ) { TapeSwatch(col, p, Modifier.fillMaxSize()) }
            }
        }
    }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text("Straighten lines", Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Switch(pen.straighten, { v -> update { it.copy(straighten = v) } }, Modifier.scale(0.8f))
    }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text("Adjust thickness to text", Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Switch(pen.tapeAdjust, { v -> update { it.copy(tapeAdjust = v) } }, Modifier.scale(0.8f))
    }
    TextButton(onRemoveTape, Modifier.fillMaxWidth()) { Text("Remove all tape on this page") }
}

@Composable
private fun PenContent(kind: PanelKind, pen: PenState, update: ((PenState) -> PenState) -> Unit, onPickColor: () -> Unit) {
    val types = if (kind == PanelKind.PEN) {
        listOf(PenType.FOUNTAIN, PenType.CALLIGRAPHY, PenType.BALLPOINT, PenType.PENCIL, PenType.WATERCOLOR, PenType.BRUSH)
    } else listOf(PenType.HIGHLIGHTER, PenType.HIGHLIGHTER_ROUND)
    val current = pen.activeType

    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        types.forEach { t ->
            val col = Color(pen.settings[t]?.color ?: 0xFF7086F7.toInt())
            Box(Modifier.clip(RoundedCornerShape(12.dp)).clickable { update { it.withPen(t) } }) {
                PenIllustration(t, col, t == current, Modifier.width(44.dp).height(104.dp))
            }
        }
    }

    SizeRow(pen.active.size) { v -> update { it.withSize(v) } }

    if (kind == PanelKind.PEN) {
        Row(Modifier.fillMaxWidth().padding(bottom = 2.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for (ls in listOf(LineStyle.SOLID, LineStyle.TAPER, LineStyle.DASH, LineStyle.DOT)) {
                LineStyleChip(ls, pen.lineStyle == ls, Modifier.weight(1f)) { update { it.copy(lineStyle = ls) } }
            }
        }
        // Hold-to-shape is always on. "Straighten lines" is separate: a nearly straight stroke becomes a line when the pen lifts.
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Straighten lines", Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
            Switch(pen.straighten, { v -> update { it.copy(straighten = v) } }, Modifier.scale(0.8f))
        }
    }

    Spacer(Modifier.height(4.dp))
    ColorPages(
        selected = pen.active.color,
        recent = pen.settings.values.map { it.color },
        onPick = { c -> update { it.withColor(c) } },
        onCustom = onPickColor
    )
}

@Composable
private fun LineStyleChip(style: Int, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val ink = MaterialTheme.colorScheme.onSurface
    Box(
        modifier.height(32.dp).clip(RoundedCornerShape(16.dp))
            .background(if (selected) MaterialTheme.colorScheme.outlineVariant else MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxWidth(0.62f).height(14.dp)) {
            val y = size.height / 2f
            val w = size.width
            when (style) {
                LineStyle.SOLID -> drawLine(ink, Offset(0f, y), Offset(w, y), strokeWidth = 3.dp.toPx(), cap = StrokeCap.Round)
                LineStyle.TAPER -> {
                    val p = Path().apply {
                        moveTo(0f, y - 2.5f.dp.toPx()); lineTo(w, y - 0.6f.dp.toPx())
                        lineTo(w, y + 0.6f.dp.toPx()); lineTo(0f, y + 2.5f.dp.toPx()); close()
                    }
                    drawPath(p, ink)
                }
                LineStyle.DASH -> drawLine(
                    ink, Offset(0f, y), Offset(w, y), strokeWidth = 3.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(9.dp.toPx(), 6.dp.toPx()))
                )
                else -> drawLine(
                    ink, Offset(0f, y), Offset(w, y), strokeWidth = 3.dp.toPx(), cap = StrokeCap.Round,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(0.1f, 8.dp.toPx()))
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SizeRow(size: Float, onChange: (Float) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = { onChange((size - 1f).coerceAtLeast(1f)) }, modifier = Modifier.size(32.dp)) {
            Icon(Icons.Default.Remove, "Smaller", modifier = Modifier.size(20.dp))
        }
        Slider(
            value = size, onValueChange = onChange,
            valueRange = 1f..100f, modifier = Modifier.weight(1f),
            thumb = {
                Surface(shape = CircleShape, shadowElevation = 3.dp, modifier = Modifier.size(30.dp)) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("${size.roundToInt()}", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        )
        IconButton(onClick = { onChange((size + 1f).coerceAtMost(100f)) }, modifier = Modifier.size(32.dp)) {
            Icon(Icons.Default.Add, "Bigger", modifier = Modifier.size(20.dp))
        }
    }
}

private val laserColors = listOf(0xFFFFE04D, 0xFFF0506E, 0xFF6FDB8F, 0xFF7A8CFA, 0xFFDADADA, 0xFF666666, 0xFFFFB800, 0xFF2DCC5A)
    .map { it.toInt() }

@Composable
private fun PanelDots(count: Int, selected: Int) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.Center) {
        repeat(count) { i ->
            Box(
                Modifier.padding(horizontal = 4.dp).size(6.dp).clip(CircleShape)
                    .background(if (i == selected) Color(0xFF555555) else Color(0xFFCFCFD4))
            )
        }
    }
}

/** Laser pointer panel: three trail styles, Rainbow / Single colour, colour row. */
@Composable
private fun LaserContent(pen: PenState, update: ((PenState) -> PenState) -> Unit, onPickColor: () -> Unit) {
    val dark = Color(0xFF151515)
    Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        for (i in 0..2) {
            val sel = pen.laserStyle == i
            val bg = if (sel) Color(0xFFD9D9DE) else Color(0xFFEFEFF2)
            Box(
                Modifier.weight(1f).height(40.dp).clip(RoundedCornerShape(20.dp)).background(bg)
                    .clickable { update { it.copy(laserStyle = i) } },
                contentAlignment = Alignment.Center
            ) {
                Canvas(Modifier.size(width = 46.dp, height = 22.dp)) {
                    val cy = size.height / 2f
                    val x0 = 6.dp.toPx()
                    val x1 = size.width - 6.dp.toPx()
                    when (i) {
                        0 -> drawLine(dark, Offset(x0, cy), Offset(x1, cy), strokeWidth = 7.dp.toPx(), cap = StrokeCap.Round)
                        1 -> {
                            drawLine(dark, Offset(x0, cy), Offset(x1, cy), strokeWidth = 8.dp.toPx(), cap = StrokeCap.Round)
                            drawLine(bg, Offset(x0, cy), Offset(x1, cy), strokeWidth = 3.5f.dp.toPx(), cap = StrokeCap.Round)
                        }
                        else -> {
                            drawCircle(dark, 8.dp.toPx(), Offset(size.width / 2f, cy), style = Stroke(2.dp.toPx()))
                            drawCircle(dark, 3.5f.dp.toPx(), Offset(size.width / 2f, cy))
                        }
                    }
                }
            }
        }
    }
    Row(
        Modifier.fillMaxWidth().clickable { update { it.copy(laserRainbow = true) } }.padding(top = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(pen.laserRainbow, { update { it.copy(laserRainbow = true) } })
        Text("Rainbow")
    }
    Row(
        Modifier.fillMaxWidth().clickable { update { it.copy(laserRainbow = false) } },
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(!pen.laserRainbow, { update { it.copy(laserRainbow = false) } })
        Text("Single colour")
    }
    Spacer(Modifier.height(8.dp))
    ColorPages(
        selected = if (pen.laserRainbow) null else pen.laserColor,
        recent = listOf(pen.laserColor) + pen.settings.values.map { it.color },
        onPick = { c -> update { it.copy(laserColor = c, laserRainbow = false) } },
        onCustom = onPickColor
    )
}

@Composable
private fun HelpSwitchRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, Modifier.size(18.dp), tint = Color(0xFF555555))
        Text(label, Modifier.weight(1f).padding(start = 10.dp), style = MaterialTheme.typography.bodyMedium)
        Switch(checked, onChange, modifier = Modifier.scale(0.8f))
    }
}

/** Handwriting help panel (Samsung): smart guideline, align letters, fix the shape of letters. */
@Composable
private fun HelpContent(pen: PenState, update: ((PenState) -> PenState) -> Unit) {
    Box(
        Modifier.fillMaxWidth().padding(top = 10.dp).height(46.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFFF3F3F6)),
        contentAlignment = Alignment.Center
    ) {
        Text("Show a guideline to keep the handwriting", style = MaterialTheme.typography.labelSmall, color = Color(0xFF6F7CE8))
        Canvas(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 8.dp)) {
            drawLine(Color(0xFF7A7A80), Offset(0f, size.height), Offset(size.width, size.height), strokeWidth = 1.dp.toPx())
        }
    }
    PanelDots(2, 0)
    HelpSwitchRow(Icons.Default.Edit, "Smart guideline", pen.helpGuideline) { v -> update { it.copy(helpGuideline = v) } }
    HelpSwitchRow(Icons.Default.FormatAlignCenter, "Align letters", pen.helpAlign) { v -> update { it.copy(helpAlign = v) } }
    HelpSwitchRow(Icons.Default.Spellcheck, "Fix the shape of letters", pen.helpFix) { v -> update { it.copy(helpFix = v) } }
    HorizontalDivider(Modifier.padding(vertical = 6.dp), color = MaterialTheme.colorScheme.outlineVariant)
    Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("English (United States)", Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Icon(Icons.Default.Settings, "Language", Modifier.size(18.dp), tint = Color(0xFF555555))
    }
}

@Composable
private fun EraserContent(pen: PenState, update: ((PenState) -> PenState) -> Unit, onClearAll: () -> Unit) {
    // Samsung "Handwriting eraser": Stroke eraser / Area eraser, two toggles, Erase all handwriting
    Row(
        Modifier.fillMaxWidth().clickable { update { it.copy(areaEraser = false) } }.padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(!pen.areaEraser, { update { it.copy(areaEraser = false) } })
        Text("Stroke eraser", Modifier.padding(start = 8.dp))
    }
    Row(
        Modifier.fillMaxWidth().clickable { update { it.copy(areaEraser = true) } }.padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(pen.areaEraser, { update { it.copy(areaEraser = true) } })
        Text("Area eraser", Modifier.padding(start = 8.dp))
    }
    if (pen.areaEraser) SizeRow(pen.eraserSize) { v -> update { it.copy(eraserSize = v) } }
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("Erase highlighter only", Modifier.weight(1f))
        Switch(pen.eraseHighlighterOnly, { v -> update { it.copy(eraseHighlighterOnly = v) } })
    }
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("Erase tape only", Modifier.weight(1f))
        Switch(pen.eraseTapeOnly, { v -> update { it.copy(eraseTapeOnly = v) } })
    }
    HorizontalDivider(Modifier.padding(vertical = 4.dp))
    TextButton(onClearAll, Modifier.fillMaxWidth()) { Text("Erase all handwriting", fontWeight = androidx.compose.ui.text.font.FontWeight.Bold) }
}

@Composable
private fun ShapeContent(pen: PenState, update: ((PenState) -> PenState) -> Unit) {
    Text("Shape", style = MaterialTheme.typography.titleMedium)
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        ShapeKind.entries.forEach { k ->
            FilterChip(pen.shape == k, { update { it.copy(shape = k) } }, { Text(k.label) })
        }
    }
    SizeRow(pen.active.size) { v -> update { it.withSize(v) } }
    Text("Drag on the page to draw the shape with the current pen", style = MaterialTheme.typography.labelSmall, modifier = Modifier.alpha(0.6f))
}

// =============================================================== colour picker (HSV)
@Composable
fun ColorPickerDialog(initial: Int, onDismiss: () -> Unit, onPick: (Int) -> Unit) {
    val hsv = remember { FloatArray(3).also { android.graphics.Color.colorToHSV(initial, it) } }
    var h by remember { mutableFloatStateOf(hsv[0]) }
    var s by remember { mutableFloatStateOf(hsv[1]) }
    var v by remember { mutableFloatStateOf(hsv[2]) }
    val argb = android.graphics.Color.HSVToColor(floatArrayOf(h, s, v))
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Custom colour") },
        text = {
            Column {
                Box(Modifier.fillMaxWidth().height(48.dp).clip(RoundedCornerShape(12.dp)).background(Color(argb)))
                Text("Hue"); Slider(h, { h = it }, valueRange = 0f..360f)
                Text("Saturation"); Slider(s, { s = it })
                Text("Brightness"); Slider(v, { v = it })
            }
        },
        confirmButton = { TextButton({ onPick(argb) }) { Text("Select") } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } }
    )
}

// =============================================================== pen illustrations (like the Samsung panel)
private fun shade(c: Color, f: Float) =
    Color((c.red * f).coerceIn(0f, 1f), (c.green * f).coerceIn(0f, 1f), (c.blue * f).coerceIn(0f, 1f), c.alpha)

@Composable
private fun PenIllustration(type: PenType, color: Color, selected: Boolean, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val top = size.height * 0.24f
        val ph = size.height - top
        fun y(f: Float) = top + ph * f
        val cx = w / 2f
        val bw = w * 0.5f
        val bl = cx - bw / 2f
        val hair = 1.2f.dp.toPx()
        val dark = Color(0xFF3A3A40)
        val metal = Brush.horizontalGradient(listOf(Color(0xFFB4B7C2), Color(0xFFF8F9FC), Color(0xFFC2C5CF)), startX = bl, endX = bl + bw)
        val bodyBrush = Brush.horizontalGradient(listOf(shade(color, 0.78f), shade(color, 1.1f), shade(color, 0.84f)), startX = bl, endX = bl + bw)
        val bandBrush = Brush.horizontalGradient(listOf(Color(0xFFE4E5EB), Color.White, Color(0xFFD6D8E0)), startX = bl, endX = bl + bw)

        if (selected) {
            val wave = Path().apply {
                moveTo(w * 0.12f, top * 0.75f)
                cubicTo(w * 0.30f, top * 0.05f, w * 0.45f, top * 0.95f, w * 0.65f, top * 0.40f)
                cubicTo(w * 0.75f, top * 0.15f, w * 0.88f, top * 0.45f, w * 0.92f, top * 0.30f)
            }
            drawPath(wave, color, style = Stroke(width = 5.dp.toPx(), cap = StrokeCap.Round))
        }
        // soft contact shadow
        drawOval(Color.Black.copy(alpha = 0.07f), Offset(bl - 4f, size.height - 8.dp.toPx()), Size(bw + 8f, 8.dp.toPx()))

        // grip, ferrule band, glossy streak
        drawRoundRect(bodyBrush, Offset(bl, y(0.46f)), Size(bw, ph * 0.60f), CornerRadius(bw * 0.3f))
        drawRect(bandBrush, Offset(bl, y(0.70f)), Size(bw, ph * 0.075f))
        drawRoundRect(Color.White.copy(alpha = 0.28f), Offset(bl + bw * 0.16f, y(0.50f)), Size(bw * 0.13f, ph * 0.17f), CornerRadius(bw * 0.06f))

        when (type) {
            PenType.FOUNTAIN, PenType.CALLIGRAPHY -> {
                val peak = if (type == PenType.CALLIGRAPHY) cx + bw * 0.22f else cx
                val nib = Path().apply {
                    moveTo(bl + bw * 0.08f, y(0.44f)); lineTo(peak, y(0.04f)); lineTo(bl + bw * 0.92f, y(0.44f)); close()
                }
                drawPath(nib, metal)
                drawPath(nib, dark.copy(alpha = 0.45f), style = Stroke(hair))
                drawLine(dark, Offset(peak, y(0.22f)), Offset(cx, y(0.44f)), strokeWidth = hair)
                drawCircle(dark, bw * 0.045f, Offset(peak, y(0.22f)))
                drawRect(Color(0xFF2C2C31), Offset(bl, y(0.435f)), Size(bw, ph * 0.04f))
            }
            PenType.BALLPOINT -> {
                val cone = Path().apply {
                    moveTo(bl + bw * 0.1f, y(0.46f)); lineTo(cx - bw * 0.1f, y(0.10f))
                    lineTo(cx + bw * 0.1f, y(0.10f)); lineTo(bl + bw * 0.9f, y(0.46f)); close()
                }
                drawPath(cone, metal)
                drawPath(cone, dark.copy(alpha = 0.35f), style = Stroke(hair))
                drawCircle(shade(color, 0.7f), bw * 0.08f, Offset(cx, y(0.085f)))
            }
            PenType.PENCIL -> {
                val wood = Path().apply {
                    moveTo(bl + bw * 0.04f, y(0.46f)); lineTo(cx, y(0.12f)); lineTo(bl + bw * 0.96f, y(0.46f)); close()
                }
                drawPath(wood, Brush.horizontalGradient(listOf(Color(0xFFE2BC8A), Color(0xFFF5DDB8), Color(0xFFE6C493)), startX = bl, endX = bl + bw))
                val lead = Path().apply {
                    moveTo(cx - bw * 0.14f, y(0.26f)); lineTo(cx, y(0.10f)); lineTo(cx + bw * 0.14f, y(0.26f)); close()
                }
                drawPath(lead, shade(color, 0.85f))
            }
            PenType.WATERCOLOR, PenType.BRUSH -> {
                drawRect(metal, Offset(bl, y(0.36f)), Size(bw, y(0.46f) - y(0.36f)))
                val bristle = Path().apply {
                    moveTo(bl + bw * 0.06f, y(0.36f))
                    if (type == PenType.WATERCOLOR) quadraticBezierTo(cx, y(-0.02f), bl + bw * 0.94f, y(0.36f))
                    else cubicTo(bl, y(0.08f), bl + bw, y(0.08f), bl + bw * 0.94f, y(0.36f))
                    close()
                }
                val tipBrush = if (type == PenType.WATERCOLOR)
                    Brush.verticalGradient(listOf(Color.White, color), startY = y(0.04f), endY = y(0.36f))
                else Brush.verticalGradient(listOf(shade(color, 1.1f), shade(color, 0.85f)), startY = y(0.08f), endY = y(0.36f))
                drawPath(bristle, tipBrush)
            }
            PenType.HIGHLIGHTER, PenType.HIGHLIGHTER_ROUND, PenType.TAPE -> {
                val tip = Path().apply {
                    moveTo(bl + bw * 0.04f, y(0.46f)); lineTo(bl + bw * 0.22f, y(0.12f))
                    lineTo(bl + bw * 0.78f, y(0.12f)); lineTo(bl + bw * 0.96f, y(0.46f)); close()
                }
                drawPath(tip, Brush.horizontalGradient(listOf(shade(color, 0.9f), shade(color, 1.1f), shade(color, 0.9f)), startX = bl, endX = bl + bw))
                if (type == PenType.HIGHLIGHTER_ROUND) drawCircle(color, bw * 0.28f, Offset(cx, y(0.12f)))
            }
        }
    }
}
