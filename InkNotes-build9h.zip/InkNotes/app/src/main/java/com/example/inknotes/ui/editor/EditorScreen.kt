package com.example.inknotes.ui.editor

import android.content.Intent
import android.widget.Toast
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Settings
import com.example.inknotes.domain.model.LineStyle
import com.example.inknotes.ink.StrokeRenderer
import kotlin.math.abs
import androidx.compose.ui.platform.LocalConfiguration
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import android.graphics.RectF
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Label
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Scanner
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.IntSize
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlin.math.roundToInt
import com.example.inknotes.domain.model.BlockKind
import com.example.inknotes.domain.model.PageTemplate
import com.example.inknotes.domain.model.PenType
import com.example.inknotes.domain.model.TextBlock
import com.example.inknotes.domain.model.Tool
import com.example.inknotes.ink.HandwritingRecognizer
import com.example.inknotes.ink.InkSurfaceView
import com.example.inknotes.ink.PenSample
import com.example.inknotes.ink.PAGE_W
import com.example.inknotes.ink.PenSpecs
import com.example.inknotes.ink.TemplateRenderer

private data class Viewport(val scale: Float = 1f, val tx: Float = 0f, val ty: Float = 0f)

private sealed interface Recog {
    data object Loading : Recog
    data class Done(val text: String, val lang: String) : Recog
    data class Error(val msg: String) : Recog
}

private const val SELECTION_IN_TOPBAR = false     // the selection actions are a floating toolbar now

private enum class PickerTarget { PEN, SELECTION, LASER, STYLE }

@OptIn(ExperimentalMaterial3Api::class, FlowPreview::class)
@Composable
fun EditorScreen(onBack: () -> Unit, vm: EditorViewModel = hiltViewModel()) {
    val strokes by vm.strokes.collectAsStateWithLifecycle()
    val pen by vm.pen.collectAsStateWithLifecycle()
    val history by vm.history.collectAsStateWithLifecycle()
    val template by vm.template.collectAsStateWithLifecycle()
    val title by vm.title.collectAsStateWithLifecycle()
    val mode by vm.mode.collectAsStateWithLifecycle()
    val blocks by vm.blocks.collectAsStateWithLifecycle()
    val focusedId by vm.focusedId.collectAsStateWithLifecycle()
    val pendingFocus by vm.pendingFocus.collectAsStateWithLifecycle()
    val images by vm.images.collectAsStateWithLifecycle()
    val selectedImage by vm.selectedImage.collectAsStateWithLifecycle()
    val pdfName by vm.pdfName.collectAsStateWithLifecycle()
    val paperColor by vm.paperColor.collectAsStateWithLifecycle()
    val locked by vm.locked.collectAsStateWithLifecycle()
    val favorite by vm.favorite.collectAsStateWithLifecycle()
    val noteCover by vm.cover.collectAsStateWithLifecycle()
    val objects by vm.objects.collectAsStateWithLifecycle()
    val selectedObject by vm.selectedObject.collectAsStateWithLifecycle()
    val hasPageClip by vm.hasPageClip.collectAsStateWithLifecycle()
    val folders by vm.folders.collectAsStateWithLifecycle()

    val ctx = LocalContext.current
    val dark = isSystemInDarkTheme()
    val white = 0xFFFFFFFF.toInt()
    val paper = if (paperColor == white) (if (dark) 0xFF2B2B2B.toInt() else 0xFFFCFCFC.toInt()) else paperColor
    val paperIsLight = Color(paper).luminance() > 0.5f
    val lineInk = if (paperIsLight) Color.Black.toArgb() else Color.White.toArgb()
    val desk = if (dark) 0xFF111113.toInt() else 0xFFE8E8EC.toInt()
    val pageWidthDp = with(LocalDensity.current) { PAGE_W.toDp() }

    var viewport by remember { mutableStateOf(Viewport()) }
    var boxSize by remember { mutableStateOf(IntSize.Zero) }
    var templateMenu by remember { mutableStateOf(false) }
    var moreMenu by remember { mutableStateOf(false) }
    var panel by remember { mutableStateOf<PanelKind?>(null) }
    val toolAnchors = remember { HashMap<String, Rect>() }            // tool buttons in SCREEN pixels (read when a panel opens)
    val hostView = LocalView.current
    val uiPrefs = remember { ctx.getSharedPreferences("inknotes_ui", android.content.Context.MODE_PRIVATE) }
    var dock by remember {
        mutableStateOf(runCatching { ToolbarDock.valueOf(uiPrefs.getString("dock", "BOTTOM") ?: "BOTTOM") }.getOrDefault(ToolbarDock.BOTTOM))
    }
    var editorRect by remember { mutableStateOf<Rect?>(null) }

    // pages, tags, voice, writing pad, change style, handwriting help, customisable toolbar
    val pages by vm.pages.collectAsStateWithLifecycle()
    val currentPageId by vm.currentPageId.collectAsStateWithLifecycle()
    val thumbVersion by vm.thumbVersion.collectAsStateWithLifecycle()
    val allTags by vm.tags.collectAsStateWithLifecycle()
    val noteTagIds by vm.noteTagIds.collectAsStateWithLifecycle()
    var showPages by remember { mutableStateOf(false) }
    var pagePanelOpen by remember { mutableStateOf(false) }
    var showTags by remember { mutableStateOf(false) }
    var showVoice by remember { mutableStateOf(false) }
    var showPad by remember { mutableStateOf(false) }
    var padOpen by remember { mutableStateOf(false) }                    // Easy writing pad
    var padFrame by remember { mutableStateOf(PadFrame(40f, 140f, 640f)) }
    var padAspect by remember { mutableFloatStateOf(0.3f) }              // pad height / width = shape of the frame on the page
    var padLive by remember { mutableStateOf<List<com.example.inknotes.domain.model.StrokePoint>>(emptyList()) }   // pen strokes in the pad, shown on the page at once
    var padGhost by remember { mutableStateOf<com.example.inknotes.domain.model.Stroke?>(null) }
    var selBounds by remember { mutableStateOf<android.graphics.RectF?>(null) }             // selection box for the floating toolbar
    var clipboard by remember { mutableStateOf<List<com.example.inknotes.domain.model.Stroke>>(emptyList()) }
    var showStyle by remember { mutableStateOf(false) }
    var showCustomize by remember { mutableStateOf(false) }
    var helpState by remember { mutableStateOf<HelpState?>(null) }
    var padOffset by remember { mutableFloatStateOf(0f) }
    val toolItems = resolveToolbar(pen.toolbar)
    val voice = remember { VoiceController(ctx, vm.id) }
    DisposableEffect(Unit) { onDispose { voice.release() } }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) voice.start()
    }
    val micGranted = ctx.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED
    var picker by remember { mutableStateOf<PickerTarget?>(null) }
    var plusMenu by remember { mutableStateOf(false) }
    var fullscreen by remember { mutableStateOf(false) }
    var styleDialog by remember { mutableStateOf(false) }
    var bgDialog by remember { mutableStateOf(false) }
    var trashDialog by remember { mutableStateOf(false) }
    var tableDialog by remember { mutableStateOf(false) }
    var drawingPad by remember { mutableStateOf(false) }
    var searchDialog by remember { mutableStateOf(false) }
    var editObj by remember { mutableStateOf<Pair<String, Int>?>(null) }      // (object id, table cell index or -1)
    var tapeToastReady by remember { mutableStateOf(false) }
    var folderDialog by remember { mutableStateOf(false) }
    var exportDialog by remember { mutableStateOf(false) }
    var exporting by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val pdfPaint = remember { android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG) }
    val whitePaint = remember { android.graphics.Paint().apply { color = android.graphics.Color.WHITE } }

    // imported PDF: pages are rendered lazily around the viewport
    val pdf = remember(pdfName) { pdfName?.let { n -> runCatching { PdfPages(vm.pdfFile(n)) }.getOrNull() } }
    DisposableEffect(pdf) { onDispose { pdf?.close() } }
    DisposableEffect(Unit) { onDispose { vm.saveThumbnail() } }     // refresh the home-screen preview
    var sample by remember { mutableStateOf<PenSample?>(null) }
    var hasSelection by remember { mutableStateOf(false) }
    var inkView by remember { mutableStateOf<InkSurfaceView?>(null) }
    var recog by remember { mutableStateOf<Recog?>(null) }
    var langDialog by remember { mutableStateOf(false) }
    val recognizer = remember { HandwritingRecognizer() }
    LaunchedEffect(currentPageId) { inkView?.scrollToTop() }      // a new page opens at its top
    val onSample: (PenSample) -> Unit = { sample = it }
    val focusedBlock = blocks.firstOrNull { it.id == focusedId } ?: blocks.last()

    LaunchedEffect(pdf) {
        if (pdf == null) return@LaunchedEffect
        pdf.loadLayout(PAGE_W)
        snapshotFlow {
            val vp = viewport
            val ch = pdf.contentHeight
            val h = boxSize.height
            if (ch <= 0f || h == 0) null
            else {
                val r = pdf.visibleRange(-vp.ty / vp.scale, (h - vp.ty) / vp.scale)
                val isHd = PAGE_W * vp.scale > 1500f
                if (r != null) Triple(r.first, r.last, isHd) else null
            }
        }
        .distinctUntilChanged()
        .collectLatest { req ->
            if (req != null) {
                pdf.request(req.first, req.second, req.third)
            }
        }
    }

    fun export(kind: String) {
        exportDialog = false
        exporting = true
        val input = Exporter.Input(
            strokes, blocks, images, vm::imageFile, template, paper, lineInk,
            ctx.resources.displayMetrics.density, pdf
        )
        val safe = title.ifBlank { "note" }.replace(Regex("[^A-Za-z0-9_-]+"), "_").take(40)
        scope.launch {
            val file = withContext(Dispatchers.Default) {
                runCatching { if (kind == "pdf") Exporter.pdf(ctx, safe, input) else Exporter.png(ctx, safe, input) }.getOrNull()
            }
            exporting = false
            if (file == null) {
                Toast.makeText(ctx, "Export failed", Toast.LENGTH_LONG).show()
            } else {
                val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", file)
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = if (kind == "pdf") "application/pdf" else "image/png"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                ctx.startActivity(Intent.createChooser(send, "Share note"))
            }
        }
    }

    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            val vp = viewport
            vm.addImage(uri, (boxSize.width / 2f - vp.tx) / vp.scale, (boxSize.height / 2f - vp.ty) / vp.scale)
        }
    }
    fun pickPhoto() = photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))

    fun toast(msg: String) = android.widget.Toast.makeText(ctx, msg, android.widget.Toast.LENGTH_SHORT).show()

    // Insert (+) menu: PDF, Audio file, Camera / Scan
    val pdfPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.attachPdf(uri) { ok -> if (!ok) toast("Could not open this PDF") }
    }
    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importAudio(uri) { ok ->
            voice.reload()
            toast(if (ok) "Audio added to this note" else "Could not add this audio")
        }
    }
    var cameraUri by remember { mutableStateOf<android.net.Uri?>(null) }
    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val u = cameraUri
        if (ok && u != null) {
            val vp = viewport
            vm.setMode(EditorMode.IMAGE)
            vm.addImage(u, (boxSize.width / 2f - vp.tx) / vp.scale, (boxSize.height / 2f - vp.ty) / vp.scale)
        }
    }
    fun openCamera() {
        runCatching {
            val dir = java.io.File(ctx.cacheDir, "camera").apply { mkdirs() }
            val f = java.io.File(dir, "shot_" + System.currentTimeMillis() + ".jpg")
            val u = androidx.core.content.FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
            cameraUri = u
            cameraLauncher.launch(u)
        }.onFailure { toast("No camera app found") }
    }
    fun shareText() {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, title.ifBlank { "Note" })
            putExtra(Intent.EXTRA_TEXT, vm.plainText())
        }
        ctx.startActivity(Intent.createChooser(send, "Share note"))
    }

    fun viewCenter(): Pair<Float, Float> {
        val vp = viewport
        return ((boxSize.width / 2f - vp.tx) / vp.scale) to ((boxSize.height / 2f - vp.ty) / vp.scale)
    }

    // Finger on a sticky note / table: tap = select, drag a selected one = move, corner = resize, tap a selected one = edit text.
    // (The pen never comes here, so it can write on top of them.)
    val od = remember { ObjectDrag() }
    val objectTouch: (Int, Float, Float, Float) -> Boolean = touch@{ action, px, py, sc ->
        when (action) {
            android.view.MotionEvent.ACTION_DOWN -> {
                val sel = objects.firstOrNull { it.id == selectedObject }
                val near = 36f / sc + 18f
                if (sel != null && !sel.isText && kotlin.math.abs(px - (sel.x + sel.w)) < near && kotlin.math.abs(py - (sel.y + sel.h)) < near) {
                    od.mode = 2
                    od.id = sel.id
                } else {
                    val hit = objects.lastOrNull { !it.isText && px >= it.x && px <= it.x + it.w && py >= it.y && py <= it.y + it.h }
                    if (hit == null) {
                        if (selectedObject != null) vm.selectObject(null)
                        return@touch false
                    }
                    od.mode = if (hit.id == selectedObject) 1 else 0
                    od.id = hit.id
                    if (hit.id != selectedObject) vm.selectObject(hit.id)
                }
                od.sx = px; od.sy = py; od.lx = px; od.ly = py; od.dist = 0f; od.moved = false
                true
            }
            android.view.MotionEvent.ACTION_MOVE -> {
                val dx = px - od.lx
                val dy = py - od.ly
                od.dist += kotlin.math.abs(dx) + kotlin.math.abs(dy)
                if (od.mode == 1) {
                    if (od.moved) vm.moveObject(od.id, dx, dy)
                    else if (od.dist > 14f / sc) { od.moved = true; vm.moveObject(od.id, px - od.sx, py - od.sy) }
                } else if (od.mode == 2) vm.resizeObject(od.id, dx, dy)
                od.lx = px
                od.ly = py
                true
            }
            android.view.MotionEvent.ACTION_UP -> {
                if (od.mode == 1 && !od.moved) {
                    objects.firstOrNull { it.id == od.id }?.let { o -> editObj = o.id to cellAt(o, px, py) }
                }
                od.mode = -1
                true
            }
            else -> {
                od.mode = -1
                true
            }
        }
    }

    // Maths solver: when a finished sum ("12+3x4=") has been written, its answer is added in blue next to it.
    LaunchedEffect(strokes.lastOrNull()?.id, pen.mathsSolver) {
        if (!pen.mathsSolver) return@LaunchedEffect
        val last = strokes.lastOrNull() ?: return@LaunchedEffect
        delay(900)
        val lb = MathSolver.bounds(last)
        val half = maxOf(lb.height(), 70f)
        val cy = (lb.top + lb.bottom) / 2f
        val line = strokes.filter { st ->
            val b = MathSolver.bounds(st)
            val c = (b.top + b.bottom) / 2f
            c > cy - half && c < cy + half && b.left <= lb.right + 40f
        }.sortedBy { MathSolver.bounds(it).left }
        if (line.size < 3) return@LaunchedEffect
        val right = line.maxOf { MathSolver.bounds(it).right }
        val top = line.minOf { MathSolver.bounds(it).top }
        val bottom = line.maxOf { MathSolver.bounds(it).bottom }
        recognizer.recognize(line, "en-US") { r ->
            r.getOrNull()?.let { t -> MathSolver.solve(t)?.let { vm.addMathResult(right + 36f, top, bottom - top, it) } }
        }
    }

    LaunchedEffect(pen.tapeHidden) {
        if (tapeToastReady) toast(if (pen.tapeHidden) "Tape hidden." else "Tape shown.")
        tapeToastReady = true
    }

    fun recognize(lang: String) {
        val s = inkView?.selectedStrokes().orEmpty()
        if (s.isEmpty()) return
        recog = Recog.Loading
        recognizer.recognize(s, lang) { r ->
            recog = r.fold({ Recog.Done(it, lang) }, { Recog.Error(it.message ?: "Recognition failed") })
        }
    }

    fun help(lang: String) {
        val s = inkView?.selectedStrokes().orEmpty()
        if (s.isEmpty()) return
        helpState = HelpState.Loading
        recognizer.recognizeAll(s, lang) { r ->
            helpState = r.fold({ HelpState.Done(it) }, { HelpState.Error(it.message ?: "Recognition failed") })
        }
    }

    val drawToolbar: @Composable () -> Unit = {
        DrawToolbar(
            pen = pen, history = history, dock = dock,
            items = toolItems, recording = voice.isRecording,
            onStyle = { panel = PanelKind.STYLE },
            onHelp = { panel = PanelKind.HELP },
            onPad = {
                if (!padOpen) {
                    val vp = viewport
                    padFrame = PadFrame(40f, (-vp.ty / vp.scale) + 100f, 640f)
                }
                padOpen = !padOpen
            },
            onCustomize = { showCustomize = true },
            onVoice = { showVoice = true },
            onDockTo = { x, y ->
                val r = editorRect
                if (r != null && r.width > 0f && r.height > 0f) {
                    val dl = x - r.left; val dr = r.right - x; val dt = y - r.top; val db = r.bottom - y
                    val m = minOf(minOf(dl, dr), minOf(dt, db))
                    val target = when (m) {
                        dl -> ToolbarDock.LEFT
                        dr -> ToolbarDock.RIGHT
                        dt -> ToolbarDock.TOP
                        else -> ToolbarDock.BOTTOM
                    }
                    if (target != dock) {
                        dock = target
                        uiPrefs.edit().putString("dock", target.name).apply()
                    }
                }
            },
            hasSelection = hasSelection,
            onConvert = { recognize("en-US") },
            onAlign = { inkView?.alignSelection() },
            onAnchor = { t, r ->
                val loc = IntArray(2)
                hostView.getLocationOnScreen(loc)
                toolAnchors[t] = r.translate(loc[0].toFloat(), loc[1].toFloat())
            },
            onLockCanvas = {
                if (!pen.lockCanvas) toast("Canvas locked. Swipe with two fingers to scroll.")
                vm.updatePen { it.copy(lockCanvas = !it.lockCanvas) }
            },
            onToolTap = { t ->
                if (pen.tool == t) {
                    panel = when (t) {
                        Tool.PEN -> PanelKind.PEN
                        Tool.HIGHLIGHTER -> PanelKind.HIGHLIGHTER
                        Tool.ERASER -> PanelKind.ERASER
                        Tool.SELECT -> PanelKind.SELECT
                        Tool.SHAPE -> PanelKind.SHAPE
                        Tool.TAPE -> PanelKind.TAPE
                        Tool.LASER -> PanelKind.LASER
                    }
                } else vm.updatePen { it.copy(tool = t) }
            },
            onText = { vm.setMode(EditorMode.TEXT) },
            onPhoto = { vm.setMode(EditorMode.IMAGE); pickPhoto() },
            onFavorite = { f -> vm.updatePen { it.applyFavorite(f) } },
            onColor = { c -> vm.updatePen { it.withColor(c) } },
            onThickness = {
                panel = when (pen.tool) {
                    Tool.HIGHLIGHTER -> PanelKind.HIGHLIGHTER
                    Tool.ERASER -> PanelKind.ERASER
                    Tool.TAPE -> PanelKind.TAPE
                    else -> PanelKind.PEN
                }
            },
            onUndo = vm::undo, onRedo = vm::redo
        
        )
    }

    Scaffold(
        topBar = {
            if (!fullscreen && !pen.readingMode) TopAppBar(
                title = {
                    TextField(
                        value = title, onValueChange = vm::setTitle, singleLine = true,
                        placeholder = { Text("Title", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.outline) },
                        textStyle = MaterialTheme.typography.titleLarge,
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent
                        )
                    )
                },
                navigationIcon = { IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                actions = {
                    if (SELECTION_IN_TOPBAR && hasSelection) {
                        IconButton({ inkView?.duplicateSelection() }) { Icon(Icons.Default.ContentCopy, "Duplicate") }
                        IconButton({ picker = PickerTarget.SELECTION }) { Icon(Icons.Default.Palette, "Colour") }
                        IconButton({ inkView?.deleteSelection() }) { Icon(Icons.Default.Delete, "Delete") }
                        IconButton({ inkView?.commitSelection() }) { Icon(Icons.Default.Check, "Done") }
                    } else {
                        IconButton({ if (!pagePanelOpen) vm.refreshPageThumbs(); pagePanelOpen = !pagePanelOpen }) { Icon(Icons.Default.MenuBook, "Pages") }
                        Box {
                            IconButton({ plusMenu = true }) { Icon(Icons.Default.Add, "Add") }
                            DropdownMenu(plusMenu, { plusMenu = false }) {
                                DropdownMenuItem(
                                    text = { Text("PDF") }, leadingIcon = { Icon(Icons.Default.PictureAsPdf, null) },
                                    onClick = { plusMenu = false; pdfPicker.launch(arrayOf("application/pdf")) }
                                )
                                DropdownMenuItem(
                                    text = { Text("Voice recording") }, leadingIcon = { Icon(Icons.Default.Mic, null) },
                                    onClick = { plusMenu = false; showVoice = true }
                                )
                                DropdownMenuItem(
                                    text = { Text("Image") }, leadingIcon = { Icon(Icons.Default.Image, null) },
                                    onClick = { plusMenu = false; vm.setMode(EditorMode.IMAGE); pickPhoto() }
                                )
                                DropdownMenuItem(
                                    text = { Text("Camera") }, leadingIcon = { Icon(Icons.Default.PhotoCamera, null) },
                                    onClick = { plusMenu = false; openCamera() }
                                )
                                DropdownMenuItem(
                                    text = { Text("Scan") }, leadingIcon = { Icon(Icons.Default.Scanner, null) },
                                    onClick = { plusMenu = false; openCamera() }
                                )
                                DropdownMenuItem(
                                    text = { Text("Audio file") }, leadingIcon = { Icon(Icons.Default.MusicNote, null) },
                                    onClick = { plusMenu = false; audioPicker.launch(arrayOf("audio/*")) }
                                )
                                DropdownMenuItem(
                                    text = { Text("Drawing") }, leadingIcon = { Icon(Icons.Default.Brush, null) },
                                    onClick = { plusMenu = false; drawingPad = true }
                                )
                                DropdownMenuItem(
                                    text = { Text("Sticky note") }, leadingIcon = { Icon(Icons.Default.Description, null) },
                                    onClick = { plusMenu = false; val (cx, cy) = viewCenter(); vm.setMode(EditorMode.DRAW); vm.addSticky(cx, cy) }
                                )
                                DropdownMenuItem(
                                    text = { Text("Table") }, leadingIcon = { Icon(Icons.Default.GridOn, null) },
                                    onClick = { plusMenu = false; tableDialog = true }
                                )
                            }
                        }
                        IconButton({ vm.updatePen { it.copy(readingMode = !it.readingMode) }; vm.setMode(EditorMode.DRAW) }) {
                            Icon(Icons.Default.Description, "Reading mode")
                        }
                        IconButton({ fullscreen = true }) { Icon(Icons.Default.Fullscreen, "Full screen") }
                        Box {
                            IconButton({ moreMenu = true }) { Icon(Icons.Default.MoreVert, "More") }
                            DropdownMenu(moreMenu, { moreMenu = false }) {
                                DropdownMenuItem(text = { Text("Search") }, onClick = { moreMenu = false; searchDialog = true })
                                DropdownMenuItem(text = { Text("Note style") }, onClick = { moreMenu = false; styleDialog = true })
                                DropdownMenuItem(text = { Text("Page settings") }, onClick = { moreMenu = false; bgDialog = true })
                                androidx.compose.material3.HorizontalDivider()
                                DropdownMenuItem(text = { Text("Add note to") }, trailingIcon = { Text("\u203A") }, onClick = { moreMenu = false; folderDialog = true })
                                DropdownMenuItem(text = { Text("Add tags") }, onClick = { moreMenu = false; showTags = true })
                                DropdownMenuItem(text = { Text("Save as") }, onClick = { moreMenu = false; exportDialog = true })
                                DropdownMenuItem(
                                    text = { Text(if (pen.fingerDrawing) "Turn off finger drawing" else "Turn on finger drawing") },
                                    onClick = { vm.updatePen { it.copy(fingerDrawing = !it.fingerDrawing) }; moreMenu = false }
                                )
                                DropdownMenuItem(
                                    text = { Text(if (pen.mathsSolver) "Turn off Maths solver" else "Turn on Maths solver") },
                                    onClick = {
                                        moreMenu = false
                                        val on = !pen.mathsSolver
                                        vm.updatePen {
                                            it.copy(
                                                mathsSolver = on,
                                                helpGuideline = if (on) false else it.helpGuideline,
                                                helpAlign = if (on) false else it.helpAlign,
                                                helpFix = if (on) false else it.helpFix
                                            )
                                        }
                                        if (on) toast("All handwriting help features turned off to turn on Maths solver.")
                                    }
                                )
                                androidx.compose.material3.HorizontalDivider()
                                Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                    IconButton({ vm.toggleFavoriteNote() }) { Icon(if (favorite) Icons.Default.Star else Icons.Default.StarBorder, "Favourite") }
                                    IconButton({ vm.toggleLocked() }) { Icon(if (locked) Icons.Default.Lock else Icons.Default.LockOpen, "Lock") }
                                    IconButton({ moreMenu = false; shareText() }) { Icon(Icons.Default.Share, "Share") }
                                    IconButton({ moreMenu = false; exportDialog = true }) { Icon(Icons.Default.Print, "Print") }
                                    IconButton({ moreMenu = false; trashDialog = true }) { Icon(Icons.Default.Delete, "Delete") }
                                }
                            }
                        }
                    }
                }
            )
        },
        bottomBar = {
            when {
                pen.readingMode -> Unit
                mode == EditorMode.DRAW -> { if (dock == ToolbarDock.BOTTOM) drawToolbar() }
                mode == EditorMode.TEXT -> TextToolbar(focusedBlock, vm::format) { vm.setMode(EditorMode.DRAW) }
                else -> ImageToolbar(
                    onDone = { vm.setMode(EditorMode.DRAW); vm.selectImage(null) },
                    onAdd = { pickPhoto() },
                    onForward = { vm.moveSelectedImage(true) },
                    onBackward = { vm.moveSelectedImage(false) },
                    onDelete = vm::deleteSelectedImage
                )
            }
        }
    ) { pad ->
      val drawBar = mode == EditorMode.DRAW && !pen.readingMode
      Column(Modifier.padding(pad).fillMaxSize()) {
        if (drawBar && dock == ToolbarDock.TOP) drawToolbar()
        Row(Modifier.weight(1f).fillMaxWidth()) {
        if (pagePanelOpen && !pen.readingMode && !fullscreen) {
            PagePanel(
                pages = pages, currentId = currentPageId, version = thumbVersion, thumbOf = vm::pageFile,
                onOpen = { vm.switchPage(it) },
                onAdd = { vm.addPage(); vm.refreshPageThumbs() },
                onDelete = { ids -> vm.deletePages(ids) },
                onErase = { id -> vm.erasePage(id) },
                onBookmark = { id -> vm.toggleBookmark(id) },
                onSaveAs = { exportDialog = true },
                hasClip = hasPageClip,
                onCopy = { id, cut ->
                    vm.copyPage(id, cut) { ok ->
                        toast(if (!ok) "PDF pages cannot be copied yet" else if (cut) "Page cut. Long-press a page > Paste" else "Page copied. Long-press a page > Paste")
                    }
                },
                onPaste = { vm.pastePage { ok -> if (!ok) toast("Could not paste the page") } },
                onNotBuilt = { m -> toast(m) }
            )
        }
        if (drawBar && dock == ToolbarDock.LEFT) drawToolbar()
        Box(
            Modifier.weight(1f).fillMaxHeight().clipToBounds()
                .onSizeChanged { boxSize = it }
                .onGloballyPositioned { editorRect = it.boundsInWindow() }
        ) {
            val pageRect = remember { RectF() }
            val visRect = remember { RectF() }
            // desk + paper + template, or the PDF pages (follows the ink viewport)
            Canvas(Modifier.fillMaxSize()) {
                val (s, tx, ty) = viewport
                visRect.set(-tx / s, -ty / s, (size.width - tx) / s, (size.height - ty) / s)
                val bitmapVersion = pdf?.version            // read so the canvas redraws when a PDF page arrives
                drawIntoCanvas { c ->
                    val nc = c.nativeCanvas
                    nc.save(); nc.translate(tx, ty); nc.scale(s, s)
                    if (pdf != null && pdf.contentHeight > 0f && bitmapVersion != null) {
                        TemplateRenderer.drawDesk(nc, visRect, desk)
                        val range = pdf.visibleRange(visRect.top, visRect.bottom)
                        if (range != null) for (i in range) {
                            pageRect.set(0f, pdf.tops[i], PAGE_W, pdf.tops[i] + pdf.heights[i])
                            val b = pdf.bitmap(i)
                            if (b != null) nc.drawBitmap(b, null, pageRect, pdfPaint) else nc.drawRect(pageRect, whitePaint)
                        }
                    } else {
                        TemplateRenderer.draw(nc, template, visRect, paper, lineInk, s, desk)
                    }
                    nc.restore()
                }
            }
            // handwriting: low-latency SurfaceView overlay (always drawn above the window)
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { c ->
                    InkSurfaceView(c).apply {
                        editListener = InkSurfaceView.EditListener { vm.onEdit(it) }
                        viewportListener = { s, x, y -> viewport = Viewport(s, x, y) }
                        selectionListener = { hasSelection = it }
                        selectionBoundsListener = { selBounds = it }
                        inkView = this
                    }
                },
                update = { v ->
                    val type = pen.activeType
                    val setting = pen.active
                    v.strokes = strokes
                    v.tool = pen.tool
                    v.pen = type
                    v.penColor = setting.color
                    v.penWidth = PenSpecs.of(type).diameter(setting.size)
                    v.fingerDrawing = pen.fingerDrawing
                    v.straighten = pen.straighten
                    v.holdToShape = true     // always on: hold the pen still to snap a shape
                    v.areaEraser = pen.areaEraser
                    v.eraserSize = pen.eraserSize
                    v.shapeKind = pen.shape
                    v.lineStyle = if (pen.tool == Tool.TAPE) pen.tapePattern else pen.lineStyle
                    val recordingNow = voice.isRecording
                    v.recordingId = if (recordingNow) voice.currentName else null
                    v.recordingStart = voice.startedAt
                    v.contentHeight = pdf?.contentHeight ?: 0f
                    v.eraseHighlighterOnly = pen.eraseHighlighterOnly
                    v.eraseTapeOnly = pen.eraseTapeOnly
                    v.tapeHidden = pen.tapeHidden
                    v.objectTouchListener = if (mode == EditorMode.DRAW && !pen.readingMode) objectTouch else null
                    v.readOnly = pen.readingMode
                    v.lockCanvas = pen.lockCanvas
                    v.selectRect = pen.selectRect
                    v.tapeAdjust = pen.tapeAdjust
                    v.laserStyle = pen.laserStyle
                    v.laserRainbow = pen.laserRainbow
                    v.laserColor = pen.laserColor
                    v.guideline = pen.helpGuideline
                    v.alignLetters = pen.helpAlign
                    v.fixShape = pen.helpFix
                    v.sampleListener = if (pen.showDebug) onSample else null
                },
                onRelease = { it.release() }
            )
            // photos, then text: declared AFTER the ink view so they get the touches first in IMAGE / TEXT mode.
            // In DRAW mode they have no pointer handlers, so touches fall through to the ink view.
            val vpModifier = Modifier.graphicsLayer {
                translationX = viewport.tx; translationY = viewport.ty
                scaleX = viewport.scale; scaleY = viewport.scale
                transformOrigin = TransformOrigin(0f, 0f)
            }
            ImageLayer(
                images = images, selectedId = selectedImage,
                editable = mode == EditorMode.IMAGE && !pen.readingMode,
                fileOf = vm::imageFile, onSelect = vm::selectImage, onTransform = vm::transformImage,
                modifier = vpModifier
            )
            ObjectLayer(objects = objects, selectedId = selectedObject, modifier = vpModifier)
            objects.firstOrNull { it.id == selectedObject }?.takeIf { !it.isText }?.let { o ->
                ObjectMenu(
                    o = o,
                    onColor = { c -> vm.setObjectColor(o.id, c) },
                    onAddRow = { vm.tableAddRow(o.id) },
                    onAddCol = { vm.tableAddCol(o.id) },
                    onStyle = { vm.tableCycleStyle(o.id) },
                    onDelete = { vm.deleteObject(o.id) },
                    modifier = Modifier.offset {
                        val v = viewport
                        IntOffset((o.x * v.scale + v.tx).roundToInt(), (o.y * v.scale + v.ty - 64.dp.toPx()).roundToInt())
                    }
                )
            }
            RichTextLayer(
                blocks = blocks,
                editable = mode == EditorMode.TEXT && !pen.readingMode,
                pendingFocus = pendingFocus,
                textColor = if (paperIsLight) Color.Black else Color.White,
                pageWidth = pageWidthDp,
                onFocus = vm::focusBlock,
                onPendingFocusConsumed = vm::pendingFocusConsumed,
                onChange = vm::changeBlock,
                onSplit = vm::splitBlock,
                onBackspaceEmpty = vm::backspaceEmpty,
                modifier = vpModifier
            )
            if (padOpen) {
                val padType = if (pen.activeType == PenType.TAPE || pen.activeType.isHighlighter) pen.pen else pen.activeType
                val padSetting = pen.settings[padType] ?: PenSetting(PenSpecs.of(padType).defaultColor, PenSpecs.of(padType).defaultSize)
                val previewRenderer = remember { StrokeRenderer(false) }
                Canvas(Modifier.fillMaxSize()) {                 // what is written in the pad shows here at once
                    val vp = viewport
                    drawIntoCanvas { c ->
                        val nc = c.nativeCanvas
                        nc.save(); nc.translate(vp.tx, vp.ty); nc.scale(vp.scale, vp.scale)
                        if (padLive.size >= 2) previewRenderer.drawLive(nc, padType, padSetting.color, PenSpecs.of(padType).diameter(padSetting.size), LineStyle.SOLID, padLive)
                        padGhost?.let { previewRenderer.draw(nc, it) }
                        nc.restore()
                    }
                }
            }
            if (padOpen) {
                val vp = viewport
                val d = LocalDensity.current
                val frameH = padFrame.w * padAspect
                Box(
                    Modifier
                        .offset { IntOffset((padFrame.x * vp.scale + vp.tx).roundToInt(), (padFrame.y * vp.scale + vp.ty).roundToInt()) }
                        .size(with(d) { (padFrame.w * vp.scale).toDp() }, with(d) { (frameH * vp.scale).toDp() })
                        .border(1.5.dp, Color(0xFF2F6FE0))
                        .pointerInput(vp.scale) {
                            detectDragGestures { change, drag ->
                                change.consume()
                                padFrame = padFrame.copy(x = padFrame.x + drag.x / vp.scale, y = padFrame.y + drag.y / vp.scale)
                            }
                        }
                ) {
                    Box(
                        Modifier.align(Alignment.BottomEnd).size(26.dp)
                            .pointerInput(vp.scale) {
                                detectDragGestures { change, drag ->
                                    change.consume()
                                    padFrame = padFrame.copy(w = (padFrame.w + drag.x / vp.scale).coerceIn(240f, PAGE_W - 80f))
                                }
                            }
                    ) {
                        Canvas(Modifier.align(Alignment.BottomEnd).size(10.dp)) {
                            val tri = androidx.compose.ui.graphics.Path().apply {
                                moveTo(size.width, 0f); lineTo(size.width, size.height); lineTo(0f, size.height); close()
                            }
                            drawPath(tri, Color(0xFF2F6FE0))
                        }
                    }
                }
            }
            selBounds?.let { b ->
                SelectionToolbar(
                    bounds = b,
                    onCut = { clipboard = inkView?.copySelectionStrokes().orEmpty(); inkView?.deleteSelection() },
                    onCopy = { clipboard = inkView?.copySelectionStrokes().orEmpty() },
                    onPaste = { inkView?.pasteStrokes(clipboard) },
                    onDelete = { inkView?.deleteSelection() },
                    onStyle = { panel = PanelKind.STYLE },
                    onConvert = { recognize("en-US") },
                    onSelectAll = { inkView?.selectAll() },
                    onDuplicate = { inkView?.duplicateSelection() }
                )
            }
            ViewChips(
                vp = { viewport },
                fit = boxSize.width.toFloat().coerceAtLeast(1f) / PAGE_W,
                pageText = "${(pages.indexOfFirst { it.id == currentPageId } + 1).coerceAtLeast(1)}/${pages.size.coerceAtLeast(1)}",
                onReset = { inkView?.resetZoom() }
            )
            if (pen.readingMode) {
                var readingSettings by remember { mutableStateOf(false) }
                Box(Modifier.align(Alignment.TopEnd).padding(12.dp)) {
                    Surface(shape = RoundedCornerShape(18.dp), color = Color(0xFFF1F1F4), modifier = Modifier.clip(RoundedCornerShape(18.dp)).clickable { readingSettings = true }) {
                        Row(Modifier.padding(horizontal = 12.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Settings, null, Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Settings", fontSize = 12.sp)
                        }
                    }
                    DropdownMenu(readingSettings, { readingSettings = false }) {
                        DropdownMenuItem(text = { Text("Exit reading mode") }, onClick = { readingSettings = false; vm.updatePen { it.copy(readingMode = false) } })
                    }
                }
                Surface(
                    shape = CircleShape, color = Color(0xFFF1F1F4),
                    modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 16.dp).size(40.dp).clip(CircleShape)
                        .clickable { vm.updatePen { it.copy(readingMode = false) } }
                ) { Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.Close, "Exit reading mode", Modifier.size(20.dp)) } }
            }
            if (pen.showDebug) DebugHud(sample, Modifier.align(Alignment.TopStart))
            if (fullscreen) {
                IconButton({ fullscreen = false }, Modifier.align(Alignment.TopEnd).padding(8.dp)) {
                    Icon(Icons.Default.FullscreenExit, "Exit full screen")
                }
            }
        }
        if (drawBar && dock == ToolbarDock.RIGHT) drawToolbar()
        }
        if (padOpen && drawBar) {
            val padType = if (pen.activeType == PenType.TAPE || pen.activeType.isHighlighter) pen.pen else pen.activeType
            val padSetting = pen.settings[padType] ?: PenSetting(PenSpecs.of(padType).defaultColor, PenSpecs.of(padType).defaultSize)
            val padFrameH = padFrame.w * padAspect
            LaunchedEffect(padGhost) { if (padGhost != null) { delay(700); padGhost = null } }
            LaunchedEffect(padFrame.x, padFrame.y, padFrame.w, padAspect) { inkView?.showPageRect(padFrame.y, padFrame.y + padFrameH) }
            EasyWritingPad(
                frame = padFrame, strokes = strokes, paperColor = paper,
                penType = padType, penColor = padSetting.color, penWidth = PenSpecs.of(padType).diameter(padSetting.size),
                pageWidth = PAGE_W,
                areaHeight = (LocalConfiguration.current.screenHeightDp * 0.17f).coerceIn(110f, 190f).dp,
                onAspect = { padAspect = it },
                onFrame = { padFrame = it },
                onLive = { padLive = it },
                onStroke = { st -> vm.addStrokes(listOf(st)); padGhost = st },
                onClose = { padOpen = false }
            )
        }
      }
    }

    if (showPages) {
        PagesDialog(
            pages = pages, currentId = currentPageId, version = thumbVersion, thumbOf = vm::pageFile,
            onOpen = { vm.switchPage(it); showPages = false },
            onAdd = { vm.addPage(); showPages = false },
            onMove = vm::movePage, onDelete = vm::deletePage,
            onDismiss = { showPages = false }
        )
    }

    if (showTags) {
        TagsDialog(
            tags = allTags, selected = noteTagIds.toSet(),
            onToggle = vm::toggleTag, onCreate = vm::createTag,
            onDismiss = { showTags = false }
        )
    }

    if (showVoice) {
        VoiceDialog(
            controller = voice, hasPermission = micGranted,
            onNeedPermission = { micLauncher.launch(android.Manifest.permission.RECORD_AUDIO) },
            onDismiss = { showVoice = false }
        )
    }

    if (showPad) {
        WritingPadDialog(
            onInsert = { raw, _, padH ->
                val vp = viewport
                val k = 0.5f / vp.scale                    // written big in the pad, lands at normal size on the page
                val type = if (pen.activeType == PenType.TAPE || pen.activeType.isHighlighter) pen.pen else pen.activeType
                val setting = pen.settings[type] ?: PenSetting(PenSpecs.of(type).defaultColor, PenSpecs.of(type).defaultSize)
                val left = maxOf(40f, -vp.tx / vp.scale + 40f)
                val top = (-vp.ty + boxSize.height * 0.3f) / vp.scale + padOffset
                val made = raw.map { pts ->
                    com.example.inknotes.domain.model.Stroke(
                        java.util.UUID.randomUUID().toString(), type, setting.color, PenSpecs.of(type).diameter(setting.size),
                        pts.mapIndexed { i, o ->
                            com.example.inknotes.domain.model.StrokePoint(left + o.x * k, top + o.y * k, 0.5f, 0f, 0f, i * 8L)
                        }
                    )
                }
                vm.addStrokes(made)
                padOffset += padH * k + 30f
            },
            onDismiss = { showPad = false }
        )
    }

    helpState?.let { st ->
        HandwritingHelpDialog(
            state = st,
            onPick = { vm.appendText(it); helpState = null },
            onDismiss = { helpState = null }
        )
    }

    if (showCustomize) {
        ToolbarCustomizeDialog(
            current = toolItems,
            onChange = { l -> vm.updatePen { it.copy(toolbar = l.map { t -> t.name }) } },
            onReset = { vm.updatePen { it.copy(toolbar = emptyList()) } },
            onDismiss = { showCustomize = false },
            dock = dock,
            onDock = { d ->
                dock = d
                uiPrefs.edit().putString("dock", d.name).apply()
            },
            debug = pen.showDebug,
            onDebug = { vm.updatePen { it.copy(showDebug = !it.showDebug) } }
        )
    }

    if (styleDialog) {
        NoteStylePanel(
            template = template, cover = noteCover,
            onApply = { t, c -> vm.setTemplateAll(t); vm.setCover(c); styleDialog = false },
            onPdf = { styleDialog = false; pdfPicker.launch(arrayOf("application/pdf")) },
            onNotBuilt = { m -> toast(m) },
            onDismiss = { styleDialog = false }
        )
    }

    if (bgDialog) {           // Page settings
        val colors = listOf(0xFFFFFFFF, 0xFFFFF8E1, 0xFFE8F5E9, 0xFFE3F2FD, 0xFFFCE4EC, 0xFFEDE7F6, 0xFFEEEEEE, 0xFF2B2B2B).map { it.toInt() }
        AlertDialog(
            onDismissRequest = { bgDialog = false },
            title = { Text("Page settings") },
            text = {
                Column {
                    Text("Scrolling direction", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.outline)
                    listOf("Vertical", "Horizontal", "2-page horizontal").forEachIndexed { i, label ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = i == 0, onClick = null, enabled = i == 0)
                            Text(
                                if (i == 0) label else "$label (not built yet)",
                                Modifier.padding(start = 10.dp),
                                color = if (i == 0) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline
                            )
                        }
                    }
                    Text(
                        "Background colour", Modifier.padding(top = 14.dp, bottom = 8.dp),
                        style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.outline
                    )
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        colors.forEach { c ->
                            Box(
                                Modifier.size(44.dp).clip(CircleShape).background(Color(c))
                                    .border(BorderStroke(if (paperColor == c) 3.dp else 1.dp, MaterialTheme.colorScheme.outline), CircleShape)
                                    .clickable { vm.setPaperColor(c) }
                            )
                        }
                    }
                }
            },
            confirmButton = { TextButton({ bgDialog = false }) { Text("Close") } }
        )
    }

    if (tableDialog) {
        TablePropertiesDialog(
            onCancel = { tableDialog = false },
            onDone = { r, c ->
                tableDialog = false
                val (cx, cy) = viewCenter()
                vm.setMode(EditorMode.DRAW)
                vm.addTable(cx, cy, r, c)
            }
        )
    }

    editObj?.let { (id, cell) ->
        val o = objects.firstOrNull { it.id == id }
        if (o != null) {
            ObjectTextDialog(
                title = if (cell >= 0) "Cell text" else "Sticky note",
                initial = if (cell >= 0) o.cells.getOrElse(cell) { "" } else o.text,
                onDismiss = { editObj = null },
                onSave = { t ->
                    if (cell >= 0) vm.setCell(id, cell, t) else vm.setObjectText(id, t)
                    editObj = null
                }
            )
        }
    }

    if (drawingPad) {
        DrawingPad(
            onCancel = { drawingPad = false },
            onDone = { img ->
                drawingPad = false
                runCatching {
                    val dir = java.io.File(ctx.cacheDir, "camera").apply { mkdirs() }
                    val f = java.io.File(dir, "drawing_" + System.currentTimeMillis() + ".png")
                    f.outputStream().use { img.asAndroidBitmap().compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
                    val u = androidx.core.content.FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
                    val (cx, cy) = viewCenter()
                    vm.setMode(EditorMode.IMAGE)
                    vm.addImage(u, cx, cy)
                }.onFailure { toast("Could not save the drawing") }
            }
        )
    }

    if (searchDialog) {
        var q by remember { mutableStateOf("") }
        var results by remember { mutableStateOf<List<Triple<Long, Int, String>>>(emptyList()) }
        var searched by remember { mutableStateOf(false) }
        val scope = androidx.compose.runtime.rememberCoroutineScope()
        AlertDialog(
            onDismissRequest = { searchDialog = false },
            title = { Text("Search") },
            text = {
                Column {
                    OutlinedTextField(
                        q, { q = it; searched = false }, Modifier.fillMaxWidth(), singleLine = true,
                        placeholder = { Text("Search typed text in this note") }
                    )
                    Text(
                        "Handwriting is not searchable yet (it needs OCR).", Modifier.padding(top = 4.dp),
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline
                    )
                    if (searched && results.isEmpty()) Text("No matches", Modifier.padding(top = 12.dp))
                    results.forEach { (pid, n, snippet) ->
                        Column(Modifier.fillMaxWidth().clickable { vm.switchPage(pid); searchDialog = false }.padding(vertical = 8.dp)) {
                            Text("Page $n", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                            Text(snippet, maxLines = 2)
                        }
                    }
                }
            },
            confirmButton = { TextButton({ scope.launch { results = vm.searchTyped(q); searched = true } }) { Text("Search") } },
            dismissButton = { TextButton({ searchDialog = false }) { Text("Close") } }
        )
    }

    if (trashDialog) {
        AlertDialog(
            onDismissRequest = { trashDialog = false },
            title = { Text("Move to recycle bin?") },
            text = { Text("This note goes to the recycle bin.") },
            confirmButton = { TextButton({ trashDialog = false; vm.trashNote { onBack() } }) { Text("Move") } },
            dismissButton = { TextButton({ trashDialog = false }) { Text("Cancel") } }
        )
    }

    if (folderDialog) {
        AlertDialog(
            onDismissRequest = { folderDialog = false },
            title = { Text("Add note to") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text(
                        "No folder", Modifier.fillMaxWidth().clickable { vm.moveToFolder(null); folderDialog = false }.padding(vertical = 14.dp)
                    )
                    folders.forEach { f ->
                        Text(
                            f.folder.name,
                            Modifier.fillMaxWidth().clickable { vm.moveToFolder(f.folder.id); folderDialog = false }.padding(vertical = 14.dp)
                        )
                    }
                }
            },
            confirmButton = { TextButton({ folderDialog = false }) { Text("Close") } }
        )
    }

    if (exportDialog) {
        AlertDialog(
            onDismissRequest = { exportDialog = false },
            title = { Text("Export note") },
            text = { Text("Share as an image or a PDF (handwriting stays sharp in the PDF).") },
            confirmButton = { TextButton({ export("pdf") }) { Text("PDF") } },
            dismissButton = { TextButton({ export("png") }) { Text("Image (PNG)") } }
        )
    }

    if (exporting) {
        AlertDialog(
            onDismissRequest = { },
            title = { Text("Exporting...") },
            text = { LinearProgressIndicator(Modifier.fillMaxWidth()) },
            confirmButton = { }
        )
    }

    LaunchedEffect(panel == PanelKind.STYLE) { if (panel == PanelKind.STYLE) vm.beginStyleSession() else vm.endStyleSession() }

    panel?.let { kind ->
        ToolPanelDialog(
            kind = kind, pen = pen,
            anchor = toolAnchors[
                when (kind) {
                    PanelKind.PEN -> "PEN"
                    PanelKind.HIGHLIGHTER -> "HIGHLIGHTER"
                    PanelKind.ERASER -> "ERASER"
                    PanelKind.SHAPE -> "SHAPE"
                    PanelKind.TAPE -> "TAPE"
                    PanelKind.LASER -> "LASER"
                    PanelKind.HELP -> "HELP"
                    PanelKind.STYLE -> "STYLE"
                    PanelKind.SELECT -> "SELECT"
                }
            ],
            dock = dock,
            update = vm::updatePen,
            onRemoveTape = vm::removeAllTape,
            onClearAll = { vm.clearAll(); panel = null },
            onPickColor = { picker = PickerTarget.PEN },
            onPickLaserColor = { picker = PickerTarget.LASER },
            onDismiss = { panel = null },
            customContent = {
                if (kind == PanelKind.STYLE) {
                    val first = inkView?.selectedStrokes()?.firstOrNull()
                    StyleContent(
                        startColor = first?.colorArgb ?: pen.active.color,
                        recent = pen.settings.values.map { it.color },
                        onApply = { c, sz -> inkView?.restyleKeepPen(c, sz) },
                        onCustomColor = { picker = PickerTarget.STYLE }
                    )
                } else if (kind == PanelKind.SELECT) {
                    SelectModeContent(pen.selectRect) { r -> vm.updatePen { it.copy(selectRect = r) }; panel = null }
                }
            }
        )
    }

    picker?.let { target ->
        ColorPickerDialog(
            initial = if (target == PickerTarget.LASER) pen.laserColor else pen.active.color,
            onDismiss = { picker = null },
            onPick = { c ->
                when (target) {
                    PickerTarget.PEN -> vm.updatePen { it.withColor(c) }
                    PickerTarget.LASER -> vm.updatePen { it.copy(laserColor = c, laserRainbow = false) }
                    PickerTarget.SELECTION -> inkView?.recolorSelection(c)
                    PickerTarget.STYLE -> inkView?.restyleKeepPen(c, null)
                }
                picker = null
            }
        )
    }

    // Convert to text (Samsung): gear = language, X, the recognised text, Copy | Convert
    recog?.let { r ->
        AlertDialog(
            onDismissRequest = { recog = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton({ langDialog = true }) { Icon(Icons.Default.Settings, "Language") }
                    Spacer(Modifier.weight(1f))
                    IconButton({ recog = null }) { Icon(Icons.Default.Close, "Close") }
                }
            },
            text = {
                Column {
                    when (r) {
                        Recog.Loading -> {
                            LinearProgressIndicator(Modifier.fillMaxWidth())
                            Text("Recognising... the first time this downloads the language model (internet needed).", Modifier.padding(top = 8.dp))
                        }
                        is Recog.Done -> Text(
                            r.text.ifBlank { "No text to recognise" },
                            style = MaterialTheme.typography.titleMedium,
                            color = if (r.text.isBlank()) MaterialTheme.colorScheme.outline else MaterialTheme.colorScheme.primary
                        )
                        is Recog.Error -> Text("Could not recognise: ${r.msg}")
                    }
                }
            },
            confirmButton = {
                if (r is Recog.Done && r.text.isNotBlank()) {
                    Row {
                        TextButton({
                            val cm = ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                            cm.setPrimaryClip(android.content.ClipData.newPlainText("text", r.text))
                            toast("Copied")
                        }) { Text("Copy") }
                        TextButton({ vm.appendText(r.text); inkView?.deleteSelection(); recog = null }) { Text("Convert") }
                    }
                }
            }
        )
    }

    if (langDialog) {
        val langs = listOf(
            "English (United States)" to "en-US", "English (United Kingdom)" to "en-GB", "English (India)" to "en-IN",
            "Hindi" to "hi", "Spanish (Spain)" to "es-ES", "French (France)" to "fr-FR", "German" to "de-DE", "Arabic" to "ar"
        )
        val cur = (recog as? Recog.Done)?.lang ?: "en-US"
        AlertDialog(
            onDismissRequest = { langDialog = false },
            title = { Text("Select language") },
            text = {
                Column(Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState())) {
                    langs.forEach { (name, tag) ->
                        Row(
                            Modifier.fillMaxWidth().clickable { langDialog = false; recognize(tag) }.padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = cur == tag, onClick = null)
                            Text(name, Modifier.padding(start = 12.dp))
                        }
                    }
                    androidx.compose.material3.HorizontalDivider(Modifier.padding(vertical = 8.dp))
                    Text("Insert text into", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.outline)
                    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = true, onClick = null)
                        Text("Body text", Modifier.padding(start = 12.dp))
                    }
                    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = false, onClick = null, enabled = false)
                        Text("New text box (not built yet)", Modifier.padding(start = 12.dp), color = MaterialTheme.colorScheme.outline)
                    }
                }
            },
            confirmButton = { TextButton({ langDialog = false }) { Text("Done") } },
            dismissButton = { TextButton({ langDialog = false }) { Text("Cancel") } }
        )
    }
}

// =============================================================== zoom / page chips
/** Samsung: while zooming a "217% (reset)" chip, while scrolling a "1/2" page chip; both fade after a moment. */
@Composable
private fun BoxScope.ViewChips(vp: () -> Viewport, fit: Float, pageText: String, onReset: () -> Unit) {
    val v = vp()
    var zoomOn by remember { mutableStateOf(false) }
    var pageOn by remember { mutableStateOf(false) }
    var lastScale by remember { mutableFloatStateOf(v.scale) }
    var lastTy by remember { mutableFloatStateOf(v.ty) }
    LaunchedEffect(v.scale, v.ty) {
        if (abs(v.scale - lastScale) > 0.001f) zoomOn = true
        if (abs(v.ty - lastTy) > 1f) pageOn = true
        lastScale = v.scale; lastTy = v.ty
        delay(1600)
        zoomOn = false; pageOn = false
    }
    val pct = (v.scale / fit * 100f).roundToInt()
    if (zoomOn && pct != 100) {
        Surface(
            shape = RoundedCornerShape(16.dp), color = Color(0xFFEDEDF0),
            modifier = Modifier.align(Alignment.TopEnd).padding(top = 10.dp, end = 14.dp).clip(RoundedCornerShape(16.dp)).clickable(onClick = onReset)
        ) {
            Row(Modifier.padding(horizontal = 10.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("$pct%", fontSize = 12.sp, color = Color(0xFF444444))
                Spacer(Modifier.width(6.dp))
                Icon(Icons.Default.Refresh, "Reset zoom", Modifier.size(14.dp), tint = Color(0xFF444444))
            }
        }
    }
    if (pageOn && !zoomOn) {
        Surface(
            shape = RoundedCornerShape(14.dp), color = Color(0xCC333333),
            modifier = Modifier.align(Alignment.BottomEnd).padding(bottom = 12.dp, end = 14.dp)
        ) { Text(pageText, Modifier.padding(horizontal = 10.dp, vertical = 4.dp), fontSize = 12.sp, color = Color.White) }
    }
}

// =============================================================== small bars
@Composable
private fun ReadingBar(onExit: () -> Unit) {
    Surface(tonalElevation = 3.dp, shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)) {
        Row(
            Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 20.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Reading mode - drawing and typing are locked", Modifier.weight(1f))
            TextButton(onExit) { Text("Exit") }
        }
    }
}

@Composable
private fun ImageToolbar(onDone: () -> Unit, onAdd: () -> Unit, onForward: () -> Unit, onBackward: () -> Unit, onDelete: () -> Unit) {
    Surface(tonalElevation = 3.dp, shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)) {
        Row(
            Modifier.navigationBarsPadding().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            ToolButton(false, onDone) { Icon(Icons.Default.Check, "Done") }
            ToolButton(false, onAdd) { Icon(Icons.Default.Image, "Add photo") }
            ToolButton(false, onForward) { Icon(Icons.Default.KeyboardArrowUp, "Bring forward") }
            ToolButton(false, onBackward) { Icon(Icons.Default.KeyboardArrowDown, "Send backward") }
            ToolButton(false, onDelete) { Icon(Icons.Default.Delete, "Delete photo") }
            Text("Drag to move, pinch to resize / rotate", Modifier.padding(start = 12.dp), style = MaterialTheme.typography.labelMedium)
        }
    }
}

@Composable
private fun DebugHud(s: PenSample?, modifier: Modifier) {
    val tool = when (s?.toolType) { 1 -> "finger"; 2 -> "stylus"; 3 -> "mouse"; 4 -> "eraser"; else -> "-" }
    val text = "tool: $tool" + (if (s?.hover == true) " (hover)" else "") +
        "\npressure: " + "%.3f".format(s?.pressure ?: 0f) +
        "\ntilt: " + "%.0f".format(Math.toDegrees((s?.tilt ?: 0f).toDouble())) + " deg" +
        "\norient: " + "%.0f".format(Math.toDegrees((s?.orientation ?: 0f).toDouble())) + " deg" +
        "\n" + (s?.stats ?: "")
    Surface(color = Color.Black.copy(alpha = 0.65f), shape = RoundedCornerShape(10.dp), modifier = modifier.padding(8.dp)) {
        Text(text, color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 12.sp, modifier = Modifier.padding(8.dp))
    }
}

// =============================================================== text formatting bar
private val textSwatches = listOf(0xFF000000, 0xFF1565C0, 0xFFC62828, 0xFF2E7D32, 0xFFF9A825, 0xFF6A1B9A, 0xFFFFFFFF)
    .map { it.toInt() }

@Composable
private fun TextToolbar(b: TextBlock, format: ((TextBlock) -> TextBlock) -> Unit, onDraw: () -> Unit) {
    Surface(color = MaterialTheme.colorScheme.surface, tonalElevation = 0.dp) {
        Column(Modifier.navigationBarsPadding().imePadding().padding(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically
            ) {
                ToolButton(false, onDraw) { ToolGlyph(Glyph.PEN, MaterialTheme.colorScheme.onSurface, Color(0xFF7086F7)) }
                FilterChip(b.bold, { format { it.copy(bold = !it.bold) } }, { Text("B", fontWeight = FontWeight.Bold) })
                FilterChip(b.italic, { format { it.copy(italic = !it.italic) } }, { Text("I", fontStyle = FontStyle.Italic) })
                FilterChip(b.underline, { format { it.copy(underline = !it.underline) } }, { Text("U", textDecoration = TextDecoration.Underline) })
                FilterChip(b.strike, { format { it.copy(strike = !it.strike) } }, { Text("S", textDecoration = TextDecoration.LineThrough) })
                FilterChip(
                    b.kind == BlockKind.BULLET,
                    { format { it.copy(kind = if (it.kind == BlockKind.BULLET) BlockKind.PARAGRAPH else BlockKind.BULLET, checked = false) } },
                    { Text("• List") }
                )
                FilterChip(
                    b.kind == BlockKind.CHECKLIST,
                    { format { it.copy(kind = if (it.kind == BlockKind.CHECKLIST) BlockKind.PARAGRAPH else BlockKind.CHECKLIST, checked = false) } },
                    { Text("Checklist") }
                )
                AssistChip({ format { it.copy(sizeSp = (it.sizeSp - 2).coerceAtLeast(12)) } }, { Text("A-") })
                AssistChip({ format { it.copy(sizeSp = (it.sizeSp + 2).coerceAtMost(48)) } }, { Text("A+") })
                AssistChip(
                    { format { it.copy(align = (it.align + 1) % 3) } },
                    { Text(when (b.align) { 1 -> "Center"; 2 -> "Right"; else -> "Left" }) }
                )
                AssistChip({ format { it.copy(indent = (it.indent - 1).coerceAtLeast(0)) } }, { Text("<-") })
                AssistChip({ format { it.copy(indent = (it.indent + 1).coerceAtMost(6)) } }, { Text("->") })
                FilterChip(
                    b.highlightArgb != 0,
                    { format { it.copy(highlightArgb = if (it.highlightArgb == 0) 0xFFFFEB3B.toInt() else 0) } },
                    { Text("Highlight") }
                )
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(
                    Modifier.size(32.dp).clip(CircleShape)
                        .border(BorderStroke(if (b.colorArgb == 0) 3.dp else 1.dp, MaterialTheme.colorScheme.outline), CircleShape)
                        .clickable { format { it.copy(colorArgb = 0) } }
                )
                textSwatches.forEach { c ->
                    Box(
                        Modifier.size(32.dp).clip(CircleShape).background(Color(c))
                            .border(BorderStroke(if (b.colorArgb == c) 3.dp else 1.dp, MaterialTheme.colorScheme.outline), CircleShape)
                            .clickable { format { it.copy(colorArgb = c) } }
                    )
                }
            }
        }
    }
}
