package com.example.inknotes.ui.editor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke as DrawStroke
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.PointerInputChange
import androidx.compose.ui.input.pointer.PointerType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.example.inknotes.domain.model.LineStyle
import com.example.inknotes.domain.model.PenType
import com.example.inknotes.domain.model.Stroke
import com.example.inknotes.domain.model.StrokePoint
import com.example.inknotes.ink.StrokeRenderer
import java.util.UUID
import kotlin.math.hypot

/**
 * The page area the easy writing pad currently writes into (top-left + width in page px).
 * The pad shows exactly this area magnified; what is written in the pad lands in it at normal size.
 */
data class PadFrame(val x: Float, val y: Float, val w: Float)

private const val PAD_MARGIN = 40f

/** Moves the frame on to the right (a space); wraps to the next line at the end of the page. */
fun PadFrame.advance(pageW: Float, frameH: Float, frac: Float = 0.5f): PadFrame {
    val nx = x + w * frac
    return if (nx + w > pageW - PAD_MARGIN / 2f) PadFrame(PAD_MARGIN, y + frameH * 0.9f, w) else copy(x = nx)
}

fun PadFrame.back(pageW: Float, frameH: Float, frac: Float = 0.5f): PadFrame {
    val nx = x - w * frac
    return if (nx >= PAD_MARGIN / 2f) copy(x = nx)
    else if (y > PAD_MARGIN) PadFrame(maxOf(PAD_MARGIN, pageW - PAD_MARGIN / 2f - w), (y - frameH * 0.9f).coerceAtLeast(PAD_MARGIN), w)
    else copy(x = PAD_MARGIN)
}

fun PadFrame.nextLine(frameH: Float): PadFrame = PadFrame(PAD_MARGIN, y + frameH * 0.9f, w)

private fun strokeBounds(s: Stroke): FloatArray {
    var x0 = Float.MAX_VALUE; var y0 = Float.MAX_VALUE; var x1 = -Float.MAX_VALUE; var y1 = -Float.MAX_VALUE
    for (p in s.points) {
        if (p.x < x0) x0 = p.x; if (p.x > x1) x1 = p.x
        if (p.y < y0) y0 = p.y; if (p.y > y1) y1 = p.y
    }
    val m = s.width
    return floatArrayOf(x0 - m, y0 - m, x1 + m, y1 + m)
}

/**
 * Easy writing pad (Samsung): a thin strip above the toolbar that shows the framed page area magnified.
 * Everything written in the strip shows up in the frame on the page at once (see [onLive]); after the pen is lifted
 * near the right end the frame moves on by itself, at the end of the page it jumps to the next line.
 */
@Composable
fun EasyWritingPad(
    frame: PadFrame,
    strokes: List<Stroke>,
    paperColor: Int,
    penType: PenType,
    penColor: Int,
    penWidth: Float,
    pageWidth: Float,
    areaHeight: androidx.compose.ui.unit.Dp,
    onAspect: (Float) -> Unit,                 // pad height / pad width: the frame on the page has the same shape
    onFrame: (PadFrame) -> Unit,
    onLive: (List<StrokePoint>) -> Unit,       // the stroke being written, for the instant preview on the page
    onStroke: (Stroke) -> Unit,
    onClose: () -> Unit
) {
    val renderer = remember { StrokeRenderer(false) }
    val bounds = remember { HashMap<String, FloatArray>() }
    val frameState = rememberUpdatedState(frame)
    val onFrameState = rememberUpdatedState(onFrame)
    val onStrokeState = rememberUpdatedState(onStroke)
    val onLiveState = rememberUpdatedState(onLive)
    val penState = rememberUpdatedState(Triple(penType, penColor, penWidth))
    var area by remember { mutableStateOf(IntSize.Zero) }
    var live by remember { mutableStateOf<List<StrokePoint>>(emptyList()) }
    val frameH = if (area.width > 0) frame.w * area.height / area.width else frame.w * 0.3f
    val grip = Color(0xFF8A8A90)

    Column(Modifier.fillMaxWidth().background(Color(0xFFFAFAFB))) {
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
        // thin header: grip on the left, back / forward / new line on the right
        Row(Modifier.fillMaxWidth().height(24.dp).padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Canvas(Modifier.size(width = 10.dp, height = 14.dp)) {
                for (cx in listOf(2.dp.toPx(), 7.dp.toPx())) for (cy in listOf(2.dp.toPx(), 7.dp.toPx(), 12.dp.toPx())) {
                    drawCircle(grip, 1.2f.dp.toPx(), Offset(cx, cy))
                }
            }
            Spacer(Modifier.weight(1f))
            Canvas(Modifier.size(22.dp).clickable { onFrame(frame.back(pageWidth, frameH)) }) {          // <
                val c = Offset(size.width / 2f, size.height / 2f); val a = 4.dp.toPx()
                drawLine(grip, Offset(c.x + a / 2f, c.y - a), Offset(c.x - a / 2f, c.y), 1.6f.dp.toPx(), StrokeCap.Round)
                drawLine(grip, Offset(c.x - a / 2f, c.y), Offset(c.x + a / 2f, c.y + a), 1.6f.dp.toPx(), StrokeCap.Round)
            }
            Canvas(Modifier.size(22.dp).clickable { onFrame(frame.advance(pageWidth, frameH)) }) {       // >
                val c = Offset(size.width / 2f, size.height / 2f); val a = 4.dp.toPx()
                drawLine(grip, Offset(c.x - a / 2f, c.y - a), Offset(c.x + a / 2f, c.y), 1.6f.dp.toPx(), StrokeCap.Round)
                drawLine(grip, Offset(c.x + a / 2f, c.y), Offset(c.x - a / 2f, c.y + a), 1.6f.dp.toPx(), StrokeCap.Round)
            }
            Canvas(Modifier.size(22.dp).clickable { onFrame(frame.nextLine(frameH)) }) {                 // enter
                val c = Offset(size.width / 2f, size.height / 2f); val a = 4.dp.toPx()
                drawLine(grip, Offset(c.x + a, c.y - a), Offset(c.x + a, c.y + a / 2f), 1.4f.dp.toPx(), StrokeCap.Round)
                drawLine(grip, Offset(c.x + a, c.y + a / 2f), Offset(c.x - a, c.y + a / 2f), 1.4f.dp.toPx(), StrokeCap.Round)
                drawLine(grip, Offset(c.x - a, c.y + a / 2f), Offset(c.x - a / 2f, c.y - a / 4f), 1.4f.dp.toPx(), StrokeCap.Round)
                drawLine(grip, Offset(c.x - a, c.y + a / 2f), Offset(c.x - a / 2f, c.y + a * 1.2f), 1.4f.dp.toPx(), StrokeCap.Round)
            }
        }
        Box(
            Modifier.fillMaxWidth().height(areaHeight).clipToBounds()
                .onSizeChanged { sz ->
                    area = sz
                    if (sz.width > 0) onAspect(sz.height.toFloat() / sz.width)
                }
                .pointerInput(Unit) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        val fr = frameState.value
                        val sz = area
                        if (sz.width <= 0) return@awaitEachGesture
                        val k = sz.width / fr.w                              // pad px per page px
                        val t0 = down.uptimeMillis
                        val pts = ArrayList<StrokePoint>()
                        fun add(c: PointerInputChange) {
                            val px = fr.x + c.position.x / k
                            val py = fr.y + c.position.y / k
                            val pr = if (c.type == PointerType.Stylus) c.pressure.coerceIn(0.05f, 1f) else 0.5f
                            val last = pts.lastOrNull()
                            if (last == null || hypot(px - last.x, py - last.y) * k > 1f) {
                                pts.add(StrokePoint(px, py, pr, 0f, 0f, c.uptimeMillis - t0))
                            }
                        }
                        add(down)
                        down.consume()
                        live = pts.toList()
                        onLiveState.value(live)
                        while (true) {
                            val ev = awaitPointerEvent()
                            val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                            add(ch)
                            ch.consume()
                            if (!ch.pressed) break
                            live = pts.toList()
                            onLiveState.value(live)
                        }
                        live = emptyList()
                        if (pts.size >= 2) {
                            val (type, color, width) = penState.value
                            onStrokeState.value(Stroke(UUID.randomUUID().toString(), type, color, width, pts))
                            onLiveState.value(emptyList())
                            val endPadX = (pts.last().x - fr.x) * k
                            if (endPadX > sz.width * 0.80f) {                // near the right end: the frame moves on by itself
                                val fh = fr.w * sz.height / sz.width
                                val shift = (endPadX - sz.width * 0.12f) / k
                                val moved = fr.copy(x = fr.x + shift)
                                onFrameState.value(
                                    if (moved.x + moved.w > pageWidth - 20f) fr.nextLine(fh) else moved
                                )
                            }
                        } else onLiveState.value(emptyList())
                    }
                }
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val k = size.width / frame.w
                val fh = size.height / k
                drawIntoCanvas { c ->
                    val nc = c.nativeCanvas
                    nc.save()
                    nc.drawColor(paperColor)
                    nc.scale(k, k)
                    nc.translate(-frame.x, -frame.y)
                    for (s in strokes) {
                        val b = bounds.getOrPut(s.id) { strokeBounds(s) }
                        if (b[2] < frame.x || b[0] > frame.x + frame.w || b[3] < frame.y || b[1] > frame.y + fh) continue
                        renderer.draw(nc, s)
                    }
                    if (live.size >= 2) renderer.drawLive(nc, penType, penColor, penWidth, LineStyle.SOLID, live)
                    nc.restore()
                }
                // blue marker near the right end: the frame moves on after the pen is lifted past it
                val mx = size.width * 0.93f
                drawLine(Color(0xFF2F6FE0), Offset(mx, 0f), Offset(mx, size.height), 2.dp.toPx())
                drawRect(Color(0xFF2F6FE0), Offset(mx - 3.dp.toPx(), 0f), Size(8.dp.toPx(), 5.dp.toPx()))
            }
        }
    }
}
