package com.example.inknotes.ui.editor

import android.graphics.RectF
import com.example.inknotes.domain.model.Stroke

/** Maths solver: "12+3x4=" -> "24". The recognised handwriting is evaluated; nothing leaves the device. */
object MathSolver {
    fun solve(raw: String): String? {
        var t = raw.replace(" ", "").replace('\u00D7', '*').replace('x', '*').replace('X', '*')
            .replace('\u00F7', '/').replace(':', '/').replace('\u2212', '-').replace('\u2013', '-')
        if (!t.endsWith("=")) return null
        t = t.dropLast(1)
        if (t.isEmpty() || t.none { it in "+-*/^" }) return null          // a sum needs an operator
        val v = runCatching { Parser(t).parse() }.getOrNull() ?: return null
        return format(v)
    }

    private fun format(v: Double): String? {
        if (v.isNaN() || v.isInfinite()) return null
        if (v == Math.rint(v) && kotlin.math.abs(v) < 1e12) return v.toLong().toString()
        return String.format(java.util.Locale.US, "%.3f", v).trimEnd('0').trimEnd('.')
    }

    fun bounds(s: Stroke): RectF {
        val r = RectF(Float.MAX_VALUE, Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE)
        for (p in s.points) {
            if (p.x < r.left) r.left = p.x
            if (p.y < r.top) r.top = p.y
            if (p.x > r.right) r.right = p.x
            if (p.y > r.bottom) r.bottom = p.y
        }
        return r
    }

    private class Parser(val s: String) {
        var i = 0
        fun parse(): Double {
            val v = expr()
            if (i != s.length) throw IllegalArgumentException("trailing")
            return v
        }
        fun expr(): Double {
            var v = term()
            while (i < s.length && (s[i] == '+' || s[i] == '-')) {
                val op = s[i++]
                val r = term()
                v = if (op == '+') v + r else v - r
            }
            return v
        }
        fun term(): Double {
            var v = power()
            while (i < s.length && (s[i] == '*' || s[i] == '/')) {
                val op = s[i++]
                val r = power()
                v = if (op == '*') v * r else v / r
            }
            return v
        }
        fun power(): Double {
            val b = unary()
            if (i < s.length && s[i] == '^') { i++; return Math.pow(b, power()) }
            return b
        }
        fun unary(): Double {
            if (i < s.length && s[i] == '-') { i++; return -unary() }
            if (i < s.length && s[i] == '+') { i++; return unary() }
            return atom()
        }
        fun atom(): Double {
            if (i < s.length && s[i] == '(') {
                i++
                val v = expr()
                if (i >= s.length || s[i] != ')') throw IllegalArgumentException("paren")
                i++
                return v
            }
            val st = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            if (st == i) throw IllegalArgumentException("number")
            return s.substring(st, i).toDouble()
        }
    }
}
