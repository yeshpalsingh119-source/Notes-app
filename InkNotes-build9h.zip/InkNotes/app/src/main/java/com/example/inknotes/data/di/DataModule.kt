package com.example.inknotes.data.di

import android.content.Context
import androidx.room.Room
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.inknotes.data.db.AppDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

private fun addColumn(db: SupportSQLiteDatabase, table: String, column: String, ddl: String) {
    db.query("PRAGMA table_info(`$table`)").use { c ->
        val idx = c.getColumnIndex("name")
        while (c.moveToNext()) if (c.getString(idx) == column) return
    }
    db.execSQL("ALTER TABLE `$table` ADD COLUMN `$column` $ddl")
}

/**
 * v1 -> v2. Older installs (build 5) do not have the tag tables or some columns, fresh build 8 installs do:
 * everything is created only when missing, so both end up with the same schema and keep their notes.
 */
val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS `tags` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `name` TEXT NOT NULL, `colorArgb` INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS `note_tags` (`noteId` INTEGER NOT NULL, `tagId` INTEGER NOT NULL, PRIMARY KEY(`noteId`, `tagId`))")
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_note_tags_tagId` ON `note_tags` (`tagId`)")
        addColumn(db, "notes", "isLocked", "INTEGER NOT NULL DEFAULT 0")
        addColumn(db, "notes", "openCount", "INTEGER NOT NULL DEFAULT 0")
        addColumn(db, "notes", "paperColor", "INTEGER NOT NULL DEFAULT -1")
        addColumn(db, "notes", "infiniteScroll", "INTEGER NOT NULL DEFAULT 0")
        addColumn(db, "notes", "searchText", "TEXT NOT NULL DEFAULT ''")
        addColumn(db, "notes", "coverIndex", "INTEGER NOT NULL DEFAULT 0")
        addColumn(db, "notes", "isFavorite", "INTEGER NOT NULL DEFAULT 0")
        addColumn(db, "pages", "bookmarked", "INTEGER NOT NULL DEFAULT 0")
        addColumn(db, "pages", "richTextJson", "TEXT NOT NULL DEFAULT ''")
    }
}

@Module
@InstallIn(SingletonComponent::class)
object DataModule {
    @Provides @Singleton
    fun db(@ApplicationContext c: Context): AppDatabase =
        Room.databaseBuilder(c, AppDatabase::class.java, "notes.db").addMigrations(MIGRATION_1_2).build()

    @Provides fun noteDao(db: AppDatabase) = db.noteDao()
    @Provides fun pageDao(db: AppDatabase) = db.pageDao()
    @Provides fun folderDao(db: AppDatabase) = db.folderDao()
    @Provides fun tagDao(db: AppDatabase) = db.tagDao()
}
