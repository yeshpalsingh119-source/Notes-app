package com.example.inknotes

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.inknotes.ui.AppNav
import com.example.inknotes.ui.theme.InkNotesTheme
import androidx.fragment.app.FragmentActivity
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        preferHighestRefreshRate()
        setContent { InkNotesTheme { AppNav() } }
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        // PDF page bitmaps are re-rendered on demand, so they are the first thing to give back
        if (level >= android.content.ComponentCallbacks2.TRIM_MEMORY_BACKGROUND) com.example.inknotes.ui.editor.PdfPages.trimAll(true)
        else if (level >= android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) com.example.inknotes.ui.editor.PdfPages.trimAll(false)
    }

    private fun preferHighestRefreshRate() {
        runCatching {
            @Suppress("DEPRECATION")
            val best = windowManager.defaultDisplay.supportedModes.maxByOrNull { it.refreshRate } ?: return
            val lp = window.attributes
            lp.preferredDisplayModeId = best.modeId
            window.attributes = lp
        }
    }
}
