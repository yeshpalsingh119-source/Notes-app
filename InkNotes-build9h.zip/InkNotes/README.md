# InkNotes - Samsung Notes-inspired app (build 9h)

Kotlin + Jetpack Compose (Material 3, One UI feel), Clean Architecture/MVVM, Hilt, Room, Flow.
Target device: Samsung Galaxy Tab S10 Lite (S Pen). Android Studio: open the folder, sync, run on tablet/emulator.

**Status: NOT compiled yet** (no Android SDK / network where this was generated). Dependency versions are
placeholders - bump AGP/Kotlin/KSP/Hilt together in Android Studio. `androidx.graphics` low-latency API
(`CanvasFrontBufferedRenderer`) may need small signature tweaks for your exact version.

## Layout
```
domain/      models (Stroke, PenType...), UndoRedoStack (200 steps)
data/        Room (notes, folders, pages, tags), StrokeFileStore (chunked JSON), NotesRepository, Hilt module
ink/         InkSurfaceView (low-latency S Pen), StrokeRenderer, PenSpecs, TemplateRenderer
ui/home      collapsing One UI header, drawer, nested folders, grid/list modes, search
ui/editor    3 layers: Compose paper/template -> (rich text, Phase 2) -> ink SurfaceView; pen toolbar
```

## Phase 1 (in this zip)
- Home: collapsing large app bar, drawer (permanent on tablet), nested folders with colour + total count,
  Grid S/M/L + List + Simple list, pinned first, trash (30-day purge), title/text search, long-press pin/trash
- Editor: low-latency stylus ink, pressure + tilt, 5 pens + 2 highlighters (+ straight snap), stroke eraser
  (+ "erase highlighter only"), S Pen button / eraser tip = eraser, finger-draw toggle, palm rejection,
  pinch-zoom + pan, templates (blank, 3 rulings, grid, dotted), dark paper, undo/redo, auto-save after every stroke

## Build 9h (this zip, on top of 9g) - versionName 0.9.8
Compile-error fix from the GitHub Actions log of build 9g (6 errors, all the same cause): the new session-only fields
`mathsSolver` and `tapeHidden` had been added to the private `SavedPens` class instead of `PenState` (EditorViewModel.kt).
They are now in `PenState` (not saved, on purpose) and `SavedPens` is back to what it was.
Used by: EditorScreen.kt (Maths solver menu item, tape toast, `v.tapeHidden`) and ToolPanels.kt (Tape panel eye icon).
No other change. Still NOT compile-tested here: this fixes exactly the errors in the log, the Kotlin front end reported
no others, but another run on GitHub Actions is needed to know. Keep only ONE InkNotes-build*.zip in the repo root.

## Build 9g (on top of 9f) - versionName 0.9.7
Not compile-tested (no kotlinc / internet here). The 9c-fixed ... 9f GitHub Actions builds are also still unconfirmed:
if a compile error shows up, send the log zip and fix that first. Keep only ONE InkNotes-build*.zip in the repo root.
- Sticky note + Table (+ menu, last two items; ObjectUi.kt, uses the existing PageObject / ObjectStore backend):
  drawn in a Compose layer under the ink; the FINGER is handled by InkSurfaceView.objectTouchListener (tap = select, drag a
  selected one = move, round corner handle = resize, tap a selected one = edit its text / the table cell), the PEN is not
  touched so it writes on top. Floating menu above the selection: sticky = Background colour (4 colours) + Delete, table =
  Add row / Add column / Table style (cycles the header colour) + Delete. "Table properties" dialog (Rows x Columns, Cancel / Done).
  Header row + column are light purple. Sticky minimise-to-icon is NOT done.
- Insert > Drawing (DrawingPad.kt): full-screen sketch on grainy paper, Pencil / Marker / Brush / Spray, 8 colours, size slider,
  undo / redo, Done puts the picture on the page as a photo (IMAGE mode, so it can be moved). No small badge in the corner.
- Maths solver (three-dots menu): when on (and the handwriting-help switches are turned off, like Samsung) a finished sum such as
  "12+3x4=" is recognised (ML Kit, en-US) 0.9 s after the last stroke, evaluated (MathSolver.kt) and the answer is added in blue
  to the right of the equation (a TEXT PageObject). Needs the ML Kit English model (downloads once).
- Tape: eye icon in the Tape panel hides / shows all tape (toast "Tape hidden." / "Tape shown.").
- Page panel: Copy / Cut / Paste work (the pasted page goes to the END of the note; PDF pages cannot be copied yet; typed text,
  strokes, photos and sticky notes are copied).
- Search (three-dots menu): searches TYPED text of all pages and jumps to the page. Handwriting is not searchable (no OCR).

**Still not done:** Clipboard sheet and Move forwards / backwards in the Select menu, Convert to maths, Drag for new page /
Release to add page, horizontal and 2-page scrolling, pen wheel, floating text box handles + per-letter formatting, Home sidebar,
cover on the PDF thumbnails, sticky minimise, "New text box" in Convert.

## Build 9f (on top of 9e) - versionName 0.9.6
Not compile-tested (no kotlinc / internet here). The 9c-fixed / 9d / 9e GitHub Actions builds are also still unconfirmed:
if a compile error shows up, send the log zip and fix that first. Keep only ONE InkNotes-build*.zip in the repo root
(the workflow builds the first .zip alphabetically).
- Note style panel (new file NoteStylePanel.kt): Cover tile + Page tile, Page tabs Basic / Academic / Planners / Journals /
  Creative / Custom with template tiles (Blank page, Lined, Lined (narrow), Lined (wide), Grid, Grid (narrow), Cornell, Music,
  Dotted, Weekly, Daily, To-do, Journal), Custom + (Image = not built, PDF works), Cover tabs Pattern / Illustration (not built) / Text,
  Apply. Apply sets the template for EVERY page of the note and saves the cover (coverIndex 1..8 Pattern, 9..16 Text).
- Home cards show the cover when one is set (HomeScreen.NoteFace).
- Left page panel (new file PagePanel.kt), opened by the book icon of the top bar: header "1/N", Select (multi-delete),
  bookmark (current page), search (not built), page thumbnails with numbers, red outline on the open page, red bookmark tab,
  + tile, long-press menu Add page / Copy / Cut / Delete / Erase page / Share / Save as file. Copy and Cut only show
  "not built yet"; Share and Save as file open the export dialog. The old Pages dialog is no longer used.
- Convert to text: Samsung popup (gear, X, recognised text, Copy | Convert) and the "Select language" dialog
  (language radios, "Insert text into": Body text works, New text box greyed).

**Still different from the video (not done):** Sticky note + Table, Insert > Drawing pad, Maths solver / Convert to maths,
Clipboard sheet, Move forwards / backwards, Tape hide / show, Drag for new page / Release to add page, horizontal and
2-page scrolling (Page settings), in-note search, pen wheel, floating text box handles, Home sidebar, Copy / Cut page.

## Build 9e (on top of 9d) - versionName 0.9.5
Not compile-tested (no kotlinc / internet here). The 9c-fixed / 9d GitHub Actions builds are also still unconfirmed:
if a compile error shows up, send the log zip and fix that first. Delete older InkNotes-build*.zip from the repo root
(the workflow builds the first .zip alphabetically).

**1. PDF / zoom engine from the "Galaxy Notes" app** (ui/editor/PdfPages.kt rewritten, same public API):
- layout is instant: only page 1 is opened (the old code opened ALL pages one by one = seconds for 1000 pages and a lock
  that blocked rendering). Every page gets the box of page 1; a page of another shape is centred on white inside its box.
  Side effect: ink written on an OLD PDF note whose pages differ in size from page 1 can sit a little off.
- only two bitmap widths exist (1440 standard, 2160 when zoomed in, PAGE_W * zoom > 1500) so zooming never re-renders;
  before this a new width was rendered for every 256 px step of zoom, in ARGB_8888 up to 2400 px.
- bitmaps are cached as RGB_565 (rendered in ARGB_8888 first: PdfRenderer cannot render into RGB_565) in a 112 MB LruCache,
  so scrolling back does not re-render.
- LIFO render queue + sliding window (visible pages +-2): pages scrolled past are dropped, neighbours pre-rendered.
- MainActivity.onTrimMemory frees the PDF bitmaps when Android is short of memory.
- EditorScreen: pdf.ensure(...) replaced by pdf.request(first, last, hd), debounce 30 ms.
- NOT ported on purpose (you said take only the zoom/PDF part): their page-by-page viewer, ink view and their glitches.

**2. Matches the newer Samsung Notes UI (video 2):**
- Top bar: Pages (book), +, Reading mode (document), Fullscreen, three-dots. Page text and Tags icon left the bar
  (page chip is on the canvas, tags are in the menu).
- + menu: PDF, Voice recording, Image, Camera, Scan, Audio file, Drawing. PDF = new page of the note, Audio file = copied
  into the note's recordings, Camera and Scan = TakePicture + FileProvider (cache/camera) placed on the page as an image;
  CAMERA permission removed from the manifest (the intent camera needs none and crashes if it is declared but not granted).
  Drawing shows "not built yet".
- Three-dots menu: Search, Note style, Page settings, Add note to >, Add tags, Save as, finger drawing, Maths solver,
  and the icon row star / lock / share / print / delete (delete asks, then moves the note to the recycle bin).
  Search and Maths solver only show "not built yet".
- Page settings: Scrolling direction (only Vertical works, the other two are greyed) + Background colour.
- Customise toolbar is a full-screen page: title, back, Reset, live Preview strip, Available tools list with icons,
  toolbar position (Bottom/Top/Left/Right) and Pen debug info (moved here from the menu). Rows move with arrows
  (Samsung drags them).
- Toolbar default drops "Favourite pens"; "Shapes" is called "Auto-fix shapes"; "Lasso select" is called "Select".
- Handwriting eraser panel: Stroke eraser / Area eraser, Erase highlighter only, Erase tape only (new), Erase all handwriting.
- Lock canvas shows "Canvas locked. Swipe with two fingers to scroll." (a Toast, not Samsung's card).

**Still different from the video (not done in 9e):** Note style cover/page panel with tabs, left page panel, Drag for
new page / Release to add page, Sticky note + Table, Drawing pad, Select-language dialog for Convert, Convert to maths,
Clipboard sheet, Tape hide/show + patterns check, Home sidebar/cover cards, 2-page / horizontal scrolling, in-note search.

## Build 9d (on top of 9c-fixed) - versionName 0.9.4
- Toolbar position: Customise (last toolbar button) now has a "Toolbar position" row: Bottom / Top / Left / Right. Same saved
  setting ("dock" in SharedPreferences inknotes_ui) as the drag grip at the start of the toolbar, so both ways work and stay in sync.
  Default stays Bottom (new Samsung Notes UI); Top = old Samsung Notes UI. Only the two files EditorDialogs.kt and
  EditorScreen.kt changed (+ versionCode 10 / versionName 0.9.4).
- NOT compile-tested (no kotlinc / internet here). The 9c-fixed GitHub Actions build is also still unconfirmed. If a compile
  error shows up, send the log zip and fix that first.
- The repo workflow builds the FIRST .zip (alphabetical) in the repo root: delete InkNotes-build9c-fixed.zip when you upload this one.

## Build 9c (on top of 9b)
- The grey pen dot was removed: it came from the screen recorder, not from Samsung Notes.
- Speed: a running cache rebuild stops the moment the pen touches down, no commit in the middle of a stroke, the stroke
  geometry cache holds a whole dense page (it was cleared at 1500 strokes), bigger cache while zoom is below 200%.
- Easy writing pad: strokes show on the page at once while writing in the pad, thin Samsung header (grip, back, forward,
  new line), blue marker near the right end, the frame moves on after the pen is lifted past 80% and wraps to the next line.
- Change style: now a Samsung panel (slider with number, colour pages). Works without a selection (whole page), changes
  apply at once and count as ONE undo step; every stroke keeps its own pen.
- Colour pages (swipe sideways, recent colours first) in the pen, tape, laser and change style panels.
- Selection: floating toolbar (Cut, Copy, Paste, Delete, Change style, Convert to text, more), blue tinted box, rotate handle,
  select all, paste, Lasso / Rectangle mode (tap the lasso tool again).
- Zoom % chip with reset while zooming, page chip (1/2) while scrolling.
- Reading mode like Samsung: no bars, Settings chip top right, X button at the bottom.
- Tape: "Adjust thickness to text".

## Build 9b
- Zoom -> write delay: cache rebuilds wait until the pen is idle (no rebuild storm while writing), the old cache bitmap is reused.
- Laser pointer: Samsung look (yellow glowing trail, fades all at once after the pen is lifted) + panel with 3 styles,
  Rainbow / Single colour and the colour row.
- Pen cursor: grey dot at the pen tip while hovering and writing.
- Lock canvas: one finger is ignored, two fingers still move / zoom.
- Handwriting help panel: Smart guideline, Align letters (basic), Fix the shape of letters (smoothing).
- Easy writing pad rewritten: a strip above the toolbar that shows the blue frame area of the page magnified; the frame
  moves on by itself, can be dragged / resized, buttons: back, space, new line, close.
- Toolbar: Samsung order and Samsung-style icons, "customise" button at the end; photo / voice no longer in the default toolbar.

## Build 9a
- Zoom lag: cache rebuild only when zoom differs by more than 4%, new strokes stay sharp (pending) instead of being painted
  into a stale/blurry cache, lighter live preview for long strokes, smaller cache while zoomed in, HUD shows "cache zoom".
- New page templates: Grid narrow, Weekly, Daily, To-do, Journal (menu > Note style lists them).
- Database v2 (migration keeps notes from build 5 and build 8 installs). New fields: note cover, favourite. Backend only for now
  (sticky notes / tables storage, bookmark, PDF as a new page, audio file import) - UI comes in the next zip.
- Still NOT compiled. If the app crashes right after installing over an old build: uninstall once and install fresh.

## Build 5
- App icon (adaptive), One UI colour theme (no wallpaper-tinted colours), richer pen illustrations.
- Area eraser (cuts strokes, undoable) + stroke eraser, eraser size slider, eraser circle.
- Scroll lag: ink cache now covers the view + a margin, so normal scrolling never rebuilds; viewport rebuilds never starve.
  Debug HUD (menu > Pen debug info) also shows strokes / rebuild time / dropped frames.
- Shapes tool (drag: line, rectangle, circle, triangle, arrow), favourite pens (star in the pen panel), pen settings remembered.
- Align handwriting (select > ruler icon), Cornell + music-staff templates.
- Export to PNG / vector PDF (menu > Export), Add note to folder, Lock note (fingerprint / face / screen lock to open).

## Build 4
- Lag fixes: front-buffer frames are coalesced (one in flight at a time), palm/touch-area rejection while the pen is near,
  zoom/pan rebuild only draws visible strokes and aborts when superseded, finished strokes stay visible via a pending list.
- Page like Samsung Notes: grey desk + centred white page, clamped scrolling, fling scroll.
- Reading mode: pen AND finger scroll (menu book icon, top bar).
- Hold to shape (pen panel): hold 0.5 s -> line / triangle / rectangle / circle / ellipse preview + haptic tick. "Straighten lines" = lines only.
- Pen panel: line styles (solid / tapered / dashed / dotted), reference colours. Flat centred toolbar.
- PDF import (PDF icon on home): pages stacked under the ink, rendered lazily by zoom level, annotate with pen/highlighter.
- Home like the reference: left rail, page thumbnails, book covers, round pencil FAB. Editor menu: Note style, Background colour, finger drawing.

## Build 3
- Latency: unbuffered touch dispatch, front-buffer live stroke + 14 ms pen-tip prediction, max refresh rate request.
  (1 ms is physically impossible - the panel refreshes every ~11 ms at 90 Hz; goal = as close to Samsung Notes as possible.)
- Lag/crash fixes: committed strokes live in a bitmap cache updated on a background thread (no full redraw per stroke),
  compact point storage + 20-stroke chunks (was MB-sized JSON rewrites per stroke), crash report saved + shown on next launch.
- Pens: fountain, calligraphy, ballpoint, pencil, watercolor, brush + 2 highlighters, each with its own look, colour and size (1-100);
  pressure (gamma curve + smoothing) and tilt (pencil/brush/watercolor widen + fade). Overflow menu > "Pen debug info" shows live
  pressure / tilt / orientation so you can check what the S Pen really reports.
- Samsung-style UI: bottom toolbar + floating pen panel (pen illustrations, size slider, straighten lines, colours, custom colour).
- Select tool (lasso): move, resize (corner handles), duplicate, recolour, delete, convert handwriting to text (ML Kit, English + Hindi).
- Photos (gallery): move, pinch resize/rotate, layer order, delete. Reading mode. Share as text. Clear all (undoable).

## Phase 2a (earlier)
- Rich-text layer (Text mode): block based - bold / italic / underline / strike, size, colour, highlight,
  alignment, bullets, indent, interactive checklists (tick = strikethrough). Formatting is per line/block,
  not per character (per-character spans = later). Typed text feeds the home-screen search index.
- Draw/Text toggle in the top bar. In Text mode finger pan/zoom is off (switch back to Draw to pan).

## Get an APK without Android Studio
Push this folder to a GitHub repo (branch `main`): Actions -> "Build debug APK" -> download artifact
`InkNotes-debug-apk` -> install `app-debug.apk` on the tablet (allow unknown sources). Or in Android Studio:
Build > Build APK(s). Expect a few compile errors on the very first build (never compiled yet) - fix/ask.

## Next phases
- Phase 2b: floating text boxes, area eraser, lasso, shape snap/straighten,
  ML Kit handwriting-to-text + OCR index, favourites dock, colour picker/eyedropper, multi-page + page sorter,
  Cornell/planner/music templates, page thumbnails, PDF import/markup (PdfRenderer), image editing
- Phase 3: audio-synced strokes, biometric AES-256 note lock, exports (PDF/DOCX/PPTX/PNG/TXT),
  Easy Writing Pad, reading mode, shared notebooks (needs a backend)

## Tab S10 Lite notes
- Mid-range chip: next perf step is caching committed strokes in a bitmap/tile cache (currently the multi
  buffer redraws every stroke on commit/pan/zoom - fine for hundreds, not thousands). Add a Baseline Profile.
- Manifest already: resizeable (split-screen/DeX), configChanges so rotation doesn't recreate the ink surface.
- Highlighter Multiply only applies on export/flatten; live overlay approximates with alpha.
- Don't ship Samsung branding/assets - behaviour is inspired, visuals are your own.
